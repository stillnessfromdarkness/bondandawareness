// ══════════════════════════════════════════
//  NAVIGATION
// ══════════════════════════════════════════
function goTo(id) {
  const current = document.getElementById(state.currentScreen);
  const next = document.getElementById(id);
  if (!next) { console.warn('goTo: screen not found:', id); return; }
  if (current && current !== next) {
    current.classList.add('exit');
    setTimeout(() => { current.classList.remove('active', 'exit'); }, 300);
  }
  // Stop bell reminder when leaving the game screen
  if (id !== 'game') {
    clearTimeout(bellReminderTimer);
    bellReminderTimer = null;
  }
  // Stop all running animation loops to prevent overlap/lag
  if (window._stopAllAnims) window._stopAllAnims(id);
  setTimeout(() => {
    next.classList.add('active');
    state.currentScreen = id;
    // auth screens: no star animation
    if (id === 'profile') { setTimeout(() => openProfile(), 50); setTimeout(() => { if(typeof gardenBuild==='function'){ if(!_gardenBuilt) gardenBuild(); gardenUpdateProgress(); } }, 120); }
    if (id === 'social')  setTimeout(() => openSocial(), 50);
    if (id === 'language') initLanguagePage();
    if (id === 'game') initGamePage();
    if (id === 'unlock') initUnlockStars();
    if (id === 'welcome') setTimeout(() => initMandala('welcomeCanvas'), 30);
    if (id === 'name-entry') {
      setTimeout(() => initNeonSpiralLogo('nameEntrySpiralCanvas'), 80);
      // Se l'utente è loggato, pre-compila il campo nome con l'username
      setTimeout(() => {
        const savedUsername = getLoggedInName('');
        if (savedUsername) {
          const inp = document.getElementById('playerNameInput');
          if (inp && !inp.value) inp.value = savedUsername;
        }
      }, 150);
    }
  }, current && current !== next ? 100 : 0);
  if (!current || current === next) state.currentScreen = id;
}
window.goTo = goTo;

// ══════════════════════════════════════════
//  ANIMATION MANAGER — stop all loops on screen change
// ══════════════════════════════════════════
window._animRafs = {};
window._stopAllAnims = function(keep) {
  for (const [name, id] of Object.entries(window._animRafs)) {
    if (name !== keep) { cancelAnimationFrame(id); delete window._animRafs[name]; }
  }
};

// ══════════════════════════════════════════
//  HELPERS
// ══════════════════════════════════════════
function generateId() {
  const r1 = Math.random().toString(36).substr(2, 9);
  const r2 = Math.random().toString(36).substr(2, 5);
  return r1 + r2 + '_' + Date.now();
}

function showToast(msg, cls, duration = 3000) {
  // Rimuovi eventuali toast della stessa classe già presenti
  document.querySelectorAll('.toast.' + cls).forEach(old => old.remove());
  const el = document.createElement('div');
  el.className = 'toast ' + cls;
  // FIX XSS: sanitize msg prima di inserirlo in innerHTML.
  // I toast interni usano solo testo + emoji (nessun tag HTML), quindi è sicuro.
  // Se un nome utente contenesse <script> o <img onerror=...> verrebbe neutralizzato.
  el.textContent = msg;
  document.body.appendChild(el);
  requestAnimationFrame(() => { requestAnimationFrame(() => { el.classList.add('show'); }); });
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 400);
  }, duration);
}

// ══════════════════════════════════════════
//  ENTER GAME — show mode selection
// ══════════════════════════════════════════
// FIX: debounce 400ms — evita una query Supabase per ogni singolo carattere digitato
function _verifyRoomExists(roomCode) {
  if (state._verifyDebounce) { clearTimeout(state._verifyDebounce); state._verifyDebounce = null; }
  if (!roomCode || roomCode.length < 4) return;
  state._verifyDebounce = setTimeout(() => {
    state._verifyDebounce = null;
    const sb = _sbClient();
    if (!sb) return;
    const roomId = 'room_' + roomCode.toUpperCase();
    sb.from('matches').select('status').eq('id', roomId).maybeSingle().then(({ data }) => {
      if (!data) {
        const hint = document.querySelector('.name-entry-subtitle');
        if (hint) {
          hint.textContent = '⚠️ Room not found or expired';
          hint.style.color = 'rgba(255,100,100,0.85)';
        }
        state._roomVerified = false;
      } else if (data.status !== 'waiting') {
        const hint = document.querySelector('.name-entry-subtitle');
        if (hint) {
          hint.textContent = '⚠️ Room is full or already started';
          hint.style.color = 'rgba(255,100,100,0.85)';
        }
        state._roomVerified = false;
      } else {
        const hint = document.querySelector('.name-entry-subtitle');
        if (hint) {
          hint.textContent = '✓ Room found — enter your name';
          hint.style.color = 'rgba(125,249,240,0.85)';
        }
        state._roomVerified = true;
        state._roomHostName = data.hostName || '';
      }
    }).catch(() => {
      state._roomVerified = null;
    });
  }, 400);
}

function enterGame() {
  const input = document.getElementById('playerNameInput');
  const name = input.value.trim();
  if (!name) {
    input.classList.add('shake');
    setTimeout(() => input.classList.remove('shake'), 500);
    return;
  }
  state.playerName = name;
  try { localStorage.setItem('playerName', name); } catch(e) {}
  state.isSolo = false;
  state.isOffline = false;

  if (state._pendingRoom) {
    state._pendingRoom = false;
    const action = state._pendingRoomAction || 'join';
    const urlRoom = state._pendingRoomCode || new URLSearchParams(window.location.search).get('room');

    if (action === 'create') {
      // Host: crea la stanza
      state._pendingRoomAction = null;
      state._pendingRoomCode = null;
      createPrivateRoom(name);
    } else {
      // Guest: unisciti
      if (!urlRoom) {
        // nessun codice — torna alla join modal
        state._pendingRoom = true;
        startJoinRoom();
        return;
      }
      if (state._roomVerified === false) {
        const hint = document.querySelector('.name-entry-subtitle');
        if (hint) hint.textContent = '⚠️ Room not found — ask for a new invite link';
        state._pendingRoom = true;
        return;
      }
      const btn = document.querySelector('#name-entry .btn-primary');
      if (btn) { btn.textContent = 'Joining…'; btn.disabled = true; }
      joinPrivateRoom(urlRoom, name);
    }
    return;
  }

  state._pendingOnline = false;
  goTo('game');
  setTimeout(joinMatchQueue, 600);
}
window.enterGame = enterGame;

function showModeSelection() {
  // Gate: require auth to have been completed (login or guest) before playing
  if (!window._authCompleted) {
    state._authReturnTo = 'modeSelection';
    goTo('auth-screen');
    return;
  }
  const t = state._uiText || UI_TEXT['en'];
  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.id = 'modeModal';
  modal.innerHTML = `
    <div class="modal-box">
      <div style="display:flex;align-items:center;margin-bottom:0.8rem;" class="mode-back-fade">
        <button onclick="closeModeModal();goTo('welcome')" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.14);border-radius:50%;color:rgba(255,255,255,0.6);font-size:1.1rem;width:38px;height:38px;display:flex;align-items:center;justify-content:center;cursor:pointer;line-height:1;flex-shrink:0;transition:all 0.25s;box-shadow:0 0 0 0 rgba(255,255,255,0.08);" onmouseover="this.style.background='rgba(255,255,255,0.1)';this.style.borderColor='rgba(255,255,255,0.3)';this.style.color='white';" onmouseout="this.style.background='rgba(255,255,255,0.04)';this.style.borderColor='rgba(255,255,255,0.14)';this.style.color='rgba(255,255,255,0.6)';">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
      </div>
      <button class="mode-btn solo-btn mode-star-1" onclick="pickOfflineMode()">
        <span class="mode-icon">
          <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
            <defs>
              <filter id="cGlow" x="-40%" y="-40%" width="180%" height="180%">
                <feGaussianBlur stdDeviation="1.8" result="b"/>
                <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
              </filter>
              <clipPath id="clipA"><circle cx="18" cy="22" r="12"/></clipPath>
            </defs>
            <circle cx="18" cy="22" r="13" fill="rgba(125,249,240,0.07)" class="circle-a"/>
            <circle cx="26" cy="22" r="13" fill="rgba(125,249,240,0.07)" class="circle-b"/>
            <circle cx="26" cy="22" r="12" fill="rgba(125,249,240,0.13)" clip-path="url(#clipA)"/>
            <circle cx="18" cy="22" r="12" stroke="rgba(125,249,240,0.8)" stroke-width="1.4" fill="none" filter="url(#cGlow)" class="circle-a"/>
            <circle cx="26" cy="22" r="12" stroke="rgba(125,249,240,0.8)" stroke-width="1.4" fill="none" filter="url(#cGlow)" class="circle-b"/>
          </svg>
        </span>
        <div><div class="mode-title">${t.modeOfflineTitle || 'In Person'}</div><div class="mode-sub">${t.modeOfflineSub || 'Bond with your close ones using a single shared device.'}</div></div>
      </button>
      <button class="mode-btn online-btn mode-star-2" onclick="pickOnlineMode()">
        <span class="mode-icon">
          <canvas id="globeCanvas" width="44" height="44" style="display:block;"></canvas>
        </span>
        <div>
          <div class="mode-title">${t.modeOnlineTitle || 'World Play'}</div>
          <div class="mode-sub" id="onlineStatusText">${t.modeOnlineSub || 'Connect with a soul from across the globe.'}</div>
        </div>
      </button>
      <button class="mode-btn room-btn mode-star-3" onclick="pickRoomMode()">
        <span class="mode-icon">
          <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
            <defs>
              <filter id="keyGlow" x="-40%" y="-40%" width="180%" height="180%">
                <feGaussianBlur stdDeviation="2" result="b"/>
                <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
              </filter>
              <filter id="keyGlow2" x="-60%" y="-60%" width="220%" height="220%">
                <feGaussianBlur stdDeviation="5" result="b"/>
                <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
              </filter>
            </defs>
            <circle cx="22" cy="18" r="11" fill="rgba(255,213,128,0.08)" class="keyhole-glow" filter="url(#keyGlow2)"/>
            <circle cx="22" cy="18" r="7.5" stroke="rgba(255,213,128,0.88)" stroke-width="1.4" fill="none" filter="url(#keyGlow)" class="keyhole-shape"/>
            <path d="M19.5 24.5 L19.5 33 L24.5 33 L24.5 24.5" stroke="rgba(255,213,128,0.88)" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" fill="none" filter="url(#keyGlow)" class="keyhole-shape"/>
            <circle cx="22" cy="18" r="3" stroke="rgba(255,213,128,0.6)" stroke-width="1.1" fill="rgba(255,213,128,0.15)" filter="url(#keyGlow)" class="keyhole-shape"/>
            <circle cx="22" cy="18" r="1.2" fill="rgba(255,230,160,0.95)" class="keyhole-glow"/>
          </svg>
        </span>
        <div>
          <div class="mode-title" style="color:#ffd580;">${t.modeRoomTitle||'Private Space'}</div>
          <div class="mode-sub">${t.modeRoomSub||'Connect with a friend online, each on your own device.'}</div>
        </div>
      </button>
    </div>
  `;
  document.body.appendChild(modal);
  // Init 3D globe canvas
  requestAnimationFrame(() => initGlobeCanvas());
}

function initGlobeCanvas() {
  const canvas = document.getElementById('globeCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = 44, H = 44, cx = 22, cy = 22, R = 14;
  let angle = 0;

  // Define latitude lines (y positions on sphere surface)
  const latitudes = [-60, -30, 0, 30, 60]; // degrees
  // Define longitude lines (equally spaced)
  const longitudes = [0, 40, 80, 120, 160, 200, 240, 280, 320];

  function project(lon, lat, rotY) {
    const latR = lat * Math.PI / 180;
    const lonR = (lon + rotY) * Math.PI / 180;
    const x3 = Math.cos(latR) * Math.sin(lonR);
    const y3 = Math.sin(latR);
    const z3 = Math.cos(latR) * Math.cos(lonR);
    return { x: cx + R * x3, y: cy - R * y3, z: z3 };
  }

  function drawArc(points, alpha, lineWidth) {
    if (points.length < 2) return;
    // split into visible segments
    let seg = [];
    for (let i = 0; i < points.length; i++) {
      const p = points[i];
      if (p.z >= 0) {
        seg.push(p);
      } else {
        if (seg.length > 1) {
          ctx.beginPath();
          ctx.moveTo(seg[0].x, seg[0].y);
          for (let j = 1; j < seg.length; j++) ctx.lineTo(seg[j].x, seg[j].y);
          ctx.strokeStyle = "rgba(200,130,255," + alpha + ")";
          ctx.lineWidth = lineWidth;
          ctx.stroke();
        }
        seg = [];
      }
    }
    if (seg.length > 1) {
      ctx.beginPath();
      ctx.moveTo(seg[0].x, seg[0].y);
      for (let j = 1; j < seg.length; j++) ctx.lineTo(seg[j].x, seg[j].y);
      ctx.strokeStyle = "rgba(200,130,255," + alpha + ")";
      ctx.lineWidth = lineWidth;
      ctx.stroke();
    }
  }

  let _gLastFrame = 0;
  const _gFrameMs = 1000 / 30; // 30fps is plenty for a 44px icon

  function draw(now) {
    if (now - _gLastFrame < _gFrameMs) return;
    _gLastFrame = now;
    ctx.clearRect(0, 0, W, H);

    // Outer glow
    const grd = ctx.createRadialGradient(cx, cy, R * 0.6, cx, cy, R * 1.3);
    grd.addColorStop(0, 'rgba(180,100,255,0.0)');
    grd.addColorStop(1, 'rgba(180,100,255,0.13)');
    ctx.beginPath();
    ctx.arc(cx, cy, R * 1.3, 0, Math.PI * 2);
    ctx.fillStyle = grd;
    ctx.fill();

    const deg = angle * (180 / Math.PI);

    // Draw back latitudes first (faded)
    for (const lat of latitudes) {
      const pts = [];
      for (let lon = 0; lon <= 360; lon += 4) {
        pts.push(project(lon, lat, deg));
      }
      // back hemisphere only
      const back = pts.map(p => ({ ...p }));
      ctx.save();
      ctx.globalAlpha = 0.18;
      for (let i = 1; i < back.length; i++) {
        if (back[i-1].z < 0 && back[i].z < 0) {
          ctx.beginPath();
          ctx.moveTo(back[i-1].x, back[i-1].y);
          ctx.lineTo(back[i].x, back[i].y);
          ctx.strokeStyle = 'rgba(200,130,255,1)';
          ctx.lineWidth = 0.6;
          ctx.stroke();
        }
      }
      ctx.restore();
    }

    // Draw back longitudes
    for (const lon of longitudes) {
      ctx.save();
      ctx.globalAlpha = 0.18;
      for (let lat = -88; lat < 88; lat += 4) {
        const p1 = project(lon, lat, deg);
        const p2 = project(lon, lat + 4, deg);
        if (p1.z < 0 && p2.z < 0) {
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.strokeStyle = 'rgba(200,130,255,1)';
          ctx.lineWidth = 0.6;
          ctx.stroke();
        }
      }
      ctx.restore();
    }

    // Clip to sphere for front lines
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.clip();

    // Front latitudes
    for (const lat of latitudes) {
      const pts = [];
      for (let lon = 0; lon <= 360; lon += 3) {
        pts.push(project(lon, lat, deg));
      }
      drawArc(pts, lat === 0 ? 0.7 : 0.45, lat === 0 ? 1.1 : 0.8);
    }

    // Front longitudes
    for (const lon of longitudes) {
      const pts = [];
      for (let lat = -88; lat <= 88; lat += 3) {
        pts.push(project(lon, lat, deg));
      }
      drawArc(pts, 0.4, 0.8);
    }

    ctx.restore();

    // Sphere border
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(200,130,255,0.85)';
    ctx.lineWidth = 1.3;
    ctx.stroke();

    // Travelling dot - star pattern: center→top-right→bottom-left→center→bottom-right→top-left→center
    {
      const starR = R * 0.65; // radius from center to corner points
      // Waypoints: [x, y] relative to globe center (cx, cy)
      const waypoints = [
        [0, 0],                               // center
        [starR * 0.7, -starR * 0.7],          // top-right
        [-starR * 0.7, starR * 0.7],          // bottom-left
        [0, 0],                               // center
        [starR * 0.7, starR * 0.7],           // bottom-right
        [-starR * 0.7, -starR * 0.7],         // top-left
        [0, 0],                               // center (then repeats)
      ];
      const stepDuration = 1.2; // seconds per segment
      const totalDuration = stepDuration * (waypoints.length - 1);
      const t = (Date.now() / 1000) % totalDuration;
      const segIdx = Math.floor(t / stepDuration);
      const segT = (t - segIdx * stepDuration) / stepDuration;
      // Smooth easing
      const ease = segT < 0.5 ? 2 * segT * segT : 1 - Math.pow(-2 * segT + 2, 2) / 2;
      const from = waypoints[segIdx];
      const to = waypoints[segIdx + 1];
      const dx = cx + from[0] + (to[0] - from[0]) * ease;
      const dy = cy + from[1] + (to[1] - from[1]) * ease;

      // Draw dot with glow
      const dotAlpha = 0.95;
      ctx.beginPath();
      ctx.arc(dx, dy, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255,200,255," + dotAlpha + ")";
      ctx.fill();
      const dg = ctx.createRadialGradient(dx, dy, 0, dx, dy, 7);
      dg.addColorStop(0, "rgba(220,160,255,0.6)");
      dg.addColorStop(1, 'rgba(220,160,255,0)');
      ctx.beginPath();
      ctx.arc(dx, dy, 7, 0, Math.PI * 2);
      ctx.fillStyle = dg;
      ctx.fill();
    }

    angle += 0.004;
  }

  function loop(now) {
    if (!document.getElementById('globeCanvas')) return;
    if (document.hidden) { window._animRafs['globe'] = requestAnimationFrame(loop); return; }
    draw(now);
    window._animRafs['globe'] = requestAnimationFrame(loop);
  }
  window._animRafs['globe'] = requestAnimationFrame(loop);
}

// ── Helper: restituisce l'username loggato se disponibile ──
function getLoggedInName(fallback) {
  const lp = window._localProfile || (typeof _localProfile !== 'undefined' ? _localProfile : null);
  const cu = (typeof currentUser !== 'undefined') ? currentUser : null;
  return lp?.username || cu?.user_metadata?.full_name || fallback || 'Player';
}
window.getLoggedInName = getLoggedInName;

function pickOfflineMode() {
  // Modalità offline: 1 solo giocatore, nessuna configurazione
  const name = getLoggedInName('Player');
  offlinePlayerCount = 1;
  offlinePlayers = [{ name, index: 0 }];
  offlineCurrentTurn = 0;
  state.isSolo = false;
  state.isOffline = true;
  state.playerName = name;
  goTo('game');
  // Remove modal AFTER screen transition to avoid flash
  setTimeout(() => closeModeModal(), 50);
}
window.pickOfflineMode = pickOfflineMode;

function pickOnlineMode() {
  // Supabase always available
  // Se l'utente è loggato con username, usa direttamente quello senza chiedere
  const saved = getLoggedInName('');
  if (saved) {
    state.playerName = saved;
    try { localStorage.setItem('playerName', saved); } catch(e) {}
    state.isSolo = false;
    state.isOffline = false;
    goTo('game');
    // Remove modal AFTER screen transition to avoid flash
    setTimeout(() => closeModeModal(), 50);
    setTimeout(joinMatchQueue, 600);
    return;
  }
  // Show name modal BEFORE removing modeModal to avoid flash
  _showOnlineNameModal();
  setTimeout(() => closeModeModal(), 50);
}
window.pickOnlineMode = pickOnlineMode;

function _showOnlineNameModal() {
  document.getElementById('onlineNameModal')?.remove();
  const t = state._uiText || UI_TEXT['en'];
  const saved = getLoggedInName('');
  const modal = document.createElement('div');
  modal.className = 'modal-overlay'; modal.id = 'onlineNameModal';
  modal.innerHTML = `
    <div class="room-box" style="text-align:center;border-color:rgba(72,202,228,0.22);box-shadow:0 24px 64px rgba(0,0,0,0.8),0 0 40px rgba(72,202,228,0.07);">
      <div style="display:flex;align-items:center;margin-bottom:1.2rem;">
        <button class="room-back-btn" onclick="document.getElementById('onlineNameModal')?.remove();showModeSelection()"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg></button>
      </div>
      <div class="room-title" style="color:#48CAE4;">${t.onlineNameTitle || 'What shall we call you?'}</div>
      <div class="room-sub" style="color:rgba(72,202,228,0.45);margin-bottom:1.4rem;">${t.onlineNameSub || 'any name you wish to carry into this space'}</div>
      <input id="onlineNameModalInput" class="room-input room-input-cyan" type="text" maxlength="20"
        placeholder="${t.onlineNamePlaceholder || 'your name\u2026'}" value="${saved}"
        onkeydown="if(event.key==='Enter') _submitOnlineName()"/>
      <button class="room-icon-btn room-btn-cyan" onclick="_submitOnlineName()">${t.onlineNameBtn || 'Enter →'}</button>
    </div>
  `;
  document.body.appendChild(modal);
  setTimeout(() => {
    const inp = document.getElementById('onlineNameModalInput');
    if (inp) { inp.focus(); if (saved) inp.select(); }
  }, 100);
}
window._showOnlineNameModal = _showOnlineNameModal;

function _submitOnlineName() {
  const inp = document.getElementById('onlineNameModalInput');
  const name = inp?.value.trim();
  if (!name) {
    if (inp) { inp.style.borderColor='rgba(255,80,80,0.5)'; setTimeout(()=>{ inp.style.borderColor=''; }, 1200); }
    return;
  }
  state.playerName = name;
  try { localStorage.setItem('playerName', name); } catch(e) {}
  document.getElementById('onlineNameModal')?.remove();
  state.isSolo = false;
  state.isOffline = false;
  goTo('game');
  setTimeout(joinMatchQueue, 600);
}
window._submitOnlineName = _submitOnlineName;
const _origSubmitOnlineName = _submitOnlineName;

function closeModeModal() {
  const m = document.getElementById('modeModal');
  if (!m) return;
  m.style.transition = 'opacity 0.15s ease';
  m.style.opacity = '0';
  m.style.pointerEvents = 'none';
  setTimeout(() => m.remove(), 160);
}

