//  UNLOCK
// ══════════════════════════════════════════
function tryUnlock() {
  const input = document.getElementById('unlockCodeInput');
  const code = input.value.trim().toUpperCase();
  const errorDiv = document.getElementById('unlockError');
  const validCodes = ['DEEPCONNECTION', 'BONDAWARENESS'];
  if (validCodes.includes(code)) {
    state.isUnlocked = true;
    try { localStorage.setItem('isUnlocked', 'true'); } catch(e) {}
    errorDiv.style.display = 'none';
    showToast('✨ Full Journey Unlocked!', 'match-found', 2500);
    setTimeout(() => goTo('game'), 2000);
  } else {
    errorDiv.style.display = 'block';
    input.classList.add('shake');
    setTimeout(() => input.classList.remove('shake'), 500);
  }
}
window.tryUnlock = tryUnlock;

// ══════════════════════════════════════════
//  SHARE
// ══════════════════════════════════════════
function shareApp() {
  if (navigator.share) {
    navigator.share({ title: 'Bond & Awareness', text: 'Play this deep connection game with me!', url: window.location.href });
  } else {
    navigator.clipboard.writeText(window.location.href)
      .then(() => showToast('🔗 Link copied!', 'match-found', 2000))
      .catch(() => {});
  }
}
window.shareApp = shareApp;

// ══════════════════════════════════════════
//  CANVAS ANIMATIONS
// ══════════════════════════════════════════
function initMandala(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  if (canvasId === 'splashCanvas') { initUltraBotanical(canvas); return; }
  if (canvasId !== 'welcomeCanvas') return;

  // ── Static starfield for home/welcome screen ───────────────────────────
  // Same spectral distribution as splash but completely static — no animation loop
  const ctx = canvas.getContext('2d');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  let W = canvas.offsetWidth || window.innerWidth;
  let H = canvas.offsetHeight || window.innerHeight;
  canvas.width  = W * dpr;
  canvas.height = H * dpr;
  ctx.scale(dpr, dpr);

  const SPECTRAL_W = [
    { h:220, s:60,  lMin:92, lMax:100, prob:0.04 },
    { h:210, s:40,  lMin:90, lMax:98,  prob:0.08 },
    { h:200, s:20,  lMin:90, lMax:97,  prob:0.14 },
    { h:55,  s:30,  lMin:88, lMax:96,  prob:0.18 },
    { h:48,  s:55,  lMin:82, lMax:92,  prob:0.26 },
    { h:30,  s:65,  lMin:70, lMax:85,  prob:0.18 },
    { h:10,  s:70,  lMin:55, lMax:75,  prob:0.12 },
  ];
  function pickSpW() {
    let rnd = Math.random(), acc = 0;
    for (const sp of SPECTRAL_W) { acc += sp.prob; if (rnd < acc) return sp; }
    return SPECTRAL_W[4];
  }

  function drawStaticStars() {
    ctx.clearRect(0, 0, W, H);
    const count = Math.floor(W * H * 0.00055);
    for (let i = 0; i < count; i++) {
      const sp  = pickSpW();
      const mag = Math.random();
      const r   = mag < 0.04 ? 1.1 + Math.random() * 0.5
                : mag < 0.15 ? 0.5  + Math.random() * 0.4
                :               0.15 + Math.random() * 0.26;
      const l   = sp.lMin + Math.random() * (sp.lMax - sp.lMin);
      const alpha = mag < 0.04 ? 0.55 + Math.random() * 0.25
                  : mag < 0.15 ? 0.30 + Math.random() * 0.20
                  :               0.08 + Math.random() * 0.18;
      const hue = sp.h + (Math.random() - 0.5) * 14;
      const x   = Math.random() * W;
      const y   = Math.random() * H;

      if (r > 0.5) {
        const glowR = r * (r > 1.0 ? 8 : 4);
        const g = ctx.createRadialGradient(x, y, 0, x, y, glowR);
        g.addColorStop(0,   `hsla(${hue},${sp.s}%,${l}%,${alpha * 0.30})`);
        g.addColorStop(0.3, `hsla(${hue},${sp.s}%,${l}%,${alpha * 0.08})`);
        g.addColorStop(1,   `hsla(${hue},${sp.s}%,${l}%,0)`);
        ctx.beginPath(); ctx.arc(x, y, glowR, 0, Math.PI * 2);
        ctx.fillStyle = g; ctx.fill();
      }

      ctx.beginPath(); ctx.arc(x, y, Math.max(0.2, r), 0, Math.PI * 2);
      ctx.fillStyle = `hsla(${hue},${sp.s}%,${l}%,${alpha})`;
      ctx.fill();

      if (r > 1.1) {
        const spikeLen = r * 7;
        [[1,0],[0,1]].forEach(([dx,dy]) => {
          const sg = ctx.createLinearGradient(x - dx*spikeLen, y - dy*spikeLen, x + dx*spikeLen, y + dy*spikeLen);
          sg.addColorStop(0,   `hsla(${hue},${sp.s}%,${l}%,0)`);
          sg.addColorStop(0.45,`hsla(${hue},${sp.s}%,${l}%,${alpha * 0.45})`);
          sg.addColorStop(0.5, `hsla(${hue},${sp.s}%,${l}%,${alpha * 0.65})`);
          sg.addColorStop(0.55,`hsla(${hue},${sp.s}%,${l}%,${alpha * 0.45})`);
          sg.addColorStop(1,   `hsla(${hue},${sp.s}%,${l}%,0)`);
          ctx.beginPath();
          ctx.moveTo(x - dx*spikeLen, y - dy*spikeLen);
          ctx.lineTo(x + dx*spikeLen, y + dy*spikeLen);
          ctx.strokeStyle = sg; ctx.lineWidth = r * 0.35; ctx.lineCap = 'round'; ctx.stroke();
        });
      }
    }
  }

  drawStaticStars();
  window.addEventListener('resize', () => {
    W = canvas.offsetWidth || window.innerWidth;
    H = canvas.offsetHeight || window.innerHeight;
    canvas.width  = W * dpr;
    canvas.height = H * dpr;
    ctx.scale(dpr, dpr);
    drawStaticStars();
  });
  return; // static only — no animation loop

  // Legacy unused code below (unreachable)
  let t = 0;
  let stars = [], nebulae = [], shootingStars = [];
  let lastShoot = 0;

  // ── Stellar spectral colours (realistic OBAFGKM sequence) ─────────────
  // Hot blue-white → yellow-white → orange → deep red
  const SPECTRAL = [
    { h:220, s:60,  lMin:92, lMax:100, prob:0.04 }, // O – blue-white blazing
    { h:210, s:40,  lMin:90, lMax:98,  prob:0.08 }, // B – blue-white
    { h:200, s:20,  lMin:90, lMax:97,  prob:0.14 }, // A – white
    { h:55,  s:30,  lMin:88, lMax:96,  prob:0.18 }, // F – yellow-white
    { h:48,  s:55,  lMin:82, lMax:92,  prob:0.26 }, // G – yellow (sun-like)
    { h:30,  s:65,  lMin:70, lMax:85,  prob:0.18 }, // K – orange
    { h:10,  s:70,  lMin:55, lMax:75,  prob:0.12 }, // M – deep red-orange
  ];

  function pickSpectral() {
    let rnd = Math.random(), acc = 0;
    for (const sp of SPECTRAL) { acc += sp.prob; if (rnd < acc) return sp; }
    return SPECTRAL[4];
  }

  // ── Build star catalog ─────────────────────────────────────────────────
  function buildStars() {
    stars = [];
    const area = W * H;
    // Density: ~0.0008 stars per px² → realistic sparse sky
    // welcome canvas uses smaller, sparser stars so title stays readable
    const isWelcome = canvasId === 'welcomeCanvas';
    const count = Math.floor(area * (isWelcome ? 0.0005 : 0.0008));
    for (let i = 0; i < count; i++) {
      const sp = pickSpectral();
      const mag = Math.random(); // 0=bright, 1=dim
      // Radius: realistic distribution — most stars tiny (0.3–0.7px), few large
      const r = mag < 0.04 ? 1.1 + Math.random() * 0.6   // bright giants — smaller
              : mag < 0.15 ? 0.55 + Math.random() * 0.45  // medium — smaller
              :               0.15 + Math.random() * 0.28; // faint — smaller
      const l = sp.lMin + Math.random() * (sp.lMax - sp.lMin);
      const baseAlpha = mag < 0.04 ? 0.70 + Math.random() * 0.20
                      : mag < 0.15 ? 0.40 + Math.random() * 0.25
                      :               0.10 + Math.random() * 0.25;
      stars.push({
        x: Math.random() * W,
        y: Math.random() * H,
        r,
        h: sp.h + (Math.random() - 0.5) * 15,
        s: sp.s,
        l,
        baseAlpha,
        alpha: baseAlpha,
        // Twinkle parameters — high-freq flicker + slow atmospheric scintillation
        tw1: { speed: 0.03 + Math.random() * 0.07,  amp: 0.06 + Math.random() * 0.10, phase: Math.random() * Math.PI * 2 },
        tw2: { speed: 0.008 + Math.random() * 0.015, amp: 0.04 + Math.random() * 0.08, phase: Math.random() * Math.PI * 2 },
        // Diffraction spikes only for bright stars
        spikes: r > 1.2,
        // Colour scintillation (atmospheric dispersion flicker)
        colShift: r > 0.8 ? (Math.random() - 0.5) * 20 : 0,
      });
    }
    // Sort back-to-front so dimmer stars drawn first
    stars.sort((a, b) => a.r - b.r);
  }

  // ── Build soft nebula clouds ───────────────────────────────────────────
  function buildNebulae() {
    nebulae = [];
    const count = 3 + Math.floor(Math.random() * 3);
    for (let i = 0; i < count; i++) {
      nebulae.push({
        x: Math.random() * W,
        y: Math.random() * H,
        rx: W * (0.12 + Math.random() * 0.22),
        ry: H * (0.08 + Math.random() * 0.14),
        angle: Math.random() * Math.PI,
        h: [200, 220, 265, 180, 30][Math.floor(Math.random() * 5)],
        alpha: 0.012 + Math.random() * 0.022,
      });
    }
  }

  // ── Resize ─────────────────────────────────────────────────────────────
  function resize() {
    W = canvas.offsetWidth  || window.innerWidth;
    H = canvas.offsetHeight || window.innerHeight;
    canvas.width  = W * dpr;
    canvas.height = H * dpr;
    ctx.scale(dpr, dpr);
    buildStars();
    buildNebulae();
  }
  resize();
  // Build bodies after resize so W/H are set
  setTimeout(() => { if (typeof buildBodies === 'function') {} }, 0); // bodies built after function defs
  window.addEventListener('resize', () => { resize(); buildBodies(); });

  // ── Draw a single star with all physical effects ───────────────────────
  function drawStar(s, tick) {
    // Twinkle: two overlapping sine waves (fast atmospheric + slow seeing)
    const tw = 1
      + s.tw1.amp * Math.sin(tick * s.tw1.speed + s.tw1.phase)
      + s.tw2.amp * Math.sin(tick * s.tw2.speed + s.tw2.phase);
    const alpha = Math.max(0, Math.min(1, s.alpha * tw));
    const r     = s.r * (0.88 + 0.12 * tw);

    // Colour scintillation — hue wobbles slightly for bright stars
    const hue = s.h + s.colShift * Math.sin(tick * 0.04 + s.tw1.phase);

    // Outer diffuse glow (PSF — point spread function)
    if (r > 0.5) {
      const glowR = r * (s.spikes ? 9 : 5);
      const g = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, glowR);
      g.addColorStop(0,   `hsla(${hue},${s.s}%,${s.l}%,${alpha * 0.35})`);
      g.addColorStop(0.3, `hsla(${hue},${s.s}%,${s.l}%,${alpha * 0.10})`);
      g.addColorStop(1,   `hsla(${hue},${s.s}%,${s.l}%,0)`);
      ctx.beginPath();
      ctx.arc(s.x, s.y, glowR, 0, Math.PI * 2);
      ctx.fillStyle = g;
      ctx.fill();
    }

    // Diffraction spikes (bright stars only — 4-point Airy pattern)
    if (s.spikes && alpha > 0.4) {
      const spikeLen = r * 14 * tw;
      const spikeAlpha = alpha * 0.25;
      [[1,0],[0,1]].forEach(([dx, dy]) => {
        const sg = ctx.createLinearGradient(
          s.x - dx * spikeLen, s.y - dy * spikeLen,
          s.x + dx * spikeLen, s.y + dy * spikeLen
        );
        sg.addColorStop(0,   `hsla(${hue},${s.s}%,${s.l}%,0)`);
        sg.addColorStop(0.45,`hsla(${hue},${s.s}%,${s.l}%,${spikeAlpha})`);
        sg.addColorStop(0.5, `hsla(${hue},${s.s}%,${s.l}%,${spikeAlpha * 1.6})`);
        sg.addColorStop(0.55,`hsla(${hue},${s.s}%,${s.l}%,${spikeAlpha})`);
        sg.addColorStop(1,   `hsla(${hue},${s.s}%,${s.l}%,0)`);
        ctx.beginPath();
        ctx.moveTo(s.x - dx * spikeLen, s.y - dy * spikeLen);
        ctx.lineTo(s.x + dx * spikeLen, s.y + dy * spikeLen);
        ctx.strokeStyle = sg;
        ctx.lineWidth = r * 0.7;
        ctx.lineCap = 'round';
        ctx.stroke();
      });
    }

    // Hard stellar core
    const coreG = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, r * 1.5);
    coreG.addColorStop(0, `hsla(${hue},${Math.max(0,s.s-20)}%,100%,${alpha})`);
    coreG.addColorStop(0.4, `hsla(${hue},${s.s}%,${s.l}%,${alpha * 0.9})`);
    coreG.addColorStop(1,   `hsla(${hue},${s.s}%,${s.l}%,0)`);
    ctx.beginPath();
    ctx.arc(s.x, s.y, r * 1.5, 0, Math.PI * 2);
    ctx.fillStyle = coreG;
    ctx.fill();
  }

  // ── Shooting star ──────────────────────────────────────────────────────
  function spawnShootingStar() {
    const angle  = (Math.random() * 0.4 + 0.05) * Math.PI; // downward-ish
    const speed  = 6 + Math.random() * 8;
    const len    = 80 + Math.random() * 140;
    const x      = Math.random() * W;
    const y      = Math.random() * H * 0.5;
    shootingStars.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
      len, life: 1.0, decay: 0.016 + Math.random() * 0.012,
      h: 200 + Math.random() * 40 });
  }

  function drawShootingStar(ss) {
    const tail = ss.len * ss.life;
    const tx = ss.x - ss.vx / Math.hypot(ss.vx, ss.vy) * tail;
    const ty = ss.y - ss.vy / Math.hypot(ss.vx, ss.vy) * tail;
    const g = ctx.createLinearGradient(tx, ty, ss.x, ss.y);
    g.addColorStop(0, `hsla(${ss.h},60%,95%,0)`);
    g.addColorStop(0.7, `hsla(${ss.h},50%,97%,${ss.life * 0.5})`);
    g.addColorStop(1,   `hsla(${ss.h},30%,100%,${ss.life * 0.9})`);
    ctx.beginPath();
    ctx.moveTo(tx, ty);
    ctx.lineTo(ss.x, ss.y);
    ctx.strokeStyle = g;
    ctx.lineWidth = 1.2 * ss.life;
    ctx.lineCap = 'round';
    ctx.stroke();
    // Head flash
    const hg = ctx.createRadialGradient(ss.x, ss.y, 0, ss.x, ss.y, 4 * ss.life);
    hg.addColorStop(0, `hsla(${ss.h},20%,100%,${ss.life})`);
    hg.addColorStop(1, `hsla(${ss.h},60%,95%,0)`);
    ctx.beginPath();
    ctx.arc(ss.x, ss.y, 4 * ss.life, 0, Math.PI * 2);
    ctx.fillStyle = hg;
    ctx.fill();
  }

  // ── Draw nebulae ──────────────────────────────────────────────────────
  function drawNebulae() {
    for (const n of nebulae) {
      ctx.save();
      ctx.translate(n.x, n.y);
      ctx.rotate(n.angle);
      const g = ctx.createRadialGradient(0, 0, 0, 0, 0, n.rx);
      g.addColorStop(0,   `hsla(${n.h},55%,65%,${n.alpha})`);
      g.addColorStop(0.5, `hsla(${n.h},45%,55%,${n.alpha * 0.5})`);
      g.addColorStop(1,   `hsla(${n.h},35%,40%,0)`);
      ctx.scale(1, n.ry / n.rx);
      ctx.beginPath();
      ctx.arc(0, 0, n.rx, 0, Math.PI * 2);
      ctx.fillStyle = g;
      ctx.fill();
      ctx.restore();
    }
  }

  // ── N-body orbital system ─────────────────────────────────────────────
  // One dominant "sun" + lighter satellites with visible orbital trails.
  // Gravity: F = G·M/r² with softening. Heavy body stays near-centre;
  // lighter ones orbit faster when close (Kepler's second law).
  const G_CONST = 0.016, EPS2 = 200, DRAG = 0.9998;
  let bodies = [];

  const SPECTRAL2 = [
    { h:220, s:55, lMin:92, lMax:100 },
    { h:48,  s:50, lMin:82, lMax:92  },
    { h:10,  s:65, lMin:60, lMax:78  },
    { h:200, s:25, lMin:88, lMax:96  },
    { h:30,  s:60, lMin:72, lMax:86  },
  ];

  function buildBodies() {
    bodies = [];
    const cx = W/2, cy = H/2;
    // Sun — heavy, slow, near centre
    const sunMass = 700 + Math.random()*200;
    const sp0 = SPECTRAL2[1];
    bodies.push({
      x: cx+(Math.random()-0.5)*W*0.08, y: cy+(Math.random()-0.5)*H*0.08,
      vx:(Math.random()-0.5)*0.12, vy:(Math.random()-0.5)*0.12,
      mass: sunMass, r: 1.4, isSun: true,
      h: sp0.h, s: sp0.s, l: sp0.lMin+Math.random()*(sp0.lMax-sp0.lMin),
      trail: [], trailMax: 35, pulse: Math.random()*Math.PI*2,
    });
    // Satellites — light, scattered, with Keplerian initial velocity
    const N = 10 + Math.floor(Math.random()*3);
    for (let i = 0; i < N; i++) {
      const ang  = (i/N)*Math.PI*2 + (Math.random()-0.5)*0.8;
      const dist = Math.min(W,H) * (0.10 + Math.random()*0.35);
      const v    = Math.sqrt(G_CONST * sunMass / dist) * (0.5 + Math.random()*0.7);
      const dir  = Math.random()<0.5 ? 1:-1;
      const mass = 12 + Math.random()*40;
      const sp   = SPECTRAL2[Math.floor(Math.random()*SPECTRAL2.length)];
      bodies.push({
        x: cx+Math.cos(ang)*dist, y: cy+Math.sin(ang)*dist,
        vx: -Math.sin(ang)*v*dir, vy: Math.cos(ang)*v*dir,
        mass, r: 0.5 + Math.sqrt(mass/22)*0.35, isSun: false,
        h: sp.h+(Math.random()-0.5)*18, s: sp.s,
        l: sp.lMin+Math.random()*(sp.lMax-sp.lMin),
        trail: [], trailMax: 40 + Math.floor(Math.random()*20),
        pulse: Math.random()*Math.PI*2,
      });
    }
  }
  buildBodies();

  function physicsStep() {
    // Pairwise gravity
    for (let i = 0; i < bodies.length; i++) {
      let ax=0, ay=0;
      for (let j = 0; j < bodies.length; j++) {
        if (i===j) continue;
        const dx=bodies[j].x-bodies[i].x, dy=bodies[j].y-bodies[i].y;
        const dist2=dx*dx+dy*dy+EPS2;
        const f=G_CONST*bodies[j].mass/dist2;
        ax+=f*dx/Math.sqrt(dist2); ay+=f*dy/Math.sqrt(dist2);
      }
      // Weak tether toward centre (keeps system on screen)
      const tx=W/2-bodies[i].x, ty=H/2-bodies[i].y;
      const td=Math.sqrt(tx*tx+ty*ty)+1;
      ax+=tx/td*0.00035; ay+=ty/td*0.00035;
      bodies[i].vx=(bodies[i].vx+ax)*DRAG;
      bodies[i].vy=(bodies[i].vy+ay)*DRAG;
    }
    for (const b of bodies) {
      b.x+=b.vx; b.y+=b.vy;
      b.trail.push({x:b.x, y:b.y});
      if (b.trail.length>b.trailMax) b.trail.shift();
    }
  }

  function drawBodies() {
    for (const b of bodies) {
      // ── Orbital trail — semi-visible line ──────────────────────────
      if (b.trail.length > 2) {
        ctx.beginPath();
        ctx.moveTo(b.trail[0].x, b.trail[0].y);
        for (let i = 1; i < b.trail.length; i++) {
          ctx.lineTo(b.trail[i].x, b.trail[i].y);
        }
        // Gradient stroke: invisible at tail → semi-visible at head
        const t0 = b.trail[0], t1 = b.trail[b.trail.length-1];
        const tg = ctx.createLinearGradient(t0.x,t0.y, t1.x,t1.y);
        const trailAlpha = b.isSun ? 0.08 : 0.22;
        tg.addColorStop(0, `hsla(${b.h},${b.s}%,75%,0)`);
        tg.addColorStop(0.5,`hsla(${b.h},${b.s}%,80%,${trailAlpha*0.4})`);
        tg.addColorStop(1,  `hsla(${b.h},${b.s}%,85%,${trailAlpha})`);
        ctx.strokeStyle = tg;
        ctx.lineWidth = b.isSun ? 0.6 : 0.5;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.stroke();
      }

      // ── Body glow + core ──────────────────────────────────────────
      const pulse = 0.5+0.5*Math.sin(t*0.025+b.pulse);
      const cr = b.r*(0.9+0.1*pulse);

      // Corona
      const coronaR = cr*(b.isSun ? 12 : 8);
      const cg = ctx.createRadialGradient(b.x,b.y,0, b.x,b.y,coronaR);
      cg.addColorStop(0,  `hsla(${b.h},${b.s}%,${b.l}%,${(b.isSun?0.18:0.12)+0.06*pulse})`);
      cg.addColorStop(0.4,`hsla(${b.h},${b.s}%,${b.l}%,${0.04*pulse})`);
      cg.addColorStop(1,  `hsla(${b.h},${b.s}%,${b.l}%,0)`);
      ctx.beginPath(); ctx.arc(b.x,b.y,coronaR,0,Math.PI*2);
      ctx.fillStyle=cg; ctx.fill();

      // Diffraction spikes (sun + larger satellites)
      if (b.r > 0.9) {
        const sl = cr*(b.isSun?14:10)*(0.85+0.15*pulse);
        const sa = (b.isSun?0.28:0.18)+0.08*pulse;
        [[1,0],[0,1]].forEach(([dx,dy]) => {
          const sg=ctx.createLinearGradient(b.x-dx*sl,b.y-dy*sl,b.x+dx*sl,b.y+dy*sl);
          sg.addColorStop(0,  `hsla(${b.h},${b.s}%,${b.l}%,0)`);
          sg.addColorStop(0.44,`hsla(${b.h},${b.s}%,${b.l}%,${sa*0.7})`);
          sg.addColorStop(0.5, `hsla(${b.h},${b.s}%,${b.l}%,${sa})`);
          sg.addColorStop(0.56,`hsla(${b.h},${b.s}%,${b.l}%,${sa*0.7})`);
          sg.addColorStop(1,  `hsla(${b.h},${b.s}%,${b.l}%,0)`);
          ctx.beginPath();
          ctx.moveTo(b.x-dx*sl,b.y-dy*sl); ctx.lineTo(b.x+dx*sl,b.y+dy*sl);
          ctx.strokeStyle=sg; ctx.lineWidth=cr*0.55; ctx.lineCap='round'; ctx.stroke();
        });
      }

      // Photosphere core
      const pg=ctx.createRadialGradient(b.x,b.y,0,b.x,b.y,cr*1.5);
      pg.addColorStop(0, `hsla(${b.h},${Math.max(0,b.s-20)}%,100%,0.92)`);
      pg.addColorStop(0.5,`hsla(${b.h},${b.s}%,${b.l}%,0.80)`);
      pg.addColorStop(1,  `hsla(${b.h},${b.s}%,${b.l}%,0)`);
      ctx.beginPath(); ctx.arc(b.x,b.y,cr*1.5,0,Math.PI*2);
      ctx.fillStyle=pg; ctx.fill();
    }
  }

  // ── Main draw loop ────────────────────────────────────────────────────
  let _wLastFrame = 0;
  const _wFrameMs = 1000 / 30; // cap welcome animation at 30fps
  function draw(now) {
    window._animRafs['welcome'] = requestAnimationFrame(draw);
    if (document.hidden) return; // tab not visible — skip render entirely
    if (now - _wLastFrame < _wFrameMs) return; // throttle to 30fps
    _wLastFrame = now;

    ctx.clearRect(0, 0, W, H);

    // Nebulae (behind everything)
    drawNebulae();

    // Stars
    for (const s of stars) drawStar(s, t);

    // Shooting stars
    if (t - lastShoot > 280 + Math.random() * 400) {
      spawnShootingStar();
      lastShoot = t;
    }
    shootingStars = shootingStars.filter(ss => ss.life > 0);
    for (const ss of shootingStars) {
      drawShootingStar(ss);
      ss.x += ss.vx;
      ss.y += ss.vy;
      ss.life -= ss.decay;
    }

    // N-body orbital system
    physicsStep();
    drawBodies();

    t += 1;
  }
  window._animRafs['welcome'] = requestAnimationFrame(draw);
}

function initUltraBotanical(canvas) {
  const ctx = canvas.getContext('2d', {alpha: false});
  ctx.imageSmoothingEnabled = false;
  const isMobile = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);
  const dpr = isMobile ? 1 : Math.min(window.devicePixelRatio || 1, 2);
  let W, H, t = 0;

  // ── PRNG seeded for deterministic botanical ──────────────────────────
  let seed = 137;
  const rnd  = () => { seed=(seed*1664525+1013904223)&0xffffffff; return (seed>>>0)/0xffffffff; };
  const rndR = (a,b) => a + rnd()*(b-a);

  // ── Spectral types (same as home) ────────────────────────────────────
  const SPECTRAL = [
    {h:220,s:60,lMin:92,lMax:100,prob:0.04},
    {h:210,s:40,lMin:90,lMax:98, prob:0.08},
    {h:200,s:20,lMin:90,lMax:97, prob:0.13},
    {h:55, s:30,lMin:88,lMax:96, prob:0.17},
    {h:48, s:55,lMin:82,lMax:92, prob:0.27},
    {h:30, s:65,lMin:70,lMax:85, prob:0.19},
    {h:10, s:70,lMin:55,lMax:75, prob:0.12},
  ];
  function pickSp() {
    let r=Math.random(), acc=0;
    for (const s of SPECTRAL) { acc+=s.prob; if (r<acc) return s; }
    return SPECTRAL[4];
  }

  // ── Gravitational background stars ──────────────────────────────────
  // Small distant stars with different masses → different orbital speeds
  // Physics: F = G·M/r² with softening, each star attracted to a central mass
  const SG_G = 0.0022, SG_EPS2 = 800, SG_DRAG = 0.9998;
  let gravStars = [], _tinybatch = null;

  // Trail buffer canvas — drawn additively, fades slowly each frame
  // This creates persistent glowing orbital paths / geometric patterns
  let trailCanvas, trailCtx;

  function initTrailCanvas() {
    trailCanvas = document.createElement('canvas');
    trailCanvas.width  = W * dpr;
    trailCanvas.height = H * dpr;
    trailCtx = trailCanvas.getContext('2d', {willReadFrequently: false, alpha: true});
    trailCtx.scale(dpr, dpr);
  }

  function buildGravStars() {
    gravStars = [];
    const cx = W * 0.5, cy = H * 0.5;
    const centralMass = 12000;
    // Fewer stars but each draws a beautiful trail — quality over quantity
    const N = Math.min(70, Math.floor(W * H * 0.00010));
    for (let i = 0; i < N; i++) {
      const sp = pickSp();
      const mass = 0.5 + Math.random() * Math.random() * 80;
      const r = 0.15 + Math.pow(mass / 80, 0.35) * 0.55;
      const baseAlpha = 0.25 + Math.random() * 0.45;
      const dist = Math.min(W, H) * (0.08 + Math.random() * 0.58);
      const ang = Math.random() * Math.PI * 2;
      const v = Math.sqrt(SG_G * centralMass / (dist + 1)) * (0.9 + Math.random() * 0.8);
      const dir = Math.random() < 0.5 ? 1 : -1;
      gravStars.push({
        x: cx + Math.cos(ang) * dist,
        y: cy + Math.sin(ang) * dist,
        vx: -Math.sin(ang) * v * dir + (Math.random() - 0.5) * 0.25,
        vy:  Math.cos(ang) * v * dir + (Math.random() - 0.5) * 0.25,
        mass,
        r,
        h: sp.h + (Math.random() - 0.5) * 14,
        s: sp.s,
        l: sp.lMin + Math.random() * (sp.lMax - sp.lMin),
        alpha: baseAlpha,
        tw: { spd: 0.01 + Math.random() * 0.025, amp: 0.05 + mass / 80 * 0.10, ph: Math.random() * Math.PI * 2 },
        prevX: null, prevY: null,
      });
    }
    // Reset trail canvas when rebuilding
    if (trailCtx) trailCtx.clearRect(0, 0, W, H);
  }

  function stepGravStars() {
    const cx = W * 0.5, cy = H * 0.5;
    const centralMass = 12000;
    for (const s of gravStars) {
      s.prevX = s.x; s.prevY = s.y;
      const dx = cx - s.x, dy = cy - s.y;
      const d2 = dx * dx + dy * dy + SG_EPS2;
      const d  = Math.sqrt(d2);
      const f  = SG_G * centralMass / d2;
      s.vx = (s.vx + f * dx / d) * SG_DRAG;
      s.vy = (s.vy + f * dy / d) * SG_DRAG;
      s.x += s.vx;
      s.y += s.vy;
      // soft wrap
      const margin = 40;
      if (s.x < -margin) { s.x = W + margin; s.prevX = null; }
      else if (s.x > W + margin) { s.x = -margin; s.prevX = null; }
      if (s.y < -margin) { s.y = H + margin; s.prevY = null; }
      else if (s.y > H + margin) { s.y = -margin; s.prevY = null; }
    }
  }

  function drawGravStars() {
    if (!trailCanvas) return;

    // 1. Fade the trail buffer very slowly — longer fade = more geometric pattern visible
    trailCtx.globalCompositeOperation = 'source-over';
    trailCtx.fillStyle = 'rgba(2,6,20,0.032)'; // faster fade → better perf, still geometric
    trailCtx.fillRect(0, 0, W, H);

    // 2. Paint new trail segments onto the buffer
    trailCtx.globalCompositeOperation = 'lighter'; // additive glow where paths cross
    for (const s of gravStars) {
      // Skip if no previous position or if star just wrapped across screen edge
      if (s.prevX === null || s.prevY === null) continue;
      // Skip if segment is suspiciously long (wrap artifact) — max allowed jump is ~8% of screen
      const dx = s.x - s.prevX, dy = s.y - s.prevY;
      const segLen = Math.hypot(dx, dy);
      if (segLen > Math.min(W, H) * 0.08 || segLen < 0.01) continue;

      const speed = Math.hypot(s.vx, s.vy);
      const tw = 1 + s.tw.amp * Math.sin(t * s.tw.spd + s.tw.ph);
      const alpha = Math.min(0.55, s.alpha * tw * (0.4 + speed * 8));
      const lineW = s.r * (0.6 + speed * 4);

      // White pulsing trails — hue desaturated toward white, brightness pulses with t
      const pulse = 0.55 + 0.45 * Math.sin(t * 0.04 + s.tw.ph);
      const trailAlpha = alpha * pulse;
      const trailL = Math.min(100, s.l + 30); // push toward white
      trailCtx.beginPath();
      trailCtx.moveTo(s.prevX, s.prevY);
      trailCtx.lineTo(s.x, s.y);
      trailCtx.strokeStyle = `rgba(255,255,255,${trailAlpha})`;
      trailCtx.lineWidth = Math.max(0.4, lineW * pulse);
      trailCtx.lineCap = 'round';
      trailCtx.stroke();
    }
    trailCtx.globalCompositeOperation = 'source-over';

    // 3. Composite trail buffer onto main canvas
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.drawImage(trailCanvas, 0, 0, W, H);
    ctx.restore();

    // 4. Draw star cores on top (bright head of each trail)
    for (const s of gravStars) {
      const tw = 1 + s.tw.amp * Math.sin(t * s.tw.spd + s.tw.ph);
      const alpha = Math.max(0, Math.min(0.9, s.alpha * tw));
      const r = s.r * (0.92 + 0.08 * tw);
      // Simple bright dot — skip heavy radial gradients for speed
      ctx.beginPath(); ctx.arc(s.x, s.y, Math.max(0.5, r * 1.2), 0, Math.PI * 2);
      ctx.fillStyle = `hsla(${s.h},${Math.max(0,s.s-10)}%,98%,${alpha})`;
      ctx.fill();
    }
  }

  // ── Botanical geometry — precomputed once ────────────────────────────
  // We store the botanical draw instructions so we can replay each frame.
  // (All randomness uses seeded rnd() so it's identical every frame.)
  let botStars = [], botNebulas, botStems, botLotuses, botFireflies;

  function precompute() {
    seed = 137; // reset seed for determinism

    // Background nebulas
    botNebulas = [
      {x:0.18,y:0.12,rx:0.35,ry:0.22,c:'30,80,60',a:0.18},
      {x:0.75,y:0.08,rx:0.28,ry:0.18,c:'60,20,90',a:0.20},
      {x:0.5, y:0.35,rx:0.55,ry:0.30,c:'10,40,70',a:0.14},
      {x:0.85,y:0.45,rx:0.22,ry:0.35,c:'80,20,60',a:0.16},
      {x:0.10,y:0.55,rx:0.30,ry:0.40,c:'20,60,40',a:0.12},
    ];

    // Animated star field (same system as home — OBAFGKM with twinkle)
    botStars = [];
    const count = Math.floor(W*H*0.0008);
    for (let i=0; i<count; i++) {
      const sp  = pickSp();
      const mag = Math.random();
      const r   = mag<0.03 ? 1.1+Math.random()*0.6
                : mag<0.13 ? 0.55+Math.random()*0.45
                :             0.15+Math.random()*0.28;
      const baseAlpha = mag<0.03 ? 0.70+Math.random()*0.20
                      : mag<0.13 ? 0.40+Math.random()*0.25
                      :             0.10+Math.random()*0.25;
      botStars.push({
        x: Math.random()*W, y: Math.random()*H, r,
        h: sp.h+(Math.random()-0.5)*14, s: sp.s,
        l: sp.lMin+Math.random()*(sp.lMax-sp.lMin),
        alpha: baseAlpha,
        tw1:{spd:0.025+Math.random()*0.06, amp:0.05+Math.random()*0.09, ph:Math.random()*Math.PI*2},
        tw2:{spd:0.007+Math.random()*0.014,amp:0.03+Math.random()*0.07, ph:Math.random()*Math.PI*2},
        spikes: r>1.0,
        colShift: r>0.8 ? (Math.random()-0.5)*18 : 0,
      });
    }
    botStars.sort((a,b)=>a.r-b.r);

    botStems = [];
    botLotuses = [];

    // Fireflies/stardust — precompute positions using seeded rnd
    botFireflies = [];
    for (let i=0;i<30;i++) {
      botFireflies.push({
        px: rnd()*W, py: rndR(H*0.1,H*0.95),
        r: rnd()*1.4+0.3, op: rnd()*0.65+0.25, gold: rnd()>0.45,
      });
    }
  }

  // ── Draw botanical background layers ─────────────────────────────────
  function drawBotanical() {
    // 1. Background gradient
    const bg=ctx.createRadialGradient(W*0.3,H*0.15,0,W*0.5,H*0.55,H*1.2);
    bg.addColorStop(0,'#0a1a2e'); bg.addColorStop(0.2,'#0d1e18');
    bg.addColorStop(0.5,'#050d10'); bg.addColorStop(0.8,'#030608');
    bg.addColorStop(1,'#010102');
    ctx.fillStyle=bg; ctx.fillRect(0,0,W,H);

    // 2. Nebulas
    for (const n of botNebulas) {
      ctx.save(); ctx.translate(n.x*W,n.y*H); ctx.scale(1,n.ry/n.rx);
      const ng=ctx.createRadialGradient(0,0,0,0,0,n.rx*W);
      ng.addColorStop(0,`rgba(${n.c},${n.a})`);
      ng.addColorStop(0.5,`rgba(${n.c},${n.a*0.4})`);
      ng.addColorStop(1,'rgba(0,0,0,0)');
      ctx.beginPath(); ctx.arc(0,0,n.rx*W,0,Math.PI*2);
      ctx.fillStyle=ng; ctx.fill(); ctx.restore();
    }
  }

  // ── Draw animated starfield (OBAFGKM, twinkle, spikes) ───────────────
  function drawStars() {
    for (const s of botStars) {
      const tw = 1
        + s.tw1.amp*Math.sin(t*s.tw1.spd+s.tw1.ph)
        + s.tw2.amp*Math.sin(t*s.tw2.spd+s.tw2.ph);
      const alpha = Math.max(0,Math.min(1,s.alpha*tw));
      const r     = s.r*(0.90+0.10*tw);
      const hue   = s.h + s.colShift*Math.sin(t*0.035+s.tw1.ph);

      // Tiny/dim stars: batch into single path per colour bucket (huge fillStyle savings)
      if (r < 0.4 || alpha < 0.15) {
        // Round hue to nearest 30° and alpha to 2 decimals to enable batching
        const hk = Math.round(hue/30)*30, ak = Math.round(alpha*10)/10;
        const key = `${hk},${s.s},${s.l},${ak}`;
        if (!_tinybatch) _tinybatch = {};
        if (!_tinybatch[key]) _tinybatch[key] = {style:`hsla(${hk},${s.s}%,${s.l}%,${ak})`, pts:[]};
        _tinybatch[key].pts.push([s.x, s.y, Math.max(0.3, r)]);
        continue;
      }

      // Glow only for stars large enough to matter visually
      if (r > 0.55) {
        const glowR=r*(s.spikes?7:4);
        const g=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,glowR);
        g.addColorStop(0,`hsla(${hue},${s.s}%,${s.l}%,${alpha*0.25})`);
        g.addColorStop(1,`hsla(${hue},${s.s}%,${s.l}%,0)`);
        ctx.beginPath(); ctx.arc(s.x,s.y,glowR,0,Math.PI*2);
        ctx.fillStyle=g; ctx.fill();
      }
      // Spikes only for truly bright stars
      if (s.spikes && alpha>0.5) {
        const sl=r*11*tw, sa=alpha*0.18;
        [[1,0],[0,1]].forEach(([dx,dy])=>{
          const sg=ctx.createLinearGradient(s.x-dx*sl,s.y-dy*sl,s.x+dx*sl,s.y+dy*sl);
          sg.addColorStop(0,`hsla(${hue},${s.s}%,${s.l}%,0)`);
          sg.addColorStop(0.5,`hsla(${hue},${s.s}%,${s.l}%,${sa*1.4})`);
          sg.addColorStop(1,`hsla(${hue},${s.s}%,${s.l}%,0)`);
          ctx.beginPath(); ctx.moveTo(s.x-dx*sl,s.y-dy*sl); ctx.lineTo(s.x+dx*sl,s.y+dy*sl);
          ctx.strokeStyle=sg; ctx.lineWidth=r*0.6; ctx.lineCap='round'; ctx.stroke();
        });
      }
      // Core gradient only for visible stars
      const cg=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,r*1.3);
      cg.addColorStop(0,`hsla(${hue},${Math.max(0,s.s-20)}%,100%,${alpha})`);
      cg.addColorStop(1,`hsla(${hue},${s.s}%,${s.l}%,0)`);
      ctx.beginPath(); ctx.arc(s.x,s.y,r*1.3,0,Math.PI*2);
      ctx.fillStyle=cg; ctx.fill();
    }
  }

  // ── Draw botanical overlay (vines + lotuses + fireflies) ─────────────
  let _overlayOffscreen = null, _overlayNeedsRebuild = true;

  function drawBotOverlay() {
    // Serve from cache — rebuild only when flagged (resize, first frame)
    if (!_overlayNeedsRebuild && _overlayOffscreen) {
      ctx.drawImage(_overlayOffscreen, 0, 0, W, H);
      return;
    }
    // Build offscreen cache
    _overlayOffscreen = document.createElement('canvas');
    _overlayOffscreen.width  = W * dpr;
    _overlayOffscreen.height = H * dpr;
    const oc = _overlayOffscreen.getContext('2d');
    oc.scale(dpr, dpr);
    _drawBotOverlayToCtx(oc);
    _overlayNeedsRebuild = false;
    ctx.drawImage(_overlayOffscreen, 0, 0, W, H);
  }

  function _drawBotOverlayToCtx(ctx) {
    seed = 137; // reset so tendril/leaf rnd() is deterministic each frame

    // Fireflies
    for (const f of botFireflies) {
      ctx.beginPath(); ctx.arc(f.px,f.py,f.r,0,Math.PI*2);
      ctx.fillStyle=f.gold?`rgba(255,225,90,${f.op})`:`rgba(160,255,190,${f.op*0.7})`; ctx.fill();
      if(f.r>0.9){
        const gf=ctx.createRadialGradient(f.px,f.py,0,f.px,f.py,f.r*5);
        gf.addColorStop(0,f.gold?`rgba(255,210,60,${f.op*0.35})`:`rgba(130,255,170,${f.op*0.25})`);
        gf.addColorStop(1,'rgba(0,0,0,0)');
        ctx.beginPath(); ctx.arc(f.px,f.py,f.r*5,0,Math.PI*2); ctx.fillStyle=gf; ctx.fill();
      }
    }

    // Vignette + ground mist
    const fog=ctx.createLinearGradient(0,H*0.65,0,H);
    fog.addColorStop(0,'rgba(0,0,0,0)'); fog.addColorStop(0.6,'rgba(2,10,4,0.55)'); fog.addColorStop(1,'rgba(1,5,2,0.88)');
    ctx.fillStyle=fog; ctx.fillRect(0,H*0.65,W,H*0.35);
    // Perspective top fade — stronger at top to sell the "looking down" effect
    const topFade=ctx.createLinearGradient(0,0,0,H*0.65);
    topFade.addColorStop(0,'rgba(1,4,2,0.82)');
    topFade.addColorStop(0.35,'rgba(1,4,2,0.40)');
    topFade.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=topFade; ctx.fillRect(0,0,W,H*0.65);
    const vig=ctx.createRadialGradient(W*0.5,H*0.5,H*0.22,W*0.5,H*0.5,H*0.95);
    vig.addColorStop(0,'rgba(0,0,0,0)'); vig.addColorStop(1,'rgba(0,3,2,0.75)');
    ctx.fillStyle=vig; ctx.fillRect(0,0,W,H);
  } // end _drawBotOverlayToCtx

  // ── N-body physics (same as home) ────────────────────────────────────
  const GC=0.016, EP2=200, DG=0.9998;
  const SPb=[
    {h:220,s:55,lMin:92,lMax:100},{h:48,s:50,lMin:82,lMax:92},
    {h:10,s:65,lMin:60,lMax:78},{h:200,s:25,lMin:88,lMax:96},
    {h:30,s:60,lMin:72,lMax:86},
  ];
  let bodies=[];
  function buildBodies() {
    bodies=[];
    const cx=W/2,cy=H/2;
    const sunMass=700+Math.random()*200,sp0=SPb[1];
    bodies.push({x:cx+(Math.random()-0.5)*W*0.08,y:cy+(Math.random()-0.5)*H*0.08,
      vx:(Math.random()-0.5)*0.12,vy:(Math.random()-0.5)*0.12,
      mass:sunMass,r:1.4,isSun:true,
      h:sp0.h,s:sp0.s,l:sp0.lMin+Math.random()*(sp0.lMax-sp0.lMin),
      trail:[],trailMax:60,pulse:Math.random()*Math.PI*2});
    const N=6+Math.floor(Math.random()*2);
    for(let i=0;i<N;i++){
      const ang=(i/N)*Math.PI*2+(Math.random()-0.5)*0.8;
      const dist=Math.min(W,H)*(0.10+Math.random()*0.35);
      const v=Math.sqrt(GC*sunMass/dist)*(0.5+Math.random()*0.7);
      const dir2=Math.random()<0.5?1:-1;
      const mass=12+Math.random()*40;
      const sp=SPb[Math.floor(Math.random()*SPb.length)];
      bodies.push({x:cx+Math.cos(ang)*dist,y:cy+Math.sin(ang)*dist,
        vx:-Math.sin(ang)*v*dir2,vy:Math.cos(ang)*v*dir2,
        mass,r:0.5+Math.sqrt(mass/22)*0.35,isSun:false,
        h:sp.h+(Math.random()-0.5)*18,s:sp.s,l:sp.lMin+Math.random()*(sp.lMax-sp.lMin),
        trail:[],trailMax:60+Math.floor(Math.random()*65),pulse:Math.random()*Math.PI*2});
    }
  }

  function physicsStep() {
    for(let i=0;i<bodies.length;i++){
      let ax=0,ay=0;
      for(let j=0;j<bodies.length;j++){
        if(i===j) continue;
        const dx=bodies[j].x-bodies[i].x,dy=bodies[j].y-bodies[i].y;
        const d2=dx*dx+dy*dy+EP2,d=Math.sqrt(d2);
        const f=GC*bodies[j].mass/d2;
        ax+=f*dx/d; ay+=f*dy/d;
      }
      const tx=W/2-bodies[i].x,ty=H/2-bodies[i].y,td=Math.sqrt(tx*tx+ty*ty)+1;
      ax+=tx/td*0.00035; ay+=ty/td*0.00035;
      bodies[i].vx=(bodies[i].vx+ax)*DG; bodies[i].vy=(bodies[i].vy+ay)*DG;
    }
    for(const b of bodies){
      b.x+=b.vx; b.y+=b.vy;
      b.trail.push({x:b.x,y:b.y});
      if(b.trail.length>b.trailMax) b.trail.shift();
    }
  }

  function drawBodies() {
    for(const b of bodies){
      if(b.trail.length>2){
        ctx.beginPath(); ctx.moveTo(b.trail[0].x,b.trail[0].y);
        for(let i=1;i<b.trail.length;i++) ctx.lineTo(b.trail[i].x,b.trail[i].y);
        const t0=b.trail[0],t1=b.trail[b.trail.length-1];
        const tg=ctx.createLinearGradient(t0.x,t0.y,t1.x,t1.y);
        const ta=b.isSun?0.08:0.22;
        tg.addColorStop(0,`hsla(${b.h},${b.s}%,75%,0)`);
        tg.addColorStop(0.5,`hsla(${b.h},${b.s}%,80%,${ta*0.4})`);
        tg.addColorStop(1,`hsla(${b.h},${b.s}%,85%,${ta})`);
        ctx.strokeStyle=tg; ctx.lineWidth=b.isSun?0.6:0.5;
        ctx.lineCap='round'; ctx.lineJoin='round'; ctx.stroke();
      }
      const pulse=0.5+0.5*Math.sin(t*0.025+b.pulse);
      const cr=b.r*(0.9+0.1*pulse);
      const coronaR=cr*(b.isSun?12:8);
      const cg=ctx.createRadialGradient(b.x,b.y,0,b.x,b.y,coronaR);
      cg.addColorStop(0,`hsla(${b.h},${b.s}%,${b.l}%,${(b.isSun?0.18:0.12)+0.06*pulse})`);
      cg.addColorStop(0.4,`hsla(${b.h},${b.s}%,${b.l}%,${0.04*pulse})`);
      cg.addColorStop(1,`hsla(${b.h},${b.s}%,${b.l}%,0)`);
      ctx.beginPath(); ctx.arc(b.x,b.y,coronaR,0,Math.PI*2); ctx.fillStyle=cg; ctx.fill();
      if(b.isSun && b.r>0.9){
        const sl=cr*14*(0.85+0.15*pulse),sa=0.28+0.08*pulse;
        [[1,0],[0,1]].forEach(([dx,dy])=>{
          const sg=ctx.createLinearGradient(b.x-dx*sl,b.y-dy*sl,b.x+dx*sl,b.y+dy*sl);
          sg.addColorStop(0,`hsla(${b.h},${b.s}%,${b.l}%,0)`);
          sg.addColorStop(0.44,`hsla(${b.h},${b.s}%,${b.l}%,${sa*0.7})`);
          sg.addColorStop(0.5,`hsla(${b.h},${b.s}%,${b.l}%,${sa})`);
          sg.addColorStop(0.56,`hsla(${b.h},${b.s}%,${b.l}%,${sa*0.7})`);
          sg.addColorStop(1,`hsla(${b.h},${b.s}%,${b.l}%,0)`);
          ctx.beginPath(); ctx.moveTo(b.x-dx*sl,b.y-dy*sl); ctx.lineTo(b.x+dx*sl,b.y+dy*sl);
          ctx.strokeStyle=sg; ctx.lineWidth=cr*0.55; ctx.lineCap='round'; ctx.stroke();
        });
      }
      const pg=ctx.createRadialGradient(b.x,b.y,0,b.x,b.y,cr*1.5);
      pg.addColorStop(0,`hsla(${b.h},${Math.max(0,b.s-20)}%,100%,0.92)`);
      pg.addColorStop(0.5,`hsla(${b.h},${b.s}%,${b.l}%,0.80)`);
      pg.addColorStop(1,`hsla(${b.h},${b.s}%,${b.l}%,0)`);
      ctx.beginPath(); ctx.arc(b.x,b.y,cr*1.5,0,Math.PI*2); ctx.fillStyle=pg; ctx.fill();
    }
  }

  // ── Resize + init ─────────────────────────────────────────────────────
  // ── Adaptive quality based on measured FPS ───────────────────────────
  // Monitors real frame time and silently scales down particle counts
  // when the device can't keep up — no visual jumps, just fewer stars.
  let _fps = 60, _lastTime = 0, _frameCount = 0, _fpsTimer = 0;
  let _quality = 1.0; // 1.0 = full, 0.6 = medium, 0.35 = low

  function _measureFPS(now) {
    _frameCount++;
    if (now - _fpsTimer >= 2000) { // sample every 2s
      _fps = _frameCount / ((now - _fpsTimer) / 1000);
      _frameCount = 0;
      _fpsTimer = now;
      // Smoothly adjust quality target
      if (_fps < 28 && _quality > 0.35) {
        _quality = Math.max(0.35, _quality - 0.15);
        _applyQuality();
      } else if (_fps > 50 && _quality < 1.0) {
        _quality = Math.min(1.0, _quality + 0.10);
        _applyQuality();
      }
    }
  }

  const _baseGravCount = Math.min(70, Math.floor(W * H * 0.00010));
  const _baseBotCount  = Math.floor(W * H * 0.0012);

  function _applyQuality() {
    // Trim grav stars in-place (no rebuild, no visual pop)
    const targetG = Math.max(20, Math.floor(_baseGravCount * _quality));
    if (gravStars.length > targetG) gravStars.length = targetG;
    // Trim bot stars
    const targetB = Math.max(80, Math.floor(_baseBotCount * _quality));
    if (botStars.length > targetB) botStars.length = targetB;
  }

  // ── Botanical background cache ────────────────────────────────────────
  // drawBotanical() is pure static color — pre-render once, blit each frame
  let _bgCache = null;
  function _buildBgCache() {
    _bgCache = document.createElement('canvas');
    _bgCache.width = W * dpr; _bgCache.height = H * dpr;
    const bctx = _bgCache.getContext('2d');
    bctx.scale(dpr, dpr);
    // replicate drawBotanical onto cache
    const bg = bctx.createRadialGradient(W*0.3,H*0.15,0,W*0.5,H*0.55,H*1.2);
    bg.addColorStop(0,'#0a1a2e'); bg.addColorStop(0.2,'#0d1e18');
    bg.addColorStop(0.5,'#050d10'); bg.addColorStop(0.8,'#030608');
    bg.addColorStop(1,'#010102');
    bctx.fillStyle = bg; bctx.fillRect(0,0,W,H);
    for (const n of botNebulas) {
      bctx.save(); bctx.translate(n.x*W,n.y*H); bctx.scale(1,n.ry/n.rx);
      const ng = bctx.createRadialGradient(0,0,0,0,0,n.rx*W);
      ng.addColorStop(0,`rgba(${n.c},${n.a})`);
      ng.addColorStop(0.5,`rgba(${n.c},${n.a*0.4})`);
      ng.addColorStop(1,'rgba(0,0,0,0)');
      bctx.beginPath(); bctx.arc(0,0,n.rx*W,0,Math.PI*2);
      bctx.fillStyle=ng; bctx.fill(); bctx.restore();
    }
  }



  function resize() {
    W = canvas.offsetWidth  || window.innerWidth;
    H = canvas.offsetHeight || window.innerHeight;
    canvas.width  = W*dpr; canvas.height = H*dpr;
    ctx.scale(dpr, dpr);
    initTrailCanvas();
    precompute();
    _buildBgCache();   // cache static bg after precompute sets botNebulas
    buildBodies();
    buildGravStars();
    _fpsTimer = performance.now(); _frameCount = 0;
    _overlayNeedsRebuild = true;
  }
  resize();
  window.addEventListener('resize', resize);

  // ── Main loop ─────────────────────────────────────────────────────────
  function draw(now) {
    window._animRafs['splash'] = requestAnimationFrame(draw);
    if (document.hidden) return; // tab not visible — skip render entirely
    _measureFPS(now);
    ctx.clearRect(0,0,W,H);

    // Blit cached background (single drawImage vs many gradient fills)
    if (_bgCache) ctx.drawImage(_bgCache, 0, 0, W, H);
    else drawBotanical();

    if (t % 2 === 0) stepGravStars(); // physics every other frame — imperceptible
    drawGravStars();
    _tinybatch = {};
    drawStars();
    // Flush tiny star batches — one path per colour bucket instead of one per star
    if (_tinybatch) {
      for (const b of Object.values(_tinybatch)) {
        ctx.fillStyle = b.style;
        ctx.beginPath();
        for (const [bx,by,br] of b.pts) { ctx.moveTo(bx+br,by); ctx.arc(bx,by,br,0,Math.PI*2); }
        ctx.fill();
      }
    }
    drawBotOverlay();
    physicsStep();
    drawBodies();
    t++;
  }
  window._animRafs['splash'] = requestAnimationFrame(draw);

  window._stopBotanicalSplash = function() {
    cancelAnimationFrame(window._animRafs['splash']);
    delete window._animRafs['splash'];
    cancelAnimationFrame(window._animRafs['splashspiral']);
    delete window._animRafs['splashspiral'];
  };
}

function initUnlockStars() {
  const canvas = document.getElementById('unlockCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const stars = Array.from({ length: 120 }, () => ({
    x: Math.random(), y: Math.random(),
    r: Math.random() * 1.5 + 0.3,
    speed: Math.random() * 0.003 + 0.001,
    phase: Math.random() * Math.PI * 2
  }));
  let t = 0;

  function resize() {
    canvas.width = canvas.offsetWidth * (window.devicePixelRatio || 1);
    canvas.height = canvas.offsetHeight * (window.devicePixelRatio || 1);
    ctx.scale(window.devicePixelRatio || 1, window.devicePixelRatio || 1);
  }
  resize();

  function draw() {
    ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);
    stars.forEach(s => {
      const opacity = (Math.sin(t * s.speed * 100 + s.phase) + 1) / 2 * 0.6 + 0.1;
      ctx.beginPath();
      ctx.arc(s.x * canvas.offsetWidth, s.y * canvas.offsetHeight, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,255,255,${opacity})`;
      ctx.fill();
    });
    t += 0.02;
    window._animRafs['unlock'] = requestAnimationFrame(draw);
  }
  window._animRafs['unlock'] = requestAnimationFrame(draw);
}


// ══════════════════════════════════════════
//  NEON SPIRAL LOGO (welcome screen)
// ══════════════════════════════════════════
function initNeonSpiralLogo(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const S = 320;
  canvas.width = S; canvas.height = S;
  const ctx = canvas.getContext('2d');
  const cx = S/2, cy = S/2;
  const turns = 2.2, maxR = S * 0.32, minR = S * 0.03, steps = 1200;
  const pts = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const angle = t * turns * Math.PI * 2 - Math.PI * 0.5;
    const r = minR + (maxR - minR) * t;
    pts.push({ x: cx + Math.cos(angle) * r, y: cy + Math.sin(angle) * r, t });
  }
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.shadowColor = 'rgba(0,200,40,0.20)'; ctx.shadowBlur = 6;
  for (let i = 0; i < steps; i++) {
    const t = i / steps;
    const endTaper = t > 0.90 ? Math.sin((1 - t) / 0.10 * Math.PI * 0.5) : 1.0;
    const lw = 3.0 + endTaper * 5.5;
    const alpha = 0.65 + endTaper * 0.27;
    const green = Math.floor(190 + endTaper * 20);
    ctx.strokeStyle = `rgba(0,${green},42,${alpha})`;
    ctx.lineWidth = lw;
    ctx.beginPath();
    ctx.moveTo(pts[i].x, pts[i].y);
    ctx.lineTo(pts[i+1].x, pts[i+1].y);
    ctx.stroke();
  }
  ctx.shadowBlur = 0;
}

function initSmallSpiral(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const S = parseInt(canvas.getAttribute('width')) || 28;
  canvas.width = S; canvas.height = S;
  const ctx = canvas.getContext('2d');
  let phase = 0;
  function draw() {
    ctx.clearRect(0, 0, S, S);
    const cx = S/2, cy = S/2;
    const turns = 2.6;
    const maxR = S * 0.40;
    const minR = 0.5;
    const steps = 350;
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const t = (i / steps) * turns * Math.PI * 2 + phase * 0.4;
      const r = minR + (maxR - minR) * Math.pow(i / steps, 0.85);
      pts.push({ x: cx + Math.cos(t - Math.PI*0.5)*r, y: cy + Math.sin(t - Math.PI*0.5)*r });
    }
    function drawPath() {
      ctx.beginPath();
      pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    }
    const pulse = 0.85 + Math.sin(phase * 1.1) * 0.15;
    ctx.globalAlpha = 0.18 * pulse; ctx.shadowColor = 'rgba(27,154,170,1)'; ctx.shadowBlur = 7;
    drawPath(); ctx.strokeStyle = 'rgba(0,160,200,1)'; ctx.lineWidth = 4; ctx.lineCap = 'round'; ctx.stroke();
    ctx.globalAlpha = 0.38 * pulse; ctx.shadowBlur = 3;
    drawPath(); ctx.strokeStyle = 'rgba(27,154,170,1)'; ctx.lineWidth = 2.2; ctx.stroke();
    ctx.globalAlpha = 0.88 * pulse; ctx.shadowColor = 'rgba(72,202,228,1)'; ctx.shadowBlur = 2;
    drawPath(); ctx.strokeStyle = 'rgba(48,190,220,1)'; ctx.lineWidth = 1.1; ctx.stroke();
    ctx.globalAlpha = 1.0; ctx.shadowColor = 'rgba(180,240,255,1)'; ctx.shadowBlur = 1;
    drawPath(); ctx.strokeStyle = 'rgba(150,235,255,1)'; ctx.lineWidth = 0.45; ctx.stroke();
    ctx.shadowBlur = 0; ctx.globalAlpha = 1;
    phase += 0.018;
    window._animRafs['smallspiral'] = requestAnimationFrame(draw);
  }
  window._animRafs['smallspiral'] = requestAnimationFrame(draw);
}

// ══════════════════════════════════════════
//  BOOT
// ══════════════════════════════════════════

// ── VISUAL DEBUG ──────────────────────────────────────────────
let _debugLines = [];
function dbg(msg) {
  const t = new Date().toLocaleTimeString('it',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
  _debugLines.push(t + ' ' + msg);
  if (_debugLines.length > 80) _debugLines.shift();
  const el = document.getElementById('debugPanel');
  if (el && el.style.display !== 'none') {
    el.innerHTML = _debugLines.map(l => '<div>' + l + '</div>').join('');
    el.scrollTop = el.scrollHeight;
  }
}
function toggleDebug() {
  const el = document.getElementById('debugPanel');
  if (!el) return;
  el.style.display = el.style.display === 'none' ? 'block' : 'none';
  if (el.style.display === 'block') {
    el.innerHTML = _debugLines.map(l => '<div>' + l + '</div>').join('');
    el.scrollTop = el.scrollHeight;
  }
}
window.toggleDebug = toggleDebug;

// ══════════════════════════════════════════════════════
