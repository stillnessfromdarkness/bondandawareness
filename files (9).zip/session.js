//  SESSION SUMMARY — 20-minute timer + UI
// ══════════════════════════════════════════════════════
(function() {

  const SESSION_MS = 20 * 60 * 1000; // 20 minutes
  let _ssTimer       = null;
  let _ssShown       = false;
  let _ssThoughtOpen = false;
  let _ssOpenPopup   = null; // currently open profile popup

  /* ── Start the 20-min countdown ── */
  function startSessionSummaryTimer() {
    stopSessionSummaryTimer();
    _ssShown = false;
    _ssTimer = setTimeout(showSessionSummary, SESSION_MS);
  }
  function stopSessionSummaryTimer() {
    if (_ssTimer) { clearTimeout(_ssTimer); _ssTimer = null; }
  }

  /* ─────────────────────────────────────────────────
     AVATAR helpers
  ───────────────────────────────────────────────── */

  // Gradient palettes per initial
  const _gradients = [
    ['#1B9AAA','#9B5DE5'], ['#9B5DE5','#F72585'],
    ['#F72585','#FB8500'], ['#48CAE4','#1B9AAA'],
    ['#06D6A0','#118AB2'], ['#FFB703','#FB8500'],
  ];
  function _gradientFor(name) {
    let h = 0;
    for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) & 0xFFFFFF;
    return _gradients[h % _gradients.length];
  }

  /* Get avatar URL for a given player name.
     - If it's "me" (logged in) → use Google/Supabase avatar
     - Otherwise → null (will render initials)                  */
  function _avatarUrl(name) {
    const cu = (typeof currentUser !== 'undefined') ? currentUser : null;
    const lp = (typeof _localProfile !== 'undefined') ? _localProfile : null;
    const myName = lp?.username || cu?.user_metadata?.full_name || cu?.user_metadata?.display_name || state.playerName || '';
    if (name && myName && name.trim().toLowerCase() === myName.trim().toLowerCase()) {
      // Try Google OAuth avatar
      return cu?.user_metadata?.avatar_url || cu?.user_metadata?.picture || null;
    }
    return null;
  }

  /* Build an avatar DOM element */
  function _makeAvatar(name) {
    const wrap = document.createElement('div');
    wrap.className = 'ss-avatar';
    const [c1, c2] = _gradientFor(name || '?');
    wrap.style.background = 'linear-gradient(135deg,' + c1 + ',' + c2 + ')';

    const url = _avatarUrl(name);
    if (url) {
      const img = document.createElement('img');
      img.src = url;
      img.onerror = function() { img.remove(); wrap.textContent = (name||'?').charAt(0).toUpperCase(); };
      wrap.appendChild(img);
    } else {
      wrap.textContent = (name||'?').charAt(0).toUpperCase();
    }
    return wrap;
  }

  /* ─────────────────────────────────────────────────
     Build & show the summary overlay
  ───────────────────────────────────────────────── */
  function showSessionSummary() {
    if (_ssShown) return;
    _ssShown = true;

    const names = _getParticipantNames();
    const container = document.getElementById('ssParticipants');
    if (container) {
      container.innerHTML = '';
      names.forEach(function(name, idx) {
        const wrap = document.createElement('div');
        wrap.className = 'ss-participant';
        wrap.dataset.name = name;

        // Avatar
        wrap.appendChild(_makeAvatar(name));

        // Name label
        const label = document.createElement('div');
        label.className = 'ss-participant-name';
        label.textContent = name;
        wrap.appendChild(label);

        // Profile popup (hidden by default)
        const popup = document.createElement('div');
        popup.className = 'ss-profile-popup';
        popup.id = 'ssPopup_' + idx;
        const popupBtn = document.createElement('button');
        popupBtn.className = 'ss-profile-popup-btn';
        popupBtn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> Profile';
        popupBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          ssOpenUserProfile(name);
        });
        popup.appendChild(popupBtn);
        wrap.appendChild(popup);

        // Toggle popup on click
        wrap.addEventListener('click', function(e) {
          e.stopPropagation();
          const isOpen = popup.classList.contains('ss-popup-open');
          // Close any other open popup
          if (_ssOpenPopup && _ssOpenPopup !== popup) {
            _ssOpenPopup.classList.remove('ss-popup-open');
          }
          popup.classList.toggle('ss-popup-open', !isOpen);
          _ssOpenPopup = !isOpen ? popup : null;
        });

        container.appendChild(wrap);
      });

      // Close popup on outside click
      document.getElementById('sessionSummaryCard').addEventListener('click', function() {
        if (_ssOpenPopup) { _ssOpenPopup.classList.remove('ss-popup-open'); _ssOpenPopup = null; }
      });
    }

    // Reset thought UI
    _ssThoughtOpen = false;
    const input   = document.getElementById('ssThoughtsInput');
    const sendBtn = document.getElementById('ssSendBtn');
    const sentMsg = document.getElementById('ssSentMsg');
    const shareBtn = document.getElementById('ssShareBtn');
    if (input)    { input.value = ''; input.classList.remove('ss-visible'); }
    if (sendBtn)  sendBtn.classList.remove('ss-visible');
    if (sentMsg)  sentMsg.classList.remove('ss-visible');
    if (shareBtn) shareBtn.style.display = '';

    // Clear thoughts feed
    const feed = document.getElementById('ssThoughtsFeed');
    if (feed) { feed.innerHTML = ''; feed.style.display = 'none'; }

    _listenForThoughts();

    const overlay = document.getElementById('sessionSummaryOverlay');
    if (overlay) overlay.classList.add('ss-open');
  }

  /* ─────────────────────────────────────────────────
     Open a user's profile (view-only for others, own for self)
  ───────────────────────────────────────────────── */
  function ssOpenUserProfile(name) {
    // Close popup
    if (_ssOpenPopup) { _ssOpenPopup.classList.remove('ss-popup-open'); _ssOpenPopup = null; }

    const cu = (typeof currentUser !== 'undefined') ? currentUser : null;
    const lp = (typeof _localProfile !== 'undefined') ? _localProfile : null;
    const myName = lp?.username || cu?.user_metadata?.full_name || state.playerName || '';

    if (name.trim().toLowerCase() === myName.trim().toLowerCase()) {
      // It's me — open my profile
      const overlay = document.getElementById('sessionSummaryOverlay');
      if (overlay) overlay.classList.remove('ss-open');
      goTo('profile');
    } else {
      // It's the opponent — show view-only via GPS profile or a simple toast
      if (typeof openGpsProfile === 'function') {
        const overlay = document.getElementById('sessionSummaryOverlay');
        if (overlay) overlay.classList.remove('ss-open');
        openGpsProfile();
      } else {
        showToast('👤 ' + name + '\u2019s profile', 'match-found', 2000);
      }
    }
  }

  /* ─────────────────────────────────────────────────
     Name entry validation (non-logged-in users)
     Intercepts enterGame to check if name is taken
     by a registered Supabase user
  ───────────────────────────────────────────────── */
  async function _isNameTakenByRegisteredUser(name) {
    try {
      if (typeof supabaseClient === 'undefined' || !supabaseClient) return false;
      if (typeof SUPABASE_URL === 'undefined' || SUPABASE_URL === 'https://YOUR_PROJECT_ID.supabase.co') return false;
      const { data } = await supabaseClient
        .from('profiles')
        .select('id')
        .eq('username', name)
        .maybeSingle();
      if (!data) return false;
      // If logged in and it's their own name, it's fine
      const cu = (typeof currentUser !== 'undefined') ? currentUser : null;
      if (cu && data.id === cu.id) return false;
      return true; // another registered user owns this name
    } catch(e) { return false; }
  }

  /* Patch enterGame to skip name entry if logged in,
     and block names owned by registered users           */
  const _origEnterGame = window.enterGame;
  window.enterGame = async function() {
    const cu  = (typeof currentUser !== 'undefined') ? currentUser : null;
    const lp  = (typeof _localProfile !== 'undefined') ? _localProfile : null;
    const input = document.getElementById('playerNameInput');

    // ── Already logged in: skip manual name, use account name ──
    if (cu) {
      const accountName = lp?.username || cu.user_metadata?.full_name || cu.user_metadata?.display_name || cu.email?.split('@')[0];
      if (accountName && input && !input.value.trim()) {
        input.value = accountName;
      }
      // No need to validate — it's their own registered name
      if (_origEnterGame) _origEnterGame.call(this);
      return;
    }

    // ── Guest: check if typed name is taken by a registered user ──
    if (input) {
      const name = input.value.trim();
      if (name) {
        const taken = await _isNameTakenByRegisteredUser(name);
        if (taken) {
          // Show inline error
          input.style.borderColor = 'rgba(255,80,80,0.6)';
          setTimeout(() => { input.style.borderColor = ''; }, 2000);
          showToast('⚠️ "' + name + '" is taken by a registered user — choose another name', 'match-found', 3500);
          return;
        }
      }
    }

    if (_origEnterGame) _origEnterGame.call(this);
  };

  /* ─────────────────────────────────────────────────
     Collect participant names from all game modes
  ───────────────────────────────────────────────── */
  function _getParticipantNames() {
    // Offline/private group mode — authoritative list
    if (typeof offlinePlayers !== 'undefined' && offlinePlayers && offlinePlayers.length > 0) {
      return offlinePlayers.map(function(p) { return p.name || p; }).filter(Boolean);
    }
    // Online mode
    const names = [];
    if (state.playerName)   names.push(state.playerName);
    if (state.opponentName) names.push(state.opponentName);
    return names.filter(function(n, i, a) { return n && a.indexOf(n) === i; });
  }

  /* ── Toggle thoughts textarea ── */
  function ssToggleThoughts() {
    _ssThoughtOpen = !_ssThoughtOpen;
    const input    = document.getElementById('ssThoughtsInput');
    const sendBtn  = document.getElementById('ssSendBtn');
    const shareBtn = document.getElementById('ssShareBtn');
    if (input) input.classList.toggle('ss-visible', _ssThoughtOpen);
    if (_ssThoughtOpen) {
      if (shareBtn) shareBtn.style.display = 'none';
      setTimeout(function() { if (input) input.focus(); }, 80);
    }
    if (sendBtn && input) {
      sendBtn.classList.toggle('ss-visible', _ssThoughtOpen && input.value.trim().length > 0);
    }
  }

  function ssOnInput() {
    const input  = document.getElementById('ssThoughtsInput');
    const sendBtn = document.getElementById('ssSendBtn');
    if (sendBtn && input) {
      sendBtn.classList.toggle('ss-visible', input.value.trim().length > 0);
    }
  }

  /* ── Send thought ── */
  function ssSendThought() {
    const input   = document.getElementById('ssThoughtsInput');
    const sendBtn = document.getElementById('ssSendBtn');
    const sentMsg = document.getElementById('ssSentMsg');
    if (!input || !input.value.trim()) return;
    const text   = input.value.trim();
    const author = state.playerName || 'You';

    if (state.matchId) {
      // FIX: usare _sendBroadcast (con subscribe corretto) invece di canale non-subscribed
      _sendBroadcast('thoughts_' + state.matchId, 'thought', { author, text, ts: Date.now() }).catch(() => {});
    }

    if (input)   { input.classList.remove('ss-visible'); input.value = ''; }
    if (sendBtn) sendBtn.classList.remove('ss-visible');
    if (sentMsg) sentMsg.classList.add('ss-visible');
  }

  /* ── Listen for others' thoughts (online only) ── */
  function _listenForThoughts() {
    if (!state.matchId) return;
    const sb = _sbClient(); if (!sb) return;
    try {
      const ch = sb.channel('thoughts_' + state.matchId)
        .on('broadcast', { event: 'thought' }, ({ payload }) => {
          if (!payload || !payload.text) return;
          if (payload.author === (state.playerName || 'You')) return;
          _addThoughtBubble(payload.author, payload.text);
        }).subscribe();
      state._thoughtsChannel = ch;
    } catch(e) {}
  }

  function _addThoughtBubble(author, text) {
    const feed = document.getElementById('ssThoughtsFeed');
    if (!feed) return;
    feed.style.display = '';
    const bubble = document.createElement('div');
    bubble.className = 'ss-thought-bubble';
    bubble.innerHTML =
      '<div class="ss-thought-name">' + _escHtml(author) + '</div>' +
      '<div class="ss-thought-text">' + _escHtml(text) + '</div>';
    feed.appendChild(bubble);
  }

  /* ── Close / Go home ── */
  function ssCloseSummary() {
    const overlay = document.getElementById('sessionSummaryOverlay');
    if (overlay) overlay.classList.remove('ss-open');
    _ssShown = false;
    startSessionSummaryTimer();
    _cleanupThoughtsListener();
  }

  function ssGoHome() {
    const overlay = document.getElementById('sessionSummaryOverlay');
    if (overlay) overlay.classList.remove('ss-open');
    stopSessionSummaryTimer();
    _cleanupThoughtsListener();
    if (typeof leaveMatch === 'function') leaveMatch();
    goTo('welcome');
  }

  function _cleanupThoughtsListener() {
    if (state._thoughtsChannel) {
      try { _sbClient()?.removeChannel(state._thoughtsChannel); } catch(e) {}
      state._thoughtsChannel = null;
    }
  }

  function _escHtml(s) {
    return String(s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  /* ── Hook into game start ── */
  const _origStartMatch = window.startMatch || function(){};
  window.startMatch = function() {
    _origStartMatch.apply(this, arguments);
    startSessionSummaryTimer();
  };

  const _origStartOffline = window.startOfflineGame || function(){};
  window.startOfflineGame = function() {
    _origStartOffline.apply(this, arguments);
    startSessionSummaryTimer();
  };

  const _origLeaveMatch = window.leaveMatch || function(){};
  window.leaveMatch = function() {
    stopSessionSummaryTimer();
    _origLeaveMatch.apply(this, arguments);
  };

  // Expose
  window.ssToggleThoughts      = ssToggleThoughts;
  window.ssOnInput             = ssOnInput;
  window.ssSendThought         = ssSendThought;
  window.ssCloseSummary        = ssCloseSummary;
  window.ssGoHome              = ssGoHome;
  window.ssOpenUserProfile     = ssOpenUserProfile;
  window.showSessionSummary    = showSessionSummary;
  window.startSessionSummaryTimer = startSessionSummaryTimer;

})();

window.addEventListener('load', function() {
  // ── PWA: Service Worker ────────────────────────────────────────────
  if ('serviceWorker' in navigator) {
    // Inline SW via blob — funziona anche senza server esterno
    const swCode = `
const CACHE = 'bond-v1';
const ASSETS = ['./', './index.html'];
self.addEventListener('install', e => e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).catch(()=>{})));
self.addEventListener('fetch', e => e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)).catch(() => caches.match('./index.html'))));
`;
    const blob = new Blob([swCode], { type: 'application/javascript' });
    const swUrl = URL.createObjectURL(blob);
    navigator.serviceWorker.register(swUrl).catch(() => {});
  }
  // Network listeners gestiti dal set globale registrato a livello di modulo (vedi sopra).
  // Load saved state
  try {
    const saved = localStorage.getItem('playerName');
    if (saved) {
      state.playerName = saved;
      document.getElementById('playerNameInput').value = saved;
    }
    const savedLang = localStorage.getItem('selectedLang');
    if (savedLang) { state.selectedLang = JSON.parse(savedLang); applyUILanguage(state.selectedLang.code); }
    if (localStorage.getItem('isUnlocked') === 'true') state.isUnlocked = true;
  } catch(e) {}

  // ── PRIVATE ROOM: auto-detect ?room=CODE in URL ──────────────────────
  const urlParams = new URLSearchParams(window.location.search);
  const incomingRoom = urlParams.get('room');
  if (incomingRoom) {
    state._pendingRoom = true;
    state._pendingRoomCode = incomingRoom.toUpperCase();

    // Aspetta che auth + profilo siano pronti, poi decide se chiedere il nome
    function _handleIncomingRoom() {
      const savedUsername = getLoggedInName('');
      if (savedUsername) {
        // Utente loggato — usa username direttamente, salta name-entry
        state.playerName = savedUsername;
        try { localStorage.setItem('playerName', savedUsername); } catch(e) {}
        _verifyRoomExists(state._pendingRoomCode);
        _showJoinNameModal(state._pendingRoomCode);
      } else {
        // Guest non loggato — chiedi il nome
        goTo('name-entry');
        const hint = document.querySelector('.name-entry-subtitle');
        if (hint) hint.textContent = 'Enter your name to join the private room';
        _verifyRoomExists(state._pendingRoomCode);
      }
    }

    // Polling finché auth/profilo non è caricato (max ~4 secondi, poi mostra name-entry)
    let _roomAuthAttempts = 0;
    function _waitForProfileThenJoinRoom() {
      const lp = (typeof _localProfile !== 'undefined') ? _localProfile : null;
      const cu = (typeof currentUser !== 'undefined') ? currentUser : null;
      const ready = (lp && lp.username) || (cu && (cu.user_metadata?.full_name || cu.email));
      if (ready || _roomAuthAttempts >= 16) {
        _handleIncomingRoom();
      } else {
        _roomAuthAttempts++;
        setTimeout(_waitForProfileThenJoinRoom, 250);
      }
    }
    setTimeout(_waitForProfileThenJoinRoom, 300);
  }

  // Init splash — delay to ensure DOM layout is complete
  requestAnimationFrame(() => requestAnimationFrame(() => {
    initMandala('splashCanvas');
    // Draw same simple green spiral as question cards
    const splashSpiral = document.getElementById('splashSpiralCanvas');
    if (splashSpiral) requestAnimationFrame(() => drawSpiralIcon(splashSpiral));
  }));

  // Splash: rimane finché non si tocca/clicca — nessun auto-advance
  let splashDone = false;
  async function goToAuth() {
    // Se il guest arriva da link stanza, non sovrascrivere name-entry
    if (state._pendingRoom || state._pendingRoomCode) return;
    if (splashDone) return;
    splashDone = true;
    if (window._stopBotanicalSplash) window._stopBotanicalSplash();
    try {
      // Check if user already has a session
      const existingUser = await checkExistingSession();
      if (existingUser) {
        currentUser = existingUser;
        window._authCompleted = true;
        await loadProfile();
        const name = _localProfile?.username || existingUser.user_metadata?.display_name || existingUser.email?.split('@')[0];
        updateUserPill(existingUser, name);
      }
      // Always go to welcome — auth happens only when Let's Play is tapped
      goTo('welcome');
      setTimeout(() => initMandala('welcomeCanvas'), 50);
      setTimeout(() => initNeonSpiralLogo('logoSpiralCanvas'), 80);
    } catch(e) {
      splashDone = false;
    }
  }
  const splashEl = document.getElementById('splash');
  if (splashEl) {
    splashEl.addEventListener('click', goToAuth);
    splashEl.addEventListener('touchend', function(e) { e.preventDefault(); goToAuth(); });
    // Anche tasto keyboard per desktop
    window.addEventListener('keydown', function onKey(e) {
      if (state.currentScreen !== 'splash') return;
      window.removeEventListener('keydown', onKey);
      goToAuth();
    }, { once: true });
  }
  // ══════════════════════════════════════════
  //  SUPABASE AUTH
  //  Replace these with your actual Supabase credentials
  //  Get them at: https://supabase.com → Your Project → Settings → API
  // ══════════════════════════════════════════
  const SUPABASE_URL = 'https://ughvejlapgbkxlfzegaa.supabase.co';
  const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVnaHZlamxhcGdia3hsZnplZ2FhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIzMTUyMTEsImV4cCI6MjA4Nzg5MTIxMX0.7poKqJUH2ZzXRGXsVB5HZQKYG9ux6m_hOIGk41lh-Hk';

  let supabaseClient = null;
  let currentUser = null;
  window._getCurrentUser = () => currentUser;

  try {
    supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true
      },
      realtime: {
        params: { eventsPerSecond: 10 }
      }
    });
    window.supabaseClient  = supabaseClient;  // expose for matchmaking
    window.SUPABASE_ANON_KEY = SUPABASE_ANON_KEY; // expose for beforeunload cleanup
    window.SUPABASE_URL      = SUPABASE_URL;       // FIX: expose URL for beforeunload (era hardcoded)
  } catch(e) {
    console.warn('Supabase not configured yet — auth disabled');
  }

  // ── Check session on load ──
  async function checkExistingSession() {
    if (!supabaseClient) return null;
    try {
      const { data: { session } } = await supabaseClient.auth.getSession();
      return session?.user || null;
    } catch(e) { return null; }
  }

  // ── Google Auth ──
  async function handleGoogleAuth() {
    if (!supabaseClient) { continueAsGuest(); return; }
    try {
      const { error } = await supabaseClient.auth.signInWithOAuth({
        provider: 'google', options: { redirectTo: 'https://www.bondandawareness.com' }
      });
      if (error) throw error;
    } catch(e) { showToast('Google login not configured yet', 'toast-info'); }
  }
  window.handleGoogleAuth = handleGoogleAuth;

  // ── Email Continue → send OTP ──
  let _otpEmail = '';
  let _demoCode = '';
  async function handleEmailContinue() {
    const email = document.getElementById('auth-email-landing')?.value.trim();
    if (!email || !email.includes('@')) {
      const inp = document.getElementById('auth-email-landing');
      if (inp) { inp.style.borderColor = 'rgba(255,107,107,0.5)'; setTimeout(() => inp.style.borderColor = '', 1500); }
      return;
    }
    const btn = document.getElementById('auth-email-btn');
    if (btn) { btn.disabled = true; btn.textContent = '...'; }
    try {
      if (supabaseClient && SUPABASE_URL !== 'https://YOUR_PROJECT_ID.supabase.co') {
        // Real Supabase
        const { error } = await supabaseClient.auth.signInWithOtp({ email, options: { shouldCreateUser: true, emailRedirectTo: null, data: {} } });
        if (error) throw error;
      } else {
        // Demo mode — generate fake code and log to console
        _demoCode = String(Math.floor(100000 + Math.random() * 900000));
        console.log('%c🔐 DEMO CODE for ' + email + ': ' + _demoCode, 'background:#1B9AAA;color:white;font-size:18px;padding:6px 12px;border-radius:6px;font-weight:bold;');
      }
      _otpEmail = email;
      const display = document.getElementById('otp-email-display');
      if (display) display.textContent = email;
      initOtpBoxes();
      goTo('auth-otp');
      // no stars on otp screen
      setTimeout(() => { document.querySelectorAll('.otp-box')[0]?.focus(); }, 400);
    } catch(e) { showToast(e.message || 'Could not send code', 'toast-info'); }
    if (btn) { btn.disabled = false; btn.textContent = 'Continue with email'; }
  }
  window.handleEmailContinue = handleEmailContinue;

  // ── OTP box keyboard logic ──
  function initOtpBoxes() {
    const boxes = document.querySelectorAll('.otp-box');
    boxes.forEach((box, i) => {
      box.value = ''; box.classList.remove('filled');
      box.oninput = (e) => {
        const val = e.target.value.replace(/\D/g, '');
        box.value = val.slice(-1);
        box.classList.toggle('filled', !!box.value);
        if (box.value && i < boxes.length - 1) boxes[i + 1].focus();
        if ([...boxes].every(b => b.value)) handleVerifyOtp();
      };
      box.onkeydown = (e) => { if (e.key === 'Backspace' && !box.value && i > 0) boxes[i - 1].focus(); };
      box.onpaste = (e) => {
        e.preventDefault();
        const paste = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '');
        boxes.forEach((b, j) => { b.value = paste[j] || ''; b.classList.toggle('filled', !!b.value); });
        if (paste.length >= 6) handleVerifyOtp();
        else boxes[Math.min(paste.length, 5)].focus();
      };
    });
  }

  // ── Verify OTP ──
  async function handleVerifyOtp() {
    const boxes = document.querySelectorAll('.otp-box');
    const code = [...boxes].map(b => b.value).join('');
    if (code.length < 6) return;
    const btn = document.getElementById('otp-verify-btn');
    const errEl = document.getElementById('otp-error');
    if (btn) { btn.disabled = true; btn.textContent = '...'; }
    if (errEl) errEl.classList.remove('show');
    try {
      const isDemo = !supabaseClient || SUPABASE_URL === 'https://YOUR_PROJECT_ID.supabase.co';
      if (isDemo) {
        // Demo mode — accept the console code
        if (code !== _demoCode) throw new Error('invalid');
        onAuthSuccess({ id: 'demo_' + Date.now(), email: _otpEmail, user_metadata: {} }, _otpEmail.split('@')[0]);
      } else {
        const { data, error } = await supabaseClient.auth.verifyOtp({ email: _otpEmail, token: code, type: 'email' });
        if (error) throw error;
        const name = data.user?.user_metadata?.full_name || _otpEmail.split('@')[0];
        await supabaseClient.from('profiles').upsert({ id: data.user.id, email: _otpEmail, display_name: name, created_at: new Date().toISOString() }).select();
        onAuthSuccess(data.user, name);
      }
    } catch(e) {
      if (errEl) { errEl.textContent = 'Invalid or expired code. Try again.'; errEl.classList.add('show'); }
      boxes.forEach(b => { b.value = ''; b.classList.remove('filled'); }); boxes[0]?.focus();
    }
    if (btn) { btn.disabled = false; btn.textContent = 'Verify'; }
  }
  window.handleVerifyOtp = handleVerifyOtp;

  // ── Resend OTP ──
  // FIX: il bottone viene disabilitato PRIMA della chiamata async per evitare
  // click multipli mentre la richiesta è in volo. Il cooldown di 30s parte
  // immediatamente, indipendentemente dall'esito della chiamata.
  let _resendCooldown = false;
  async function handleResendOtp() {
    const btn = document.getElementById('otp-resend-btn');
    if (!_otpEmail || !supabaseClient) return;
    if (_resendCooldown) return;
    _resendCooldown = true;
    if (btn) { btn.disabled = true; btn.textContent = 'Sending...'; }
    // Cooldown di 30s parte subito, prima della chiamata async
    setTimeout(() => {
      _resendCooldown = false;
      if (btn) { btn.disabled = false; btn.textContent = 'Resend code'; }
    }, 30000);
    try {
      await supabaseClient.auth.signInWithOtp({ email: _otpEmail, options: { shouldCreateUser: true, emailRedirectTo: null } });
      showToast('✓ New code sent', 'toast-info');
      if (btn) btn.textContent = 'Sent ✓';
      initOtpBoxes(); document.querySelectorAll('.otp-box')[0]?.focus();
    } catch(e) {
      showToast('Could not resend', 'toast-info');
      if (btn) btn.textContent = 'Resend code';
    }
  }
  window.handleResendOtp = handleResendOtp;

  // ── Continue as Guest ──
  function continueAsGuest() {
    currentUser = null; updateUserPill(null);
    window._authCompleted = true;
    state._authReturnTo = null;
    // Go to welcome screen first
    goTo('welcome');
    setTimeout(() => initMandala('welcomeCanvas'), 50);
    setTimeout(() => initNeonSpiralLogo('logoSpiralCanvas'), 80);
    // After welcome transition completes, show name modal or mode selection
    setTimeout(() => {
      const savedName = (() => { try { return localStorage.getItem('playerName') || ''; } catch(e) { return ''; } })();
      // Always show name modal so user can confirm/change their name
      document.getElementById('guestNameModal')?.remove();
      const t = state._uiText || UI_TEXT['en'];
      const m = document.createElement('div');
      m.className = 'modal-overlay'; m.id = 'guestNameModal';
      m.innerHTML = `
        <div class="room-box" style="text-align:center;border-color:rgba(72,202,228,0.22);">
          <div class="room-title" style="color:#48CAE4;">How should we call you?</div>
          <input id="guestNameInput" class="room-input room-input-cyan" type="text" maxlength="20"
            value="${savedName}"
            placeholder="${t.onlineNamePlaceholder || 'your name…'}"
            onkeydown="if(event.key==='Enter') window._submitGuestName()"/>
          <button class="room-icon-btn room-btn-cyan" onclick="window._submitGuestName()">${t.onlineNameBtn || 'Enter →'}</button>
        </div>`;
      document.body.appendChild(m);
      setTimeout(() => {
        const inp = document.getElementById('guestNameInput');
        if (inp) { inp.focus(); inp.select(); }
      }, 100);
      window._submitGuestName = function() {
        const inp = document.getElementById('guestNameInput');
        const name = inp?.value.trim();
        if (!name) {
          if (inp) { inp.style.borderColor='rgba(255,80,80,0.5)'; setTimeout(()=>inp.style.borderColor='',1200); }
          return;
        }
        state.playerName = name;
        try { localStorage.setItem('playerName', name); } catch(e) {}
        document.getElementById('guestNameModal')?.remove();
        showModeSelection();
      };
    }, 500);
  }
  window.continueAsGuest = continueAsGuest;

  // ── On Auth Success → check if needs username ──
  async function onAuthSuccess(user, name) {
    currentUser = user;
    window._authCompleted = true;
    await loadProfile();
    const returnTo = state._authReturnTo;
    state._authReturnTo = null;
    if (!_localProfile.username) {
      // New user — ask for username
      goTo('auth-username');
      setTimeout(() => document.getElementById('username-input')?.focus(), 400);
    } else {
      updateUserPill(user, _localProfile.username);
      goTo('welcome');
      setTimeout(() => initMandala('welcomeCanvas'), 50);
      setTimeout(() => initNeonSpiralLogo('logoSpiralCanvas'), 80);
      if (returnTo === 'modeSelection') setTimeout(() => showModeSelection(), 200);
    }
  }

  // ── Username input validation ──
  let _usernameCheckTimer = null;
  function handleUsernameInput() {
    const input = document.getElementById('username-input');
    const status = document.getElementById('username-status');
    const btn = document.getElementById('username-submit-btn');
    const val = input.value.replace(/[^a-zA-Z0-9_]/g, '');
    input.value = val;
    if (!status || !btn) return;
    if (val.length < 3) {
      status.textContent = val.length > 0 ? 'Min 3 characters' : '';
      status.className = 'username-status';
      btn.disabled = true; return;
    }
    status.textContent = 'Checking...';
    status.className = 'username-status checking';
    btn.disabled = true;
    clearTimeout(_usernameCheckTimer);
    _usernameCheckTimer = setTimeout(async () => {
      const taken = await checkUsernameTaken(val);
      if (taken) {
        status.textContent = val + ' is already taken';
        status.className = 'username-status taken';
        btn.disabled = true;
      } else {
        status.textContent = val + ' is available ✓';
        status.className = 'username-status ok';
        btn.disabled = false;
      }
    }, 500);
  }
  window.handleUsernameInput = handleUsernameInput;

  async function checkUsernameTaken(username) {
    if (!supabaseClient || SUPABASE_URL === 'https://YOUR_PROJECT_ID.supabase.co') {
      return false;
    }
    try {
      const { data, error } = await supabaseClient
        .from('profiles')
        .select('id')
        .ilike('username', username)
        .maybeSingle();
      if (error) return false;
      if (!data) return false;
      // Se l'username appartiene all'utente corrente, non è "preso"
      if (currentUser && data.id === currentUser.id) return false;
      return true;
    } catch(e) { return false; }
  }

  async function handleUsernameSubmit() {
    const input = document.getElementById('username-input');
    const btn = document.getElementById('username-submit-btn');
    const status = document.getElementById('username-status');
    const username = input?.value.trim();
    if (!username || username.length < 3) return;
    if (btn) { btn.disabled = true; btn.textContent = '...'; }

    // Controlla unicità prima di salvare
    const taken = await checkUsernameTaken(username);
    if (taken) {
      if (status) { status.textContent = 'Username già in uso, scegline un altro'; status.className = 'username-status taken'; }
      if (btn) { btn.disabled = false; btn.textContent = 'Continue'; }
      return;
    }

    _localProfile = { ..._localProfile, username }; window._localProfile = _localProfile;
    if (supabaseClient && currentUser && SUPABASE_URL !== 'https://YOUR_PROJECT_ID.supabase.co') {
      try {
        await supabaseClient.from('profiles').upsert({
          id: currentUser.id,
          email: currentUser.email,
          username,
          updated_at: new Date().toISOString()
        });
      } catch(e) {}
    }
    updateUserPill(currentUser, username);
    const returnTo = state._authReturnTo;
    state._authReturnTo = null;
    goTo('welcome');
    setTimeout(() => initMandala('welcomeCanvas'), 50);
    setTimeout(() => initNeonSpiralLogo('logoSpiralCanvas'), 80);
    if (returnTo === 'modeSelection') setTimeout(() => showModeSelection(), 200);
    if (btn) { btn.disabled = false; btn.textContent = 'Continue'; }
  }
  window.handleUsernameSubmit = handleUsernameSubmit;

  // ── Draw static spiral ──
  window.drawStaticSpiral = function drawStaticSpiral(canvasId, color1, color2) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const S = 160; canvas.width = S; canvas.height = S;
    const ctx = canvas.getContext('2d');
    // Dark background circle
    ctx.beginPath();
    ctx.arc(S/2, S/2, S/2, 0, Math.PI*2);
    ctx.fillStyle = '#0a0f1e';
    ctx.fill();
    const cx = S/2, cy = S/2;
    const turns = 2.8, maxR = S * 0.38, minR = 1.5, steps = 800;
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const t = (i / steps) * turns * Math.PI * 2;
      const r = minR + (maxR - minR) * Math.pow(i / steps, 0.85);
      pts.push({ x: cx + Math.cos(t - Math.PI*0.5)*r, y: cy + Math.sin(t - Math.PI*0.5)*r });
    }
    function drawPath() {
      ctx.beginPath();
      pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    }
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    // Glow layers
    ctx.globalAlpha = 0.18; ctx.shadowColor = color1; ctx.shadowBlur = 20;
    drawPath(); ctx.strokeStyle = color1; ctx.lineWidth = 14; ctx.stroke();
    ctx.globalAlpha = 0.35; ctx.shadowBlur = 10;
    drawPath(); ctx.strokeStyle = color1; ctx.lineWidth = 7; ctx.stroke();
    ctx.globalAlpha = 0.85; ctx.shadowBlur = 5;
    drawPath(); ctx.strokeStyle = color2; ctx.lineWidth = 2.8; ctx.stroke();
    ctx.globalAlpha = 1.0; ctx.shadowBlur = 2;
    drawPath(); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 0.8; ctx.stroke();
    ctx.shadowBlur = 0; ctx.globalAlpha = 1;
  };

  // ── Status toggle ──
  let _userStatus = 'online';
  function switchProfileTab(tab) {
    const mainView = document.getElementById('profile-main-view');
    const raccoltaView = document.getElementById('profile-raccolta-view');
    const btnProfile = document.getElementById('sidemenu-profile');
    const btnRaccolta = document.getElementById('sidemenu-raccolta');
    if (tab === 'raccolta') {
      if (mainView) mainView.style.display = 'none';
      if (raccoltaView) raccoltaView.style.display = 'flex';
      if (btnProfile) btnProfile.classList.remove('active');
      if (btnRaccolta) btnRaccolta.classList.add('active');
      if (!_gardenBuilt) gardenBuild();
      gardenUpdateProgress();
    } else {
      if (mainView) mainView.style.display = 'flex';
      if (raccoltaView) raccoltaView.style.display = 'none';
      if (btnProfile) btnProfile.classList.add('active');
      if (btnRaccolta) btnRaccolta.classList.remove('active');
    }
  }
  window.switchProfileTab = switchProfileTab;

  function toggleStatusMenu() {
    const menu = document.getElementById('status-menu');
    if (menu) menu.classList.toggle('open');
  }
  window.toggleStatusMenu = toggleStatusMenu;

  function setUserStatus(status) {
    _userStatus = status;
    _localProfile = { ..._localProfile, status };
    const dot = document.getElementById('profile-status-dot');
    if (dot) { dot.className = 'profile-status-dot ' + status; }
    // Update spiral wrap glow
    const wrap = document.getElementById('profile-spiral-wrap');
    if (wrap) { wrap.classList.toggle('offline', status === 'offline'); }
    // Update ring color on pill
    updatePillRingColor(status);
    const menu = document.getElementById('status-menu');
    if (menu) menu.classList.remove('open');
    // Close menu when clicking outside
  }
  window.setUserStatus = setUserStatus;

  function updatePillRingColor(status) {
    const circles = document.querySelectorAll('.ring-circle-small');
    circles.forEach(c => {
      c.style.stroke = status === 'online' ? '#22c55e' : '#ef4444';
      c.style.filter = status === 'online'
        ? 'drop-shadow(0 0 3px #22c55e)'
        : 'drop-shadow(0 0 3px #ef4444)';
    });
  }

  // Close status menu on outside click
  document.addEventListener('click', (e) => {
    const wrap = document.getElementById('profile-spiral-wrap');
    if (wrap && !wrap.contains(e.target)) {
      document.getElementById('status-menu')?.classList.remove('open');
    }
  });

  // ── Open Profile ──
  // openProfile is defined in the auth script block below
  // window.openProfile = openProfile; (handled below)

  // ── Social tabs ──
  let _socialTab = 'friends';
  function switchSocialTab(tab) {
    _socialTab = tab;
    ['friends','discover','requests'].forEach(t => {
      document.getElementById('tab-' + t)?.classList.toggle('active', t === tab);
    });
    renderSocialBody();
  }
  window.switchSocialTab = switchSocialTab;

  function renderSocialBody() {
    const body = document.getElementById('social-body');
    if (!body) return;
    if (_socialTab === 'friends') renderFriendsTab(body);
    else if (_socialTab === 'discover') renderDiscoverTab(body);
    else renderRequestsTab(body);
  }

  function renderFriendsTab(body) {
    const friends = _localProfile?.friends || [];
    if (friends.length === 0) {
      body.innerHTML = `<div class="social-empty">No friends yet.<br>Go to <b>Discover</b> to find people to connect with!</div>`;
      return;
    }
    // Sort: online first
    const sorted = [...friends].sort((a,b) => (b.online?1:0) - (a.online?1:0));
    const onlineCount = sorted.filter(f => f.online).length;
    let html = '';
    if (onlineCount > 0) html += `<div class="social-section-title">Online now (${onlineCount})</div>`;
    sorted.forEach((f, i) => {
      const name = f.username || f.email || 'Friend';
      const orig = friends.indexOf(f);
      html += `
        <div class="social-friend-row">
          <div class="social-user-avatar" style="background:${avatarGradient(name)}">
            ${escapeHtml(name.charAt(0).toUpperCase())}
            <span class="social-status-ring ${f.online ? 'online' : 'offline'}"></span>
          </div>
          <div class="social-friend-info">
            <div class="social-friend-name">${escapeHtml(name)}</div>
            <div class="social-friend-stats">${f.sessions||0} sessions · ${f.online ? '<span style="color:#22c55e">Online</span>' : 'Offline'}</div>
          </div>
          <div class="social-friend-actions">
            <button class="social-chat-btn" onclick="openChat(${orig})">Chat</button>
            <button class="social-invite-btn" ${!f.online ? 'disabled title="Not online"' : ''} onclick="inviteToSession('${name}')">▶ Play</button>
          </div>
        </div>
      `;
    });
    body.innerHTML = html;
  }

  function inviteToSession(username) {
    showToast(`Invitation sent to ${username}! ✓`, 'toast-info');
    // In production: create a session room and send notification via Supabase realtime
  }
  window.inviteToSession = inviteToSession;

  function renderDiscoverTab(body) {
    body.innerHTML = `
      <div class="social-search-wrap">
        <span class="social-search-icon">⌕</span>
        <input class="social-search" id="social-search-input" placeholder="Search by username..." oninput="handleSocialSearch()" onkeydown="if(event.key==='Enter') handleSocialSearch()">
      </div>
      <div id="social-search-results"></div>
      <div class="social-section-title">Suggested</div>
      <div id="social-suggested">${renderSuggestedUsers()}</div>
    `;
  }

  function renderSuggestedUsers() {
    // Demo suggested users
    const suggested = [
      { username: 'sofia_m', bio: 'Love deep conversations', sessions: 12 },
      { username: 'marco_r', bio: 'Curious about everything', sessions: 8 },
      { username: 'luna_k', bio: 'Mindfulness & awareness', sessions: 21 },
    ];
    const friends = _localProfile?.friends || [];
    return suggested.map(u => {
      const already = friends.find(f => f.username === u.username);
      return `
        <div class="social-user-card">
          <div class="social-user-avatar" style="background:${avatarGradient(u.username)}">${escapeHtml(u.username.charAt(0).toUpperCase())}</div>
          <div class="social-user-info">
            <div class="social-user-name">${escapeHtml(u.username)}</div>
            <div class="social-user-sub">${u.sessions} sessions · ${escapeHtml(u.bio)}</div>
          </div>
          <button class="social-add-btn ${already ? 'added' : ''}" onclick="addFriendFromSocial('${escapeHtml(u.username)}', this)">${already ? 'Added' : 'Add'}</button>
        </div>
      `;
    }).join('');
  }

  function renderRequestsTab(body) {
    body.innerHTML = `<div class="social-empty">No pending friend requests.</div>`;
  }

  async function handleSocialSearch() {
    const q = document.getElementById('social-search-input')?.value.trim().toLowerCase();
    const results = document.getElementById('social-search-results');
    if (!results) return;
    if (!q || q.length < 2) { results.innerHTML = ''; return; }
    // Demo search — in production queries Supabase
    const demo = [
      { username: 'alex_w', sessions: 5 },
      { username: 'anna_b', sessions: 14 },
      { username: 'andrea_s', sessions: 3 },
    ].filter(u => u.username.includes(q));
    if (demo.length === 0) { results.innerHTML = `<div class="social-empty" style="padding:1rem 1.4rem">No users found for "${escapeHtml(q)}"</div>`; return; }
    const friends = _localProfile?.friends || [];
    results.innerHTML = '<div class="social-section-title">Results</div>' + demo.map(u => {
      const already = friends.find(f => f.username === u.username);
      return `
        <div class="social-user-card">
          <div class="social-user-avatar" style="background:${avatarGradient(u.username)}">${escapeHtml(u.username.charAt(0).toUpperCase())}</div>
          <div class="social-user-info">
            <div class="social-user-name">${escapeHtml(u.username)}</div>
            <div class="social-user-sub">${u.sessions} sessions</div>
          </div>
          <button class="social-add-btn ${already ? 'added' : ''}" onclick="addFriendFromSocial('${u.username}', this)">${already ? 'Added' : 'Add'}</button>
        </div>
      `;
    }).join('');
  }
  window.handleSocialSearch = handleSocialSearch;

  function addFriendFromSocial(username, btn) {
    const friends = _localProfile?.friends || [];
    if (friends.find(f => f.username === username)) return;
    friends.push({ username, sessions: 0, online: false });
    _localProfile = { ..._localProfile, friends };
    btn.textContent = 'Added'; btn.classList.add('added');
    document.getElementById('stat-friends').textContent = friends.length;
    showToast('Friend added ✓', 'toast-info');
  }
  window.addFriendFromSocial = addFriendFromSocial;

  function avatarGradient(str) {
    const gradients = ['linear-gradient(135deg,#1B9AAA,#9B5DE5)','linear-gradient(135deg,#F72585,#7209B7)','linear-gradient(135deg,#4CC9F0,#4361EE)','linear-gradient(135deg,#06D6A0,#118AB2)','linear-gradient(135deg,#FB8500,#FFB703)'];
    let h = 0; for (let c of (str||'?')) h = (h*31 + c.charCodeAt(0)) % gradients.length;
    return gradients[Math.abs(h)];
  }

  // ── Open Social (init tab) ──
  function openSocial() { _socialTab = 'friends'; switchSocialTab('friends'); }
  window.openSocial = openSocial;

  // ── Chat ──
  let _chatFriendIndex = -1;
  let _chatMessages = {};
  function openChat(friendIndex) {
    _chatFriendIndex = friendIndex;
    const friend = (_localProfile?.friends || [])[friendIndex];
    if (!friend) return;
    const name = friend.username || friend.email || 'Friend';
    const peerAvatar = document.getElementById('chat-peer-avatar');
    const peerName = document.getElementById('chat-peer-name');
    const peerStatus = document.getElementById('chat-peer-status');
    if (peerAvatar) peerAvatar.textContent = name.charAt(0).toUpperCase();
    if (peerName)   peerName.textContent = name;
    if (peerStatus) peerStatus.textContent = friend.online ? 'Online' : 'Offline';
    renderChatMessages(name);
    goTo('chat');
    setTimeout(() => document.getElementById('chat-input')?.focus(), 300);
  }
  window.openChat = openChat;

  function renderChatMessages(key) {
    const msgs = _chatMessages[key] || [];
    const container = document.getElementById('chat-messages');
    if (!container) return;
    if (msgs.length === 0) {
      container.innerHTML = `<div style="flex:1;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:0.82rem;text-align:center;padding:2rem">Start a conversation!<br><span style="font-size:0.72rem;margin-top:0.3rem;display:block">Messages are private between you two</span></div>`;
      return;
    }
    container.innerHTML = msgs.map(m => `
      <div class="chat-bubble-wrap ${m.me ? 'me' : 'them'}">
        <div class="chat-bubble ${m.me ? 'me' : 'them'}">${escapeHtml(m.text)}</div>
        <div class="chat-time">${escapeHtml(m.time)}</div>
      </div>
    `).join('');
    container.scrollTop = container.scrollHeight;
  }

  function sendChatMessage() {
    const input = document.getElementById('chat-input');
    const text = input?.value.trim();
    if (!text) return;
    const friend = (_localProfile?.friends || [])[_chatFriendIndex];
    const key = friend?.username || friend?.email || 'chat';
    if (!_chatMessages[key]) _chatMessages[key] = [];
    const now = new Date();
    const time = now.getHours() + ':' + String(now.getMinutes()).padStart(2,'0');
    _chatMessages[key].push({ me: true, text, time });
    if (input) input.value = '';
    renderChatMessages(key);
  }
  window.sendChatMessage = sendChatMessage;

  function updateUserPill(user, usernameOverride) {
    const pill = document.getElementById('user-pill');
    const avatarLetter = document.getElementById('user-avatar-letter');
    const pillName = document.getElementById('user-pill-name');
    const signinBtn = document.getElementById('signin-btn');
    if (!pill) return;
    if (user) {
      const username = usernameOverride || _localProfile?.username || user.email?.split('@')[0] || '?';
      pill.style.display = 'flex';
      pillName.textContent = username;
      if (avatarLetter) avatarLetter.textContent = username.charAt(0).toUpperCase();
      if (signinBtn) signinBtn.style.display = 'none';
    } else {
      pill.style.display = 'none';
      if (signinBtn) signinBtn.style.display = 'block';
    }
  }

  // ── Open Profile — populate fields ──
  function openProfile() {
    const profile = _localProfile || {};
    const name = (currentUser && (currentUser.user_metadata?.full_name || currentUser.user_metadata?.display_name || currentUser.email?.split('@')[0])) || '';
    // Stats
    const statSessions  = document.getElementById('stat-sessions');
    const statQuestions = document.getElementById('stat-questions');
    const statFriends   = document.getElementById('stat-friends');
    if (statSessions)  statSessions.textContent  = profile.sessions_played || 0;
    if (statQuestions) statQuestions.textContent = profile.questions_answered || 0;
    if (statFriends)   statFriends.textContent   = (profile.friends || []).length;
    // Bio
    const bioInput = document.getElementById('profile-bio-input');
    if (bioInput) bioInput.value = profile.bio || '';
    // Friends list
    if (typeof renderFriends === 'function') renderFriends(profile.friends || []);
    // ── Spiral + username ──
    const username = profile.username || name || '';
    const uDisplay = document.getElementById('profile-username-display');
    if (uDisplay) uDisplay.textContent = username;
    const status = profile.status || 'online';
    const isOnline = status === 'online';
    const c1 = isOnline ? 'rgba(34,197,94,1)'   : 'rgba(239,68,68,1)';
    const c2 = isOnline ? 'rgba(134,239,172,1)'  : 'rgba(252,165,165,1)';
    setTimeout(() => { if (window.drawStaticSpiral) window.drawStaticSpiral('profileSpiralCanvas', c1, c2); }, 80);
    const wrap = document.getElementById('profile-spiral-wrap');
    if (wrap) wrap.classList.toggle('offline', !isOnline);
    _userStatus = status;
  }
  window.openProfile = openProfile;

  // Local profile cache
  let _localProfile = {};
  window._localProfile = _localProfile;
  async function loadProfile() {
    if (!supabaseClient || !currentUser) return;
    try {
      const { data } = await supabaseClient.from('profiles').select('*').eq('id', currentUser.id).single();
      if (data) {
        _localProfile = data; window._localProfile = _localProfile;
        // Aggiorna playerName con username reale
        if (data.username) {
          state.playerName = data.username;
          try { localStorage.setItem('playerName', data.username); } catch(e) {}
        }
        // Carica i progressi della raccolta da Supabase (merge con localStorage)
        if (typeof gardenLoadFromSupabase === 'function') gardenLoadFromSupabase();
      } else {
        // Profilo non esiste ancora (es. nuovo utente Google) — crealo
        const email = currentUser.email || '';
        await supabaseClient.from('profiles').upsert({
          id: currentUser.id,
          email,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
        _localProfile = { id: currentUser.id, email }; window._localProfile = _localProfile;
      }
    } catch(e) {
      // Prova comunque a creare il profilo
      try {
        await supabaseClient.from('profiles').upsert({
          id: currentUser.id,
          email: currentUser.email || '',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
        _localProfile = { id: currentUser.id, email: currentUser.email || '' };
      } catch(e2) {}
    }
  }

  // ── Save profile ──
  async function handleSaveProfile() {
    if (!currentUser) return;
    const bio = document.getElementById('profile-bio-input')?.value.trim();
    _localProfile = { ..._localProfile, bio };
    if (supabaseClient && currentUser && SUPABASE_URL !== 'https://YOUR_PROJECT_ID.supabase.co') {
      try {
        await supabaseClient.from('profiles').upsert({
          id: currentUser.id, bio,
          friends: _localProfile.friends || [],
          updated_at: new Date().toISOString()
        });
      } catch(e) {}
    }
    showToast('Saved ✓', 'toast-info');
  }
  window.handleSaveProfile = handleSaveProfile;

  // ── Log Out ──
  async function handleLogOut() {
    if (supabaseClient) { try { await supabaseClient.auth.signOut(); } catch(e) {} }
    currentUser = null; _localProfile = {};
    window._authCompleted = false;
    if (typeof state !== 'undefined') { state.playerName = ''; }
    try { localStorage.removeItem('playerName'); } catch(e) {}
    updateUserPill(null);
    goTo('welcome');
    showToast('Logged out', 'toast-info');
  }
  window.handleLogOut = handleLogOut;

  // ── User Menu (sign out) — kept for compatibility ──
  async function showUserMenu() { goTo('profile'); }
  window.showUserMenu = showUserMenu;

  // ── Save progress ──
  async function saveUserProgress(data) {
    if (!supabaseClient || !currentUser) return;
    try { await supabaseClient.from('user_progress').upsert({ user_id: currentUser.id, ...data, updated_at: new Date().toISOString() }); }
    catch(e) { console.warn('Could not save progress:', e); }
  }
  window.saveUserProgress = saveUserProgress;

  // ── OAuth redirect handler ──
  if (supabaseClient) {
    supabaseClient.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        const screens = ['auth-screen', 'auth-otp', 'splash', 'welcome'];
        if (screens.includes(state.currentScreen)) {
          const name = session.user.user_metadata?.full_name || session.user.user_metadata?.name || session.user.email?.split('@')[0];
          onAuthSuccess(session.user, name);
        }
      }
    });
  }

  // ── Init auth mandala ──
  // no stars on auth screen

});
