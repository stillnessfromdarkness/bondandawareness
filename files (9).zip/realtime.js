// ══════════════════════════════════════════
//  SUPABASE REALTIME — sostituisce Firebase Realtime Database
// ══════════════════════════════════════════

// Stub database per compatibilità residua (non usato)
const database = null;
const isFirebaseEnabled = false;

// ── Supabase broadcast helper ──────────────────────────────────────
// Funzione helper riutilizzabile per inviare broadcast su qualsiasi canale.
// FIX: _matchChannel() e _sbBroadcast() erano dead code (mai chiamati) — rimossi.
// Ora tutti i broadcast (typing, thoughts) usano _sendBroadcast() con gestione
// corretta di CHANNEL_ERROR/TIMED_OUT per evitare promise che non si risolvono mai.
async function _sendBroadcast(channelName, event, payload) {
  const sb = _sbClient(); if (!sb) return;
  return new Promise((resolve) => {
    const ch = sb.channel(channelName, { config: { broadcast: { self: false } } });
    const timeout = setTimeout(() => {
      try { sb.removeChannel(ch); } catch(e) {}
      resolve();
    }, 3000);
    ch.subscribe(async (status) => {
      if (status === 'SUBSCRIBED') {
        clearTimeout(timeout);
        try { await ch.send({ type: 'broadcast', event, payload }); } catch(e) {}
        setTimeout(() => { try { sb.removeChannel(ch); } catch(e) {} }, 300);
        resolve();
      } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
        clearTimeout(timeout);
        try { sb.removeChannel(ch); } catch(e) {}
        resolve();
      }
    });
  });
}

// Leggi il record match da Supabase

// _updateMatch e _insertThought rimossi — erano dead code (mai chiamati).
// Tutti gli update al match avvengono inline con sb.from('matches').update(...).
// I thoughts vanno via broadcast su 'thoughts_*', non su DB.

console.log('✅ Supabase Realtime ready');

