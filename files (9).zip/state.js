// ══════════════════════════════════════════
//  STATE
// ══════════════════════════════════════════
const state = {
  currentScreen: 'splash',
  playerName: '',
  selectedLang: { code: 'en', name: 'English', flag: '🇬🇧' },
  langFromGame: false,
  currentQuestion: '',
  questionIndex: 0,
  isUnlocked: false,
  isSolo: true,
  isOffline: false,
  matchId: null,
  _currentSeed: null,
  opponentName: null,
  isMyTurn: false,
  playerId: null,
  currentAnswer: null,
  opponentAnswer: null,
  answerSubmitted: false,
  isWaitingForMatch: false,
  sessionToken: null,
  // matchListener e queueRef rimossi — erano residui legacy Firebase mai usati.
  opponentId: null,
  _partnerTyping: false,
};

// ══════════════════════════════════════════
//  QUESTIONS (20 questions, 11 languages)
// ══════════════════════════════════════════
const LANGUAGES = [
  { name:'English',  code:'en', flag:'🇬🇧' },
  { name:'Español',  code:'es', flag:'🇪🇸' },
  { name:'Français', code:'fr', flag:'🇫🇷' },
  { name:'Italiano', code:'it', flag:'🇮🇹' },
  { name:'Deutsch',  code:'de', flag:'🇩🇪' },
  { name:'Português',code:'pt', flag:'🇧🇷' },
  { name:'عربي',     code:'ar', flag:'🇸🇦' },
  { name:'简体中文',  code:'zh', flag:'🇨🇳' },
  { name:'Русский',  code:'ru', flag:'🇷🇺' },
  { name:'עברית',    code:'he', flag:'🇮🇱' },
  { name:'Indonesia',code:'id', flag:'🇮🇩' },
];

const QUESTIONS = [
  {en:"What is something you've never told anyone but have always wanted to?",es:"¿Qué es algo que nunca le has dicho a nadie pero siempre has querido decir?",fr:"Quelle est une chose que vous n'avez jamais dite à personne mais que vous avez toujours voulu dire?",it:"C'è qualcosa che non hai mai detto a nessuno ma hai sempre voluto dire?",de:"Was ist etwas, das du noch nie jemandem gesagt hast, aber immer sagen wolltest?",pt:"O que é algo que você nunca contou a ninguém, mas sempre quis dizer?",ar:"ما الذي لم تخبره لأحد قط لكنك دائمًا أردت قوله؟",zh:"有什么你从未告诉任何人但一直想说的事？",ru:"Что вы никогда никому не говорили, но всегда хотели сказать?",he:"מה הוא משהו שמעולם לא סיפרת לאף אחד, אך תמיד רצית לשתף?",id:"Apa yang tidak pernah kamu ceritakan kepada siapapun namun selalu ingin kamu katakan?"},
  {en:"What moment in your life do you most wish you could relive?",es:"¿Qué momento de tu vida desearías poder revivir?",fr:"Quel moment de votre vie souhaiteriez-vous le plus pouvoir revivre?",it:"Quale momento della tua vita vorresti più rivivere?",de:"Welchen Moment in deinem Leben würdest du am liebsten noch einmal erleben?",pt:"Qual momento da sua vida você mais gostaria de reviver?",ar:"أي لحظة في حياتك تتمنى أن تعيشها مرة أخرى؟",zh:"你人生中最希望能重温的是哪个时刻？",ru:"Какой момент в вашей жизни вы больше всего хотели бы пережить снова?",he:"איזה רגע בחייך היית הכי רוצה לחוות שוב?",id:"Momen apa dalam hidupmu yang paling ingin kamu alami kembali?"},
  {en:"What does love mean to you — and has that meaning changed?",es:"¿Qué significa el amor para ti? ¿Ha cambiado ese significado?",fr:"Que signifie l'amour pour vous — et ce sens a-t-il changé?",it:"Cosa significa per te l'amore — e questo significato è cambiato?",de:"Was bedeutet Liebe für dich — und hat sich das verändert?",pt:"O que o amor significa para você — e esse significado mudou?",ar:"ماذا يعني الحب بالنسبة لك — وهل تغيّر هذا المعنى؟",zh:"爱对你意味着什么——这种意义改变过吗？",ru:"Что для вас значит любовь — и изменилось ли это значение?",he:"מה אהבה מסמלת עבורך — והאם המשמעות הזו השתנתה?",id:"Apa arti cinta bagimu — dan apakah makna itu sudah berubah?"},
  {en:"What fear has quietly shaped your life without you realizing it?",es:"¿Qué miedo ha moldeado silenciosamente tu vida sin que te hayas dado cuenta?",fr:"Quelle peur a silencieusement façonné votre vie sans que vous le réalisiez?",it:"Quale paura ha silenziosamente plasmato la tua vita senza che tu te ne rendessi conto?",de:"Welche Angst hat dein Leben still geprägt, ohne dass du es gemerkt hast?",pt:"Qual medo moldou silenciosamente a sua vida sem que você percebesse?",ar:"أي خوف شكّل حياتك بهدوء دون أن تدرك ذلك؟",zh:"哪种恐惧悄悄塑造了你的生活，而你却没有意识到？",ru:"Какой страх тихо формировал вашу жизнь, не осознавая этого?",he:"איזה פחד עיצב את חייך בשקט מבלי שהרגשת?",id:"Ketakutan apa yang diam-diam membentuk hidupmu tanpa kamu sadari?"},
  {en:"When do you feel most fully alive?",es:"¿Cuándo te sientes más completamente vivo?",fr:"Quand vous sentez-vous le plus pleinement vivant?",it:"Quando ti senti più pienamente vivo?",de:"Wann fühlst du dich am lebendigsten?",pt:"Quando você se sente mais completamente vivo?",ar:"متى تشعر أنك حيٌّ تمامًا؟",zh:"你什么时候感到最充满活力？",ru:"Когда вы чувствуете себя наиболее живым?",he:"מתי אתה מרגיש הכי חי?",id:"Kapan kamu merasa paling hidup sepenuhnya?"},
  {en:"What is the kindest thing someone has ever done for you?",es:"¿Cuál es la cosa más amable que alguien ha hecho por ti?",fr:"Quelle est la chose la plus gentille qu'on ait jamais faite pour vous?",it:"Qual è la cosa più gentile che qualcuno abbia mai fatto per te?",de:"Was ist das Freundlichste, was jemand jemals für dich getan hat?",pt:"Qual é a coisa mais gentil que alguém já fez por você?",ar:"ما أطيب شيء فعله أحدهم من أجلك؟",zh:"有人为你做过的最善良的事是什么？",ru:"Что самое доброе кто-то сделал для вас?",he:"מה המעשה הכי אדיב שמישהו עשה בשבילך?",id:"Apa hal terbaik yang pernah dilakukan seseorang untukmu?"},
  {en:"What part of yourself are you still learning to accept?",es:"¿Qué parte de ti mismo todavía estás aprendiendo a aceptar?",fr:"Quelle partie de vous-même apprenez-vous encore à accepter?",it:"Quale parte di te stesso stai ancora imparando ad accettare?",de:"Welchen Teil von dir selbst lernst du noch zu akzeptieren?",pt:"Qual parte de si mesmo você ainda está aprendendo a aceitar?",ar:"أي جزء من نفسك لا تزال تتعلم قبوله؟",zh:"你仍在学习接受自己的哪个部分？",ru:"Какую часть себя вы ещё учитесь принимать?",he:"איזה חלק בעצמך אתה עדיין לומד לקבל?",id:"Bagian dirimu yang mana yang masih kamu pelajari untuk diterima?"},
  {en:"What would you do differently if you knew you couldn't fail?",es:"¿Qué harías de manera diferente si supieras que no puedes fracasar?",fr:"Que feriez-vous différemment si vous saviez que vous ne pouvez pas échouer?",it:"Cosa faresti diversamente se sapessi che non puoi fallire?",de:"Was würdest du anders machen, wenn du wüsstest, dass du nicht scheitern kannst?",pt:"O que você faria diferente se soubesse que não poderia falhar?",ar:"ماذا ستفعل بشكل مختلف لو عرفت أنك لن تفشل؟",zh:"如果知道不会失败，你会做什么不同的选择？",ru:"Что бы вы сделали иначе, зная, что не можете потерпеть неудачу?",he:"מה היית עושה אחרת אם ידעת שאי אפשר לכשול?",id:"Apa yang akan kamu lakukan secara berbeda jika kamu tahu tidak bisa gagal?"},
  {en:"What is something about you that surprises people?",es:"¿Qué hay en ti que sorprende a la gente?",fr:"Qu'est-ce qui chez vous surprend les gens?",it:"C'è qualcosa di te che sorprende le persone?",de:"Was überrascht andere Menschen an dir?",pt:"O que há em você que surpreende as pessoas?",ar:"ما الذي يفاجئ الناس عنك؟",zh:"关于你自己，什么会让人们感到惊讶？",ru:"Что в вас удивляет людей?",he:"מה בך מפתיע אנשים?",id:"Apa yang ada di dirimu yang membuat orang terkejut?"},
  {en:"What memory brings you unexplainable peace?",es:"¿Qué recuerdo te trae una paz inexplicable?",fr:"Quel souvenir vous apporte une paix inexplicable?",it:"Quale ricordo ti porta una pace inspiegabile?",de:"Welche Erinnerung bringt dir unerklärlichen Frieden?",pt:"Qual memória traz a você uma paz inexplicável?",ar:"أي ذكرى تجلب لك سلامًا لا يمكن تفسيره؟",zh:"什么记忆会带给你莫名的平静？",ru:"Какое воспоминание приносит вам необъяснимый покой?",he:"איזו זיכרון מביא לך שלווה שאי אפשר להסביר?",id:"Kenangan apa yang memberimu kedamaian yang tak dapat dijelaskan?"},
  {en:"If you could send a message to your younger self, what would it be?",es:"¿Si pudieras enviarle un mensaje a tu yo más joven, cuál sería?",fr:"Si vous pouviez envoyer un message à votre jeune moi, quel serait-il?",it:"Se potessi mandare un messaggio al tuo io più giovane, cosa diresti?",de:"Was würdest du deinem jüngeren Ich sagen?",pt:"Se você pudesse enviar uma mensagem para o seu eu mais jovem, o que seria?",ar:"ماذا ستقول لنفسك في سنٍّ أصغر؟",zh:"如果可以给年轻时的自己发一条信息，你会说什么？",ru:"Что бы вы сказали своему молодому «я»?",he:"אם יכולת לשלוח הודעה לעצמך הצעיר, מה היא הייתה?",id:"Jika kamu bisa mengirim pesan ke dirimu yang lebih muda, apa isinya?"},
  {en:"What does home feel like to you?",es:"¿Cómo te sientes en casa?",fr:"Que signifie «maison» pour vous?",it:"Cosa significa «casa» per te?",de:"Wie fühlt sich Zuhause für dich an?",pt:"O que significa lar para você?",ar:"ما الذي يشعرك بأنك في البيت؟",zh:"「家」对你来说是什么感觉？",ru:"Что для вас значит дом?",he:"מה זה אומר לך בית?",id:"Apa yang terasa seperti rumah bagimu?"},
  {en:"What has grief taught you?",es:"¿Qué te ha enseñado el duelo?",fr:"Que vous a appris le deuil?",it:"Cosa ti ha insegnato il dolore?",de:"Was hat dich Trauer gelehrt?",pt:"O que o luto te ensinou?",ar:"ماذا علّمك الحزن؟",zh:"悲痛教给了你什么？",ru:"Чему вас научило горе?",he:"מה האבל לימד אותך?",id:"Apa yang telah diajarkan kesedihan kepadamu?"},
  {en:"Is there someone you need to forgive — including yourself?",es:"¿Hay alguien a quien necesites perdonar — incluido a ti mismo?",fr:"Y a-t-il quelqu'un que vous devez pardonner — y compris vous-même?",it:"C'è qualcuno che devi perdonare — incluso te stesso?",de:"Gibt es jemanden, dem du vergeben musst — einschließlich dir selbst?",pt:"Há alguém a quem você precisa perdoar — incluindo a si mesmo?",ar:"هل هناك شخص تحتاج إلى مسامحته — بما في ذلك نفسك؟",zh:"有没有你需要原谅的人——包括你自己？",ru:"Есть ли кто-то, кого вам нужно простить — включая себя?",he:"האם יש מישהו שאתה צריך לסלוח לו — כולל את עצמך?",id:"Adakah seseorang yang perlu kamu maafkan — termasuk dirimu sendiri?"},
  {en:"What is your relationship with silence?",es:"¿Cuál es tu relación con el silencio?",fr:"Quelle est votre relation avec le silence?",it:"Qual è il tuo rapporto con il silenzio?",de:"Wie ist dein Verhältnis zur Stille?",pt:"Qual é sua relação com o silêncio?",ar:"ما علاقتك بالصمت؟",zh:"你与沉默的关系是怎样的？",ru:"Какие у вас отношения с тишиной?",he:"מה הקשר שלך עם שתיקה?",id:"Bagaimana hubunganmu dengan keheningan?"},
  {en:"What do you wish people understood about you?",es:"¿Qué deseas que la gente entendiera sobre ti?",fr:"Qu'aimeriez-vous que les gens comprennent de vous?",it:"Cosa vorresti che le persone capissero di te?",de:"Was wünschst du dir, dass andere über dich verstehen?",pt:"O que você gostaria que as pessoas entendessem sobre você?",ar:"ما الذي تتمنى أن يفهمه الناس عنك؟",zh:"你希望人们能理解你的哪些方面？",ru:"Что вы хотели бы, чтобы люди понимали о вас?",he:"מה היית רוצה שאנשים יבינו עליך?",id:"Apa yang kamu harapkan orang-orang pahami tentangmu?"},
  {en:"What is one belief you hold that most people disagree with?",es:"¿Cuál es una creencia que tienes con la que la mayoría no está de acuerdo?",fr:"Quelle est une croyance avec laquelle la plupart des gens ne sont pas d'accord?",it:"Qual è una credenza che hai con cui la maggior parte non è d'accordo?",de:"Was ist eine Überzeugung, mit der die meisten nicht einverstanden sind?",pt:"Qual é uma crença sua com a qual a maioria discorda?",ar:"ما هو اعتقاد تحمله يخالفه معظم الناس؟",zh:"你持有哪种大多数人不同意的信念？",ru:"Какое убеждение у вас есть, с которым большинство не согласны?",he:"מה אמונה אחת שרוב האנשים לא מסכימים איתה?",id:"Apa satu keyakinan yang kamu pegang yang kebanyakan orang tidak setuju?"},
  {en:"What does your body need that you haven't been giving it?",es:"¿Qué necesita tu cuerpo que no le has estado dando?",fr:"De quoi votre corps a-t-il besoin que vous ne lui avez pas donné?",it:"Di cosa ha bisogno il tuo corpo che non gli stai dando?",de:"Was braucht dein Körper, das du ihm nicht gibst?",pt:"O que o seu corpo precisa que você não tem dado a ele?",ar:"ما الذي يحتاجه جسدك ولم تكن تعطيه إياه؟",zh:"你的身体需要什么而你没有给予它？",ru:"В чём нуждается ваше тело, чего вы ему не даёте?",he:"מה הגוף שלך צריך שאתה לא נותן לו?",id:"Apa yang dibutuhkan tubuhmu yang belum kamu berikan?"},
  {en:"What makes you feel genuinely seen by another person?",es:"¿Qué te hace sentir genuinamente visto por otra persona?",fr:"Qu'est-ce qui vous fait vous sentir vraiment vu par une autre personne?",it:"Cosa ti fa sentire veramente visto da un'altra persona?",de:"Was lässt dich das Gefühl haben, wirklich gesehen zu werden?",pt:"O que te faz sentir genuinamente visto por outra pessoa?",ar:"ما الذي يجعلك تشعر أن شخصًا ما يراك حقًا؟",zh:"什么让你感到真正被另一个人看见？",ru:"Что заставляет вас чувствовать себя по-настоящему увиденным?",he:"מה גורם לך להרגיש שרואים אותך באמת?",id:"Apa yang membuatmu merasa benar-benar dilihat oleh orang lain?"},
  {en:"What are you most grateful for right now, in this very moment?",es:"¿Por qué estás más agradecido ahora mismo?",fr:"Pour quoi êtes-vous le plus reconnaissant en ce moment?",it:"Per cosa sei più grato in questo preciso momento?",de:"Wofür bist du gerade am dankbarsten?",pt:"Pelo que você é mais grato agora, neste exato momento?",ar:"علامَ أنت ممتن أكثر ما يكون الآن؟",zh:"此刻，你最感激的是什么？",ru:"За что вы больше всего благодарны прямо сейчас?",he:"על מה אתה הכי אסיר תודה ברגע הזה?",id:"Apa yang paling kamu syukuri saat ini?"},
];

