// ══════════════════════════════════════════
//  PRIVATE ROOM
// ══════════════════════════════════════════
function pickRoomMode() {
  // Supabase always available
  if (window.location.protocol === 'file:') {
    alert('⚠️ Private Room works only when the app is hosted online.\n\nUpload the file to a web server or use GitHub Pages, then try again.');
    return;
  }
  // Show next modal BEFORE removing current to avoid flash
  showRoomSubModal();
  setTimeout(() => closeModeModal(), 50);
}
window.pickRoomMode = pickRoomMode;

function showRoomSubModal() {
  document.getElementById('roomSubModal')?.remove();
  const t = state._uiText || UI_TEXT['en'];
  const modal = document.createElement('div');
  modal.className = 'modal-overlay'; modal.id = 'roomSubModal';
  modal.innerHTML = `
    <div class="modal-box">
      <div style="display:flex;align-items:center;margin-bottom:0.8rem;" class="mode-back-fade">
        <button onclick="showModeSelection();setTimeout(closeRoomSubModal,50)" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.14);border-radius:50%;color:rgba(255,255,255,0.6);font-size:1.1rem;width:38px;height:38px;display:flex;align-items:center;justify-content:center;cursor:pointer;line-height:1;flex-shrink:0;transition:all 0.25s;" onmouseover="this.style.background='rgba(255,255,255,0.1)';this.style.borderColor='rgba(255,255,255,0.3)';this.style.color='white';" onmouseout="this.style.background='rgba(255,255,255,0.04)';this.style.borderColor='rgba(255,255,255,0.14)';this.style.color='rgba(255,255,255,0.6)';">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
      </div>
      <button class="mode-btn room-btn mode-star-1" onclick="startCreateRoom();setTimeout(closeRoomSubModal,50)" style="margin-bottom:0.8rem;">
        <span class="mode-icon">
          <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
            <circle cx="22" cy="22" r="14" fill="rgba(255,213,128,0.1)" stroke="rgba(255,213,128,0.7)" stroke-width="1.5"/>
            <line x1="22" y1="15" x2="22" y2="29" stroke="rgba(255,213,128,1)" stroke-width="2" stroke-linecap="round"/>
            <line x1="15" y1="22" x2="29" y2="22" stroke="rgba(255,213,128,1)" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </span>
        <div>
          <div class="mode-title" style="color:#ffd580;">${t.roomCreateTitle||'Crea Stanza'}</div>
          <div class="mode-sub">${t.roomCreateSub||'Genera un codice e invita un amico'}</div>
        </div>
      </button>
      <button class="mode-btn mode-star-2" onclick="startJoinRoom();setTimeout(closeRoomSubModal,50)" style="background:linear-gradient(135deg,rgba(72,202,228,0.25),rgba(27,154,170,0.1));border-color:rgba(72,202,228,0.4);box-shadow:0 4px 20px rgba(27,154,170,0.2);">
        <span class="mode-icon">
          <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
            <circle cx="22" cy="22" r="14" fill="rgba(72,202,228,0.1)" stroke="rgba(72,202,228,0.7)" stroke-width="1.5"/>
            <path d="M25 16h4a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-4" stroke="rgba(72,202,228,1)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
            <polyline points="20,18 26,22 20,26" stroke="rgba(72,202,228,1)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
            <line x1="13" y1="22" x2="25" y2="22" stroke="rgba(72,202,228,1)" stroke-width="1.8" stroke-linecap="round"/>
          </svg>
        </span>
        <div>
          <div class="mode-title" style="color:#48CAE4;">${t.roomJoinTitle||'Unisciti alla Stanza'}</div>
          <div class="mode-sub">${t.roomJoinSub||'Inserisci il codice ricevuto'}</div>
        </div>
      </button>
    </div>
  `;
  document.body.appendChild(modal);
}
function closeRoomSubModal() {
  const m = document.getElementById('roomSubModal');
  if (!m) return;
  m.style.transition = 'opacity 0.15s ease';
  m.style.opacity = '0';
  m.style.pointerEvents = 'none';
  setTimeout(() => m.remove(), 160);
}
window.closeRoomSubModal = closeRoomSubModal;

/* ── Helper modale nome ── */
function _nameModal(id, accentColor, titleText, subText, placeholder, continueLabel, onBack, onSubmit) {
  document.getElementById(id)?.remove();
  const isCyan = accentColor === '#48CAE4';
  const modal = document.createElement('div');
  modal.className = 'modal-overlay'; modal.id = id;
  modal.innerHTML = `
    <div class="room-box" style="text-align:center;">
      <div style="display:flex;align-items:center;margin-bottom:1.2rem;">
        <button class="room-back-btn" onclick="${onBack}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg></button>
      </div>
      <div class="room-title" style="color:${accentColor};">${titleText}</div>
      ${subText ? `<div class="room-sub" style="color:${accentColor}55;margin-bottom:1.4rem;">${subText}</div>` : ''}
      <input id="${id}Input" class="room-input ${isCyan?'room-input-cyan':''}" type="text" maxlength="20" placeholder="${placeholder}"
        onkeydown="if(event.key==='Enter') ${onSubmit}"/>
      <button class="room-icon-btn ${isCyan?'room-btn-cyan':'room-btn-gold'}" onclick="${onSubmit}">${continueLabel}</button>
    </div>
  `;
  document.body.appendChild(modal);
  setTimeout(() => document.getElementById(id+'Input')?.focus(), 100);
}

/* ── Crea Stanza ── */
function startCreateRoom() {
  // Skip name — ask it later, just before the game starts
  _showRoomLoadingOverlay();
  createPrivateRoom('__pending__');
}
window.startCreateRoom = startCreateRoom;

function _submitCreateRoomName() {
  const inp = document.getElementById('createRoomNameModalInput');
  const name = inp?.value.trim();
  if (!name) { if(inp){inp.style.borderColor='rgba(255,80,80,0.5)';setTimeout(()=>{inp.style.borderColor='';},1200);} return; }
  document.getElementById('createRoomNameModal')?.remove();
  state.playerName = name;
  // Resume the pending match creation stored in state
  if (state._pendingMatchCallback) {
    const cb = state._pendingMatchCallback;
    state._pendingMatchCallback = null;
    cb(name);
  }
}
window._submitCreateRoomName = _submitCreateRoomName;

function _doCreateRoom(hostName) {
  state.playerName = hostName;
  createPrivateRoom(hostName);
}
window._doCreateRoom = _doCreateRoom;

/* ── Unisciti ── */
function startJoinRoom() {
  document.getElementById('joinRoomModal')?.remove();
  const t = state._uiText || UI_TEXT['en'];
  const modal = document.createElement('div');
  modal.className = 'modal-overlay'; modal.id = 'joinRoomModal';
  modal.innerHTML = `
    <div class="room-box" style="text-align:center;">
      <div style="display:flex;align-items:center;margin-bottom:1.2rem;">
        <button class="room-back-btn" onclick="closeJoinRoomModal();showRoomSubModal()"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg></button>
      </div>
      <div class="room-title" style="color:#48CAE4;">${t.roomJoinTitle||'Unisciti alla Stanza'}</div>
      <div id="qr-scanner-container" style="display:none;margin-bottom:1rem;border-radius:12px;overflow:hidden;position:relative;">
        <video id="qr-video" style="width:100%;border-radius:12px;display:block;" autoplay playsinline muted></video>
        <div style="position:absolute;inset:0;border:2px solid rgba(72,202,228,0.5);border-radius:12px;pointer-events:none;"></div>
        <button onclick="stopQRScan()" style="position:absolute;top:8px;right:8px;background:rgba(0,0,0,0.6);border:1px solid rgba(255,255,255,0.2);border-radius:50%;color:white;width:28px;height:28px;cursor:pointer;font-size:0.9rem;display:flex;align-items:center;justify-content:center;">✕</button>
      </div>
      <button onclick="startQRScan()" style="width:100%;padding:0.7rem;background:linear-gradient(135deg,rgba(72,202,228,0.15),rgba(27,154,170,0.08));border:1px dashed rgba(72,202,228,0.35);border-radius:12px;color:rgba(72,202,228,0.85);font-family:'DM Sans',sans-serif;font-size:0.85rem;font-weight:500;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;margin:1rem 0 0.85rem;">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3M17 14v3h3M14 20h3M20 17h1v3"/></svg>
        Scansiona QR Code
      </button>
      <div style="display:flex;align-items:center;gap:0.6rem;margin-bottom:0.85rem;"><div style="flex:1;height:1px;background:rgba(255,255,255,0.08);"></div><span style="font-size:0.68rem;color:rgba(255,255,255,0.2);letter-spacing:0.06em;">oppure</span><div style="flex:1;height:1px;background:rgba(255,255,255,0.08);"></div></div>
      <div class="room-label" style="text-align:left;margin-bottom:0.4rem;">${t.roomJoinSub||'Inserisci il codice della stanza'}</div>
      <input id="joinRoomCodeInput" class="room-input room-input-cyan room-input-code" type="text"
        maxlength="6" placeholder="AB3X7K"
        oninput="this.value=this.value.toUpperCase()"
        onkeydown="if(event.key==='Enter') doJoinWithCode()"/>
      <button class="room-icon-btn room-btn-cyan" onclick="doJoinWithCode()">${t.roomJoinBtn||'Unisciti →'}</button>
    </div>
  `;
  document.body.appendChild(modal);
  setTimeout(() => document.getElementById('joinRoomCodeInput')?.focus(), 100);
}
window.startJoinRoom = startJoinRoom;

/* ── QR Scanner ── */
let _qrStream = null;
let _qrInterval = null;

function startQRScan() {
  const container = document.getElementById('qr-scanner-container');
  const video = document.getElementById('qr-video');
  if (!container || !video) return;
  
  // Check for BarcodeDetector API or jsQR fallback
  if (!('BarcodeDetector' in window)) {
    // Fallback: load jsQR
    if (!window.jsQR) {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js';
      script.onload = () => _startCamera(container, video);
      document.head.appendChild(script);
      return;
    }
  }
  _startCamera(container, video);
}

function _startCamera(container, video) {
  container.style.display = 'block';
  setTimeout(() => container.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
  navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
    .then(stream => {
      _qrStream = stream;
      video.srcObject = stream;
      video.play();
      _qrInterval = setInterval(() => _scanFrame(video), 300);
    })
    .catch(() => {
      container.style.display = 'none';
      showToast('⚠️ Fotocamera non disponibile', 'match-found', 2500);
    });
}

function _scanFrame(video) {
  if (video.readyState !== video.HAVE_ENOUGH_DATA) return;
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth; canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  
  let code = null;
  if ('BarcodeDetector' in window) {
    new BarcodeDetector({ formats: ['qr_code'] }).detect(canvas)
      .then(results => { if (results.length) _handleQRResult(results[0].rawValue); })
      .catch(() => {});
    return;
  }
  if (window.jsQR) {
    const result = jsQR(imageData.data, imageData.width, imageData.height);
    if (result) _handleQRResult(result.data);
  }
}

function _handleQRResult(url) {
  stopQRScan();
  // Extract room code from URL ?room=XXXXX
  try {
    const u = new URL(url);
    const code = u.searchParams.get('room');
    if (code) {
      const inp = document.getElementById('joinRoomCodeInput');
      if (inp) { inp.value = code.toUpperCase(); inp.style.borderColor = 'rgba(72,202,228,0.6)'; }
      showToast('✅ QR rilevato: ' + code.toUpperCase(), 'match-found', 2000);
      setTimeout(() => doJoinWithCode(), 600);
      return;
    }
  } catch(e) {}
  // Maybe it's just the code directly
  const cleaned = url.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (cleaned.length >= 4 && cleaned.length <= 8) {
    const inp = document.getElementById('joinRoomCodeInput');
    if (inp) { inp.value = cleaned.substring(0,6); }
    showToast('✅ QR rilevato: ' + cleaned, 'match-found', 2000);
    setTimeout(() => doJoinWithCode(), 600);
  }
}

function stopQRScan() {
  if (_qrInterval) { clearInterval(_qrInterval); _qrInterval = null; }
  if (_qrStream) { _qrStream.getTracks().forEach(t => t.stop()); _qrStream = null; }
  const container = document.getElementById('qr-scanner-container');
  if (container) container.style.display = 'none';
}
window.startQRScan = startQRScan;
window.stopQRScan = stopQRScan;

function closeJoinRoomModal() { stopQRScan(); document.getElementById('joinRoomModal')?.remove(); }
window.closeJoinRoomModal = closeJoinRoomModal;

function doJoinWithCode() {
  const inp = document.getElementById('joinRoomCodeInput');
  const code = inp?.value.trim().toUpperCase()||'';
  if (code.length < 4) { if(inp){inp.style.borderColor='rgba(255,80,80,0.5)';setTimeout(()=>{inp.style.borderColor='';},1200);} return; }
  closeJoinRoomModal();
  state._pendingRoomCode = code;
  _showJoinNameModal(code);
}
window.doJoinWithCode = doJoinWithCode;

function _showJoinNameModal(code) {
  const saved = getLoggedInName('');
  if (saved) { _doJoinRoom(code, saved); return; }
  const t = state._uiText || UI_TEXT['en'];
  _nameModal('joinRoomNameModal','#48CAE4',
    t.roomNameTitle||'Il tuo nome', t.roomNameSub||'Come vuoi essere chiamato?',
    t.roomNamePlaceholder||'il tuo nome…', t.roomJoinBtn||'Entra →',
    "document.getElementById('joinRoomNameModal')?.remove();startJoinRoom()",
    `_submitJoinRoomName('${code}')`);
}
window._showJoinNameModal = _showJoinNameModal;

function _submitJoinRoomName(code) {
  const inp = document.getElementById('joinRoomNameModalInput');
  const name = inp?.value.trim();
  if (!name) { if(inp){inp.style.borderColor='rgba(255,80,80,0.5)';setTimeout(()=>{inp.style.borderColor='';},1200);} return; }
  document.getElementById('joinRoomNameModal')?.remove();
  _doJoinRoom(code, name);
}
window._submitJoinRoomName = _submitJoinRoomName;

function _doJoinRoom(code, guestName) {
  state.playerName = guestName;
  state._pendingRoomCode = code;
  joinPrivateRoom(code, guestName);
}
window._doJoinRoom = _doJoinRoom;

/* ── Crea Stanza overlay (senza QR) ── */
function confirmCreateRoom(roomId, roomCode, roomUrl) {
  document.getElementById('roomOverlay')?.remove();
  showWaitingOverlay(roomCode, roomUrl, roomId);
}
window.confirmCreateRoom = confirmCreateRoom;

/* ── Waiting overlay (con QR in cima) ── */
function showWaitingOverlay(roomCode, roomUrl, roomId) {
  document.getElementById('waitingRoomOverlay')?.remove();
  const t = state._uiText || UI_TEXT['en'];
  const cu = (typeof currentUser !== 'undefined') ? currentUser : null;
  const isLoggedIn = !!cu;
  const overlay = document.createElement('div');
  overlay.className = 'room-overlay'; overlay.id = 'waitingRoomOverlay';
  overlay.innerHTML = `
    <div class="room-box" style="text-align:center;">
      <div style="display:flex;align-items:center;margin-bottom:1.2rem;">
        <button class="room-back-btn" onclick="cancelRoom('${roomId}')"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg></button>
      </div>
      <div class="room-qr-wrap" style="margin-bottom:1.2rem;">
        <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(roomUrl)}" width="170" height="170" alt="QR" style="border-radius:12px;"/>
      </div>
      <div class="room-label" style="text-align:left;">${t.roomCodeLabel||'Room Code'}</div>
      <div class="room-code-row" style="margin-bottom:0.75rem;">
        <span class="room-code-text">${roomCode}</span>
        <button class="room-copy-btn" onclick="copyRoomCode('${roomCode}')">${t.roomCopyCode||'Copy'}</button>
      </div>
      <div class="room-label" style="text-align:left;">${t.roomLinkLabel||'Invite Link'}</div>
      <div class="room-link-row" style="margin-bottom:1.2rem;">
        <span class="room-link-text">${roomUrl}</span>
        <button class="room-copy-btn" onclick="copyRoomLink('${roomUrl}')">${t.roomCopyLink||'Copy'}</button>
        ${navigator.share ? `<button class="room-copy-btn" onclick="shareRoomLink('${roomUrl}')">${t.roomShare||'Share'}</button>` : ''}
      </div>
      <div class="room-waiting-row" style="justify-content:center;">
        <div class="room-waiting-dot"></div>
        ${t.roomWaiting||'Waiting for your friend…'}
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
}

function _buildFriendsListHTML(roomUrl) {
  const t = state._uiText || UI_TEXT['en'];
  const lp = (typeof _localProfile !== 'undefined') ? _localProfile : null;
  const friends = lp?.friends || [];
  if (!friends.length) return `<div style="padding:1rem;text-align:center;color:rgba(255,255,255,0.25);font-size:0.78rem;">${(t.roomNoFriends||'Nessun amico ancora.\nAggiungine dalla sezione Social!').replace('\n','<br>')}</div>`;
  return [...friends].sort((a,b)=>(b.online?1:0)-(a.online?1:0)).map(f => {
    const name = f.username||f.email||'Amico'; const on = !!f.online;
    const inviteLabel = on ? (t.roomInviteBtn||'Invita') : (t.roomOfflineBtn||'Offline');
    const statusLabel = on ? (t.roomOnline||'Online') : (t.roomOffline||'Offline');
    return `<div class="room-friend-row">
      <div class="room-friend-avatar">${name.charAt(0).toUpperCase()}<span class="room-friend-dot" style="background:${on?'#22c55e':'#ef4444'};box-shadow:0 0 5px ${on?'rgba(34,197,94,0.6)':'rgba(239,68,68,0.4)'};"></span></div>
      <div style="flex:1;min-width:0;"><div class="room-friend-name">${name}</div><div class="room-friend-status" style="color:${on?'#22c55e':'rgba(255,255,255,0.28)'};">${statusLabel}</div></div>
      <button class="room-friend-invite" onclick="sendFriendRoomInvite('${name}','${roomUrl}')" ${!on?'disabled':''}>${inviteLabel}</button>
    </div>`;
  }).join('');
}
window._buildFriendsListHTML = _buildFriendsListHTML;

function toggleFriendInvitePanel(roomUrl) {
  const p = document.getElementById('friendInvitePanel');
  if (!p) return;
  if (p.style.display==='block') { p.style.display='none'; return; }
  p.innerHTML = _buildFriendsListHTML(roomUrl);
  p.style.display = 'block';
}
window.toggleFriendInvitePanel = toggleFriendInvitePanel;

function sendFriendRoomInvite(username, roomUrl) {
  const t = state._uiText || UI_TEXT['en'];
  showToast(`✉️ ${t.roomInviteFriend||'Invito inviato a'} ${username}!`, 'match-found', 2500);
  document.querySelectorAll('#friendInvitePanel .room-friend-invite').forEach(b => {
    if (!b.disabled) { b.textContent = t.roomInvitedBtn||'✓ Inviato'; b.disabled=true; }
  });
}
window.sendFriendRoomInvite = sendFriendRoomInvite;

function copyRoomCode(code) {
  navigator.clipboard.writeText(code).catch(()=>{ const t=document.createElement('textarea'); t.value=code; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove(); });
  showToast('🔑 Codice copiato!', 'match-found', 2000);
}
window.copyRoomCode = copyRoomCode;

function copyRoomLink(url) {
  navigator.clipboard.writeText(url).catch(()=>{ const t=document.createElement('textarea'); t.value=url; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove(); });
  showToast('🔗 Link copiato!', 'match-found', 2000);
}
window.copyRoomLink = copyRoomLink;

function shareRoomLink(url) {
  navigator.share?.({ title:'Bond & Awareness', text:'Unisciti alla mia stanza 🌿', url }).catch(()=>{});
}
window.shareRoomLink = shareRoomLink;

function cancelRoom(roomId) {
  if (state._roomHostTimeout) { clearTimeout(state._roomHostTimeout); state._roomHostTimeout=null; }
  // FIX: pulisci anche il polling interval aggiunto come backup
  if (state._roomPollInterval) { clearInterval(state._roomPollInterval); state._roomPollInterval=null; }
  if (state._roomGuestChannel) {
    try { _sbClient()?.removeChannel(state._roomGuestChannel); } catch(e) {}
    state._roomGuestChannel = null;
    state._roomGuestListener = false;
  }
  if (roomId) {
    const sb = _sbClient();
    if (sb) sb.from('matches').delete().eq('id', roomId).then(()=>{}, ()=>{});
  }
  document.getElementById('roomOverlay')?.remove();
  document.getElementById('waitingRoomOverlay')?.remove();
  state._isRoomHost=false; state._roomCode=null; state._roomId=null;
  showModeSelection();
}
window.cancelRoom = cancelRoom;


function listenForRoomGuest(roomId, hostName, deckSeed) {
  const sb = _sbClient(); if (!sb) return;
  state._roomGuestListener = true;

  // Polling + Realtime su Supabase per il record stanza
  const channel = sb.channel('room:' + roomId)
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'matches', filter: 'id=eq.' + roomId }, async (payload) => {
      const data = payload.new;
      if (!data) return;
      // FIX: guard contro la race condition Realtime + polling.
      // Il poll potrebbe aver già avviato una creazione match asincrona mentre
      // il callback Realtime era in coda nell'event loop. Senza questo check
      // entrambi i path creerebbero un matchId diverso, desincronizzando host e guest.
      if (!state._roomGuestListener) return;
      if (data.status === 'joined' && data.guest_id && data.guest_id !== state.playerId) {
        if (!state._roomGuestListener) return; // double-check dopo la condizione
        clearInterval(state._roomPollInterval);
        state._roomPollInterval = null;
        try { sb.removeChannel(channel); } catch(e) {}
        state._roomGuestChannel = null;
        state._roomGuestListener = false;
        if (state._roomHostTimeout) { clearTimeout(state._roomHostTimeout); state._roomHostTimeout = null; }

        function _createMatchWithName(resolvedHostName) {
          const matchId = 'match_' + generateId();
          const matchData = {
            id: matchId,
            player1_id:   state.playerId,
            player1_name: resolvedHostName,
            player2_id:   data.guest_id,
            player2_name: data.guest_name,
            question_index: 0,
            question_text: '',
            current_turn: state.playerId,
            deck_seed:    deckSeed,
            status: 'active',
            session_token: state.sessionToken,
            timestamp: Date.now()
          };
          sb.from('matches').insert(matchData).then(async () => {
            await sb.from('matches').update({ match_id: matchId, status: 'active' }).eq('id', roomId);
            document.getElementById('roomOverlay')?.remove();
            document.getElementById('waitingRoomOverlay')?.remove();
            document.getElementById('createRoomNameModal')?.remove();
            goTo('game');
            startMatch(matchId, data.guest_name, true, data.guest_id);
          }).catch(err => console.error('Room match create error:', err));
        }

        const saved = getLoggedInName('');
        if (saved) {
          state.playerName = saved;
          _createMatchWithName(saved);
        } else {
          const t = state._uiText || UI_TEXT['en'];
          state._pendingMatchCallback = _createMatchWithName;
          const ov2 = document.getElementById('waitingRoomOverlay');
          if (ov2) ov2.remove();
          _nameModal('createRoomNameModal','#ffd580',
            t.roomNameTitle||'What shall we call you?', '',
            t.roomNamePlaceholder||'your name…', 'Enter →',
            '', '_submitCreateRoomName()');
        }
      }
    })
    .subscribe();
  state._roomGuestChannel = channel;

  // FIX: polling di backup ogni 4s — protegge dal WebSocket Realtime che cade
  // mentre l'host aspetta il guest (es. connessione mobile instabile)
  state._roomPollInterval = setInterval(async () => {
    if (!state._roomGuestListener) { clearInterval(state._roomPollInterval); return; }
    try {
      const { data } = await sb.from('matches').select('status,guest_id,guest_name').eq('id', roomId).maybeSingle();
      if (!data) return;
      if (data.status === 'joined' && data.guest_id && data.guest_id !== state.playerId) {
        // Trigger manuale — il channel Realtime probabilmente era caduto
        clearInterval(state._roomPollInterval);
        state._roomPollInterval = null;
        state._roomGuestListener = false;
        try { sb.removeChannel(channel); } catch(e) {}
        if (state._roomHostTimeout) { clearTimeout(state._roomHostTimeout); state._roomHostTimeout = null; }
        const saved = getLoggedInName('');
        const hostN = saved || state.playerName || hostName;
        const matchId = 'match_' + generateId();
        const matchData = {
          id: matchId,
          player1_id: state.playerId, player1_name: hostN,
          player2_id: data.guest_id,  player2_name: data.guest_name,
          question_index: 0, question_text: '',
          current_turn: state.playerId,
          deck_seed: deckSeed, status: 'active',
          session_token: state.sessionToken, timestamp: Date.now()
        };
        await sb.from('matches').insert(matchData);
        await sb.from('matches').update({ match_id: matchId, status: 'active' }).eq('id', roomId);
        document.getElementById('roomOverlay')?.remove();
        document.getElementById('waitingRoomOverlay')?.remove();
        goTo('game');
        startMatch(matchId, data.guest_name, true, data.guest_id);
      }
    } catch(e) {}
  }, 4000);
}

function _showRoomLoadingOverlay() {
  document.getElementById('roomLoadingOverlay')?.remove();
  const ov = document.createElement('div');
  ov.className = 'modal-overlay'; ov.id = 'roomLoadingOverlay';
  ov.innerHTML = `
    <div class="room-box" style="text-align:center;border-color:rgba(255,180,50,0.2);min-height:140px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1rem;">
      <div style="width:36px;height:36px;border:2px solid rgba(255,213,128,0.15);border-top-color:rgba(255,213,128,0.7);border-radius:50%;animation:spin 0.8s linear infinite;"></div>
      <div class="room-sub" style="margin:0;">Creazione stanza in corso…</div>
    </div>
  `;
  document.body.appendChild(ov);
}

function createPrivateRoom(hostName) {
  const roomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
  const roomId   = 'room_' + roomCode;
  const roomUrl  = window.location.origin + window.location.pathname + '?room=' + roomCode;
  const deckSeed = Math.floor(Math.random() * 2147483646) + 1;

  state.playerId    = generateId();
  state.playerName  = hostName;
  state.sessionToken= generateId();
  state.sessionStart= Date.now();
  state._isRoomHost = true;
  state._roomCode   = roomCode;
  state._roomId     = roomId;

  const sb = _sbClient();
  if (!sb) { document.getElementById('roomLoadingOverlay')?.remove(); showToast('⚠️ Not connected', 'match-found', 3000); return; }

  sb.from('matches').insert({
    id:        roomId,
    host_id:   state.playerId,
    host_name: hostName,
    status:    'waiting',
    deck_seed: deckSeed,
    timestamp: Date.now()
  }).then(() => {
    document.getElementById('roomLoadingOverlay')?.remove();
    showWaitingOverlay(roomCode, roomUrl, roomId);
    listenForRoomGuest(roomId, '__pending__', deckSeed);
    // Timeout host: se nessun guest arriva in 5 minuti, cancella la stanza
    state._roomHostTimeout = setTimeout(() => {
      cancelRoom(roomId);
      showToast('⏱ Nessun giocatore si è unito — stanza scaduta', 'match-found', 4000);
    }, 5 * 60 * 1000);
  }).catch(err => {
    document.getElementById('roomLoadingOverlay')?.remove();
    console.error('createPrivateRoom error:', err);
    showToast('⚠️ Errore creazione stanza — riprova', 'match-found', 4000);
  });
}
window.createPrivateRoom = createPrivateRoom;

function joinPrivateRoom(roomCode, guestName) {
  const roomId = 'room_' + roomCode.toUpperCase();

  function _resetBtn() {
    const btn = document.querySelector('#name-entry .btn-primary');
    if (btn) { btn.textContent = 'Enter the Space →'; btn.disabled = false; }
  }
  function _failAndReset(msg) {
    showToast(msg, 'match-found', 4000);
    _resetBtn();
    // Fix: ripristina _pendingRoom così l'utente può riprovare
    state._pendingRoom = true;
    state._pendingRoomCode = roomCode.toUpperCase();
  }

  let _attempts = 0;
  function _tryJoin() {
    _attempts++;
    const sb = _sbClient();
    if (!sb) { _failAndReset('⚠️ Not connected — retry'); return; }

    sb.from('matches').select('*').eq('id', roomId).maybeSingle().then(({ data, error }) => {
      if (error || !data) { _failAndReset('⚠️ Room not found or expired — ask for a new link'); return; }
      if (data.status === 'joined' || data.status === 'active') { _failAndReset('⚠️ Room is full — game already started'); return; }
      if (data.status !== 'waiting') { _failAndReset('⚠️ Room not available'); return; }

      state.playerId = generateId();
      state.playerName = guestName;
      state.sessionToken = generateId();
      state.sessionStart = Date.now();
      state._isRoomHost = false;

      sb.from('matches').update({ guest_id: state.playerId, guest_name: guestName, status: 'joined' }).eq('id', roomId)
        .then(({ error: updErr }) => {
          if (updErr) throw updErr;

          // FIX: timeout esteso a 60s con feedback progressivo (era 30s, troppo poco
          // per host su connessione lenta o che deve inserire il nome)
          let _guestTimeout = setTimeout(() => {
            if (state._roomChannel) { try { sb.removeChannel(state._roomChannel); } catch(e) {} state._roomChannel = null; }
            _failAndReset('⚠️ Host did not respond — try again');
          }, 60000);
          // Feedback progressivo: avvisi a 20s e 40s
          let _toast20 = setTimeout(() => { showToast('⏳ Waiting for host to start…', 'match-found', 3000); }, 20000);
          let _toast40 = setTimeout(() => { showToast('⏳ Almost there — host is connecting…', 'match-found', 3000); }, 40000);
          let _halfwayToast = setTimeout(() => { showToast('⏳ Still waiting for host…', 'match-found', 3000); }, 15000);

          goTo('game');
          const waitBadge = document.getElementById('waitingBadge');
          const waitTitle = document.getElementById('waitingBadgeTitle');
          const waitSub   = document.getElementById('waitingBadgeSub');
          if (waitBadge) waitBadge.style.display = 'flex';
          if (waitTitle) waitTitle.textContent = 'Waiting for host…';
          if (waitSub)   waitSub.textContent   = 'The host is setting up the room';

          const roomCh = sb.channel('guest_room_' + roomId)
            .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'matches', filter: 'id=eq.' + roomId }, ({ new: d }) => {
              if (!d) {
                clearTimeout(_guestTimeout); clearTimeout(_halfwayToast);
                clearTimeout(_toast20); clearTimeout(_toast40);
                try { sb.removeChannel(roomCh); } catch(e) {}
                state._roomChannel = null;
                showToast('⚠️ Host cancelled the room', 'match-found', 4000);
                goTo('name-entry'); _resetBtn(); return;
              }
              if (d.match_id && d.status === 'active') {
                clearTimeout(_guestTimeout); clearTimeout(_halfwayToast);
                clearTimeout(_toast20); clearTimeout(_toast40);
                try { sb.removeChannel(roomCh); } catch(e) {}
                state._roomChannel = null;
                if (waitBadge) waitBadge.style.display = 'none';
                startMatch(d.match_id, d.host_name, false, d.host_id);
              }
            }).subscribe();
          state._roomChannel = roomCh;
        }).catch(err => {
          if (_attempts < 3) { setTimeout(_tryJoin, 1500); }
          else { _failAndReset('⚠️ Could not join room — check your connection'); }
        });
    }).catch(err => {
      if (_attempts < 3) { setTimeout(_tryJoin, 1500); }
      else { _failAndReset('⚠️ Connection error — check your connection and try again'); }
    });
  }

  _tryJoin();
}


