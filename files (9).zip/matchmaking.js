// ══════════════════════════════════════════
//  MATCHMAKING — v6
// ══════════════════════════════════════════

// ── Contatore visivo attesa matchmaking ──
let _waitingCounterInterval = null;
function _startWaitingCounter() {
  _stopWaitingCounter();
  const start = Date.now();
  const titleEl = document.getElementById('waitingBadgeTitle');
  _waitingCounterInterval = setInterval(() => {
    const secs = Math.floor((Date.now() - start) / 1000);
    if (titleEl) titleEl.textContent = (state._uiText||{}).searching || ('Searching… ' + secs + 's');
  }, 1000);
}
function _stopWaitingCounter() {
  if (_waitingCounterInterval) { clearInterval(_waitingCounterInterval); _waitingCounterInterval = null; }
}

// ══════════════════════════════════════════
//  MATCHMAKING — Supabase Realtime
//  Queue + lock su Supabase, partita su Firebase
// ══════════════════════════════════════════

function _sbClient() {
  // Riusa il client Supabase già inizializzato dall'auth
  if (typeof supabaseClient !== 'undefined' && supabaseClient) return supabaseClient;
  return null;
}

async function cleanStaleQueue() {
  const sb = _sbClient(); if (!sb) return;
  // FIX: non eliminare entry di altri utenti basandosi sul timestamp locale —
  // il clock del client potrebbe essere sfasato rispetto al server Supabase.
  // Puliamo SOLO la nostra entry precedente (se playerId è già noto),
  // e usiamo un cutoff conservativo di 3 minuti per le entry orfane.
  // La pulizia aggressiva degli altri utenti causava perdita di priorità in coda.
  const cutoff = Date.now() - 180000; // 3 min — molto più conservativo del precedente 120s
  try {
    if (state.playerId) {
      // Rimuovi solo eventuali entry stantie del nostro stesso playerId (sessioni zombie)
      await sb.from('match_queue').delete()
        .eq('player_id', state.playerId)
        .lt('timestamp', Date.now() - 5000); // entry più vecchie di 5s dello stesso player
    }
    // Pulisci entry realmente orfane (> 3 minuti) per tutti
    await sb.from('match_queue').delete().lt('timestamp', cutoff);
  } catch(e) {}
}

function joinMatchQueue() {
  if (!state.playerId) state.playerId = generateId();
  state._userLeftMatch    = false;
  state.sessionToken      = generateId();
  state.isWaitingForMatch = true;
  state._matchFound       = false;
  state._myQueueId        = null;
  state._creating         = false;

  const badge = document.getElementById('waitingBadge');
  if (badge) badge.style.display = 'flex';
  _startWaitingCounter();

  // Pulisci listener e timer precedenti
  _cleanupQueueListeners();

  _joinQueueAsync().catch(err => {
    console.error('[Match] joinQueue error:', err);
    _stopWaitingCounter();
    showToast('⚠️ Connection error — retry in 3s', 'match-found', 3000);
    setTimeout(() => { if (state.isWaitingForMatch) joinMatchQueue(); }, 3000);
  });
}

async function _joinQueueAsync() {
  const sb = _sbClient();
  if (!sb) { throw new Error('Supabase client not ready'); }

  await cleanStaleQueue();

  state.sessionStart = Date.now();

  // Inserisci in coda
  const { data: row, error } = await sb.from('match_queue').insert({
    player_id:   state.playerId,
    player_name: state.playerName,
    timestamp:   state.sessionStart
  }).select().single();

  if (error) {
    console.error('[Match] Failed to insert into match_queue:', error);
    throw error;
  }
  state._myQueueId = row.id;

  // Subscrive ai cambiamenti della queue via Realtime
  const channel = sb.channel('match_queue_' + state.playerId)
    .on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'match_queue'
    }, () => {
      if (!state.isWaitingForMatch || state._matchFound) return;
      if (state._matchPollTimer) { clearTimeout(state._matchPollTimer); state._matchPollTimer = null; }
      _matchLoop();
    })
    .subscribe(status => {
      // Start first loop only once channel is confirmed ready
      if (status === 'SUBSCRIBED') _matchLoop();
    });

  state._queueChannel = channel;

  // Fallback: if subscribe takes >2s, start loop anyway
  setTimeout(() => {
    if (state.isWaitingForMatch && !state._matchFound && !state._matchLoopRunning) _matchLoop();
  }, 2000);
  // Supabase Realtime: ascolta notifiche di match creato per questo player
  const sb2 = _sbClient();
  if (sb2) {
    const matchNotifyCh = sb2.channel('match_notify_' + state.playerId)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'matches',
          filter: 'player1_id=eq.' + state.playerId }, async (payload) => {
        if (state._matchFound || !state.isWaitingForMatch) return;
        const m = payload.new;
        if (m && m.status === 'active') _onMatchFound(m.id, _matchRowToLegacy(m));
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'matches',
          filter: 'player2_id=eq.' + state.playerId }, async (payload) => {
        if (state._matchFound || !state.isWaitingForMatch) return;
        const m = payload.new;
        if (m && m.status === 'active') _onMatchFound(m.id, _matchRowToLegacy(m));
      })
      .subscribe();
    state._myMatchListener = { cleanup: () => { try { sb2.removeChannel(matchNotifyCh); } catch(e) {} } };
  } else {
    state._myMatchListener = null;
  }

  // Timeout 90s
  state._queueTimeout = setTimeout(() => {
    if (state._matchFound) return;
    _stopWaitingCounter();
    removeFromQueue(state._myQueueId);
    showToast('⏱ Still searching… retrying', 'match-found', 2000);
    setTimeout(() => {
      if (state.currentScreen === 'game' && !state.matchId && !state._userLeftMatch) joinMatchQueue();
    }, 2000);
  }, 90000);
}

async function _matchLoop() {
  if (state._matchFound || !state.isWaitingForMatch) return;
  if (state._matchLoopRunning) return; // prevent overlapping async calls
  state._matchLoopRunning = true;
  const sb = _sbClient();
  if (!sb) { state._matchLoopRunning = false; return; }

  // FIX: try/finally garantisce che _matchLoopRunning venga sempre resettato
  // anche in caso di eccezioni non catchate, evitando il freeze silenzioso
  try {
    const { data: players, error } = await sb
      .from('match_queue')
      .select('*')
      .order('timestamp', { ascending: true });

    if (error) {
      console.warn('[Match] _matchLoop query error:', error);
      state._matchPollTimer = setTimeout(_matchLoop, 2000);
      return;
    }

    const myId  = state.playerId;
    const me    = players.find(p => p.player_id === myId);
    const others = players.filter(p => p.player_id !== myId);

    // Se il nostro record non esiste più in queue, re-inseriscilo
    if (!me) {
      console.warn('[Match] My queue record missing — re-inserting');
      try {
        const { data: newRow, error: insertErr } = await sb.from('match_queue').insert({
          player_id:   myId,
          player_name: state.playerName,
          timestamp:   state.sessionStart || Date.now()
        }).select().single();
        if (!insertErr && newRow) state._myQueueId = newRow.id;
      } catch(e) {}
      state._matchPollTimer = setTimeout(_matchLoop, 1000);
      return;
    }

    if (others.length === 0) {
      // Aggiorna timestamp per restare fresco
      if (me && Date.now() - me.timestamp > 15000) {
        try { await sb.from('match_queue').update({ timestamp: Date.now() }).eq('id', me.id); } catch(e) {}
      }
      state._matchPollTimer = setTimeout(_matchLoop, 2000);
      return;
    }

    const opp = others[0]; // più vecchio in coda

    // Chi è arrivato DOPO crea il match (timestamp più alto)
    const myTs  = me.timestamp;
    const iCreate = myTs > opp.timestamp || (myTs === opp.timestamp && myId > opp.player_id);

    if (iCreate && !state._creating) {
      state._creating = true;
      state._matchLoopRunning = false; // rilascia prima di await
      await _doCreateMatch(
        { playerId: myId,          name: state.playerName, queueId: me.id },
        { playerId: opp.player_id, name: opp.player_name,  queueId: opp.id }
      );
      return; // evita il finally di resettare dopo il release manuale
    } else if (!iCreate) {
      state._matchPollTimer = setTimeout(_matchLoop, 500);
    }
  } catch(err) {
    console.error('[Match] _matchLoop unexpected error:', err);
    state._matchPollTimer = setTimeout(_matchLoop, 2000);
  } finally {
    // Garantisce sempre il reset del lock, tranne quando rilasciato manualmente sopra
    if (state._matchLoopRunning) state._matchLoopRunning = false;
  }
}

async function _doCreateMatch(me, opp) {
  const sb = _sbClient(); if (!sb) { state._creating = false; return; }

  // FIX: timeout globale di sicurezza — se l'intera operazione si blocca
  // (es. Supabase lento o network flap), state._creating viene rilasciato
  // entro 15s invece di rimanere true per sempre.
  const _createTimeout = setTimeout(() => {
    if (state._creating) {
      console.warn('[Match] _doCreateMatch timed out — releasing lock');
      state._creating = false;
      sb.from('match_locks').delete().eq('lock_key', [me.playerId, opp.playerId].sort().join('_')).then(()=>{}, ()=>{});
      state._matchPollTimer = setTimeout(_matchLoop, 1500);
    }
  }, 15000);

  // Lock atomico su Supabase per evitare race condition
  const lockKey = [me.playerId, opp.playerId].sort().join('_');
  const { error: lockErr } = await sb.from('match_locks').insert({
    lock_key:  lockKey,
    locked_by: me.playerId
  });

  if (lockErr) {
    clearTimeout(_createTimeout);
    // Lock già preso dall'altro — aspetta che crei lui
    state._creating = false;
    state._matchPollTimer = setTimeout(_matchLoop, 600);
    return;
  }

  try {
    const matchId  = 'match_' + generateId();
    const deckSeed = Math.floor(Math.random() * 2147483646) + 1;
    const tempDeck = (() => {
      const rng = mulberry32(deckSeed);
      const all = [...DECK_CARDS.map(c => ({...c})), ...FRUIT_WILDCARDS.map(c => ({...c}))];
      for (let i = all.length - 1; i > 0; i--) {
        const j = Math.floor(rng() * (i + 1));
        [all[i], all[j]] = [all[j], all[i]];
      }
      return all;
    })();

    const matchData = {
      player1_id:     opp.playerId,
      player1_name:   opp.name,
      player2_id:     me.playerId,
      player2_name:   state.playerName,
      question_index: 0,
      question_text:  tempDeck[0]?.en || '',
      current_turn:   opp.playerId,
      deck_seed:      deckSeed,
      status:         'active',
      timestamp:      Date.now()
    };

    // Scrivi la partita su Supabase
    await sb.from('matches').insert({ id: matchId, ...matchData });

    // Rimuovi entrambi dalla queue e rilascia lock atomicamente
    await Promise.all([
      sb.from('match_queue').delete().in('id', [opp.queueId, me.queueId].filter(Boolean)),
      sb.from('match_locks').delete().eq('lock_key', lockKey)
    ]);

    clearTimeout(_createTimeout);
    state._creating = false;
    // Il Supabase Realtime listener lo rileverà e chiamerà _onMatchFound
  } catch(err) {
    clearTimeout(_createTimeout);
    console.error('[Match] Create failed:', err);
    await sb.from('match_locks').delete().eq('lock_key', lockKey).then(()=>{}, ()=>{});
    state._creating = false;
    state._matchPollTimer = setTimeout(_matchLoop, 1500);
  }
}


// ── Converte una riga Supabase nel formato legacy usato internamente ──
function _matchRowToLegacy(row) {
  return {
    player1Id:     row.player1_id,
    player1Name:   row.player1_name,
    player2Id:     row.player2_id,
    player2Name:   row.player2_name,
    questionIndex: row.question_index || 0,
    questionText:  row.question_text  || '',
    currentTurn:   row.current_turn,
    deckSeed:      row.deck_seed,
    status:        row.status,
    answer:        row.answer ? (typeof row.answer === 'string' ? JSON.parse(row.answer) : row.answer) : null,
    timestamp:     row.timestamp,
    nextReadyP1:   row.next_ready_p1 || false,
    nextReadyP2:   row.next_ready_p2 || false
  };
}

function _onMatchFound(matchId, match) {
  if (state._matchFound) return;
  if (state.matchId) return;
  state._matchFound = true;

  _cleanupQueueListeners();
  state.isWaitingForMatch = false;
  _stopWaitingCounter();
  const badge = document.getElementById('waitingBadge');
  if (badge) badge.style.display = 'none';

  // Rimuovi dalla queue se ancora presente
  const sb = _sbClient();
  if (sb && state._myQueueId) {
    sb.from('match_queue').delete().eq('id', state._myQueueId).then(()=>{}, ()=>{});
  }

  const amP1         = match.player1Id === state.playerId;
  const opponentId   = amP1 ? match.player2Id   : match.player1Id;
  const opponentName = amP1 ? match.player2Name  : match.player1Name;
  startMatch(matchId, opponentName, amP1, opponentId);
}

function _cleanupQueueListeners() {
  state._matchLoopRunning = false;
  if (state._queueChannel) {
    try { _sbClient()?.removeChannel(state._queueChannel); } catch(e) {}
    state._queueChannel = null;
  }
  if (state._queueTimeout)  { clearTimeout(state._queueTimeout);  state._queueTimeout  = null; }
  if (state._matchPollTimer){ clearTimeout(state._matchPollTimer); state._matchPollTimer = null; }
  if (state._myMatchListener) { try { state._myMatchListener.cleanup(); } catch(e) {} state._myMatchListener = null; }
}

function removeFromQueue(id) {
  _cleanupQueueListeners();
  const sb = _sbClient();
  if (sb && id) sb.from('match_queue').delete().eq('id', id).then(()=>{}, ()=>{});
  state.isWaitingForMatch = false;
  // FIX: non impostare _matchFound=true qui — era un side effect nascosto che
  // impediva qualsiasi futuro tentativo di matchmaking nella stessa sessione.
  // _matchFound viene gestito esplicitamente solo in _onMatchFound e joinMatchQueue.
  _stopWaitingCounter();
  const badge = document.getElementById('waitingBadge');
  if (badge) badge.style.display = 'none';
}


