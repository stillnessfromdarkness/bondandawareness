// ══════════════════════════════════════════
//  MATCH START & REAL-TIME LISTENING
// ══════════════════════════════════════════
function _sbMatchToState(row) {
  return {
    player1Id:     row.player1_id,
    player1Name:   row.player1_name,
    player2Id:     row.player2_id,
    player2Name:   row.player2_name,
    questionIndex: row.question_index || 0,
    questionText:  row.question_text  || '',
    currentTurn:   row.current_turn,
    deckSeed:      row.deck_seed,
    status:        row.status,
    answer:        row.answer,
    timestamp:     row.timestamp,
    nextReadyP1:   row.next_ready_p1 || false,
    nextReadyP2:   row.next_ready_p2 || false
  };
}

function startMatch(matchId, opponentName, amPlayer1, opponentId) {
  // FIX: guard contro doppia chiamata — può succedere se listenForRoomGuest
  // Realtime + poll si sovrappongono prima che il fix entry-guard intervenga,
  // o se _onMatchFound viene invocato due volte in rapida successione.
  if (state.matchId && state.matchId !== matchId) {
    console.warn('[startMatch] already in match', state.matchId, '— ignoring call for', matchId);
    return;
  }
  state.matchId = matchId;
  state._matchFound = false; // reset so reconnection can re-enter if needed
  state._pendingMatchUpdate = null;
  state.opponentName = opponentName;
  state.opponentId = opponentId;
  state.amPlayer1 = amPlayer1;
  state.isMyTurn = amPlayer1;
  state.questionIndex = 0;
  state.currentAnswer = null;
  state.opponentAnswer = null;
  state.isWaitingForMatch = false;
  state._deckReady = false;
  state._currentSeed = null;
  state._nextSent = false;
  _sessionFruitsSeen = {};

  const wbEl = document.getElementById('waitingBadge');
  if (wbEl) wbEl.style.display = 'none';
  updateMatchUI();
  showToast('🎯 Connected with ' + opponentName + '!', 'match-found');

  // ── PRESENCE via Supabase Realtime ──
  const sb = _sbClient();
  if (state._presenceChannel) { try { sb?.removeChannel(state._presenceChannel); } catch(e) {} }

  const presenceChannel = sb?.channel('presence_' + matchId, { config: { presence: { key: state.playerId } } });
  state._presenceChannel = presenceChannel;
  // FIX: clearTimeout prima di nullare — se c'era un timer pendente da una partita
  // precedente, senza questo potrebbe sparare handleOpponentLeft sul nuovo matchId
  // e terminare la nuova partita subito dopo l'avvio.
  if (state._presenceTimer) { clearTimeout(state._presenceTimer); state._presenceTimer = null; }
  let _reconnectCount = 0;

  if (presenceChannel) {
    presenceChannel
      .on('presence', { event: 'sync' }, () => {
        if (!state.matchId) return;
        const presState = presenceChannel.presenceState();
        const oppOnline = !!presState[opponentId];
        if (!oppOnline) {
          if (state._presenceTimer) return;
          state._presenceTimer = setTimeout(() => {
            if (!state.matchId) return;
            const ps2 = presenceChannel.presenceState();
            if (!ps2[opponentId]) {
              _reconnectCount++;
              if (_reconnectCount < 2) {
                state._presenceTimer = null;
                showToast('⚠️ Partner connection lost — waiting…', 'match-found', 3000);
                state._presenceTimer = setTimeout(() => {
                  if (!state.matchId) return;
                  const ps3 = presenceChannel.presenceState();
                  if (!ps3[opponentId]) { handleOpponentLeft(matchId, null); }
                  else { state._presenceTimer = null; _reconnectCount = 0; }
                }, 3000);
              } else { handleOpponentLeft(matchId, null); }
            } else {
              state._presenceTimer = null;
              if (_reconnectCount > 0) showToast('✅ Partner reconnected!', 'match-found', 2000);
              _reconnectCount = 0;
            }
          }, 5000);
        } else {
          if (state._presenceTimer) { clearTimeout(state._presenceTimer); state._presenceTimer = null; }
          _reconnectCount = 0;
        }
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') await presenceChannel.track({ online_at: Date.now() });
      });
  }

  if (state._heartbeatInterval) clearInterval(state._heartbeatInterval);
  state._heartbeatInterval = setInterval(() => {
    if (!state.matchId || !presenceChannel) { clearInterval(state._heartbeatInterval); return; }
    presenceChannel.track({ online_at: Date.now() }).catch(() => {});
  }, 20000);

  listenToMatch(matchId);
  setTimeout(() => { try { setupTypingListener(); } catch(e) {} }, 500);
  setTimeout(() => {
    const cardScene = document.getElementById('cardScene');
    if (cardScene) { cardScene.style.maxWidth = '390px'; cardScene.style.width = '100%'; }
  }, 50);

  if (amPlayer1) {
    const sb2 = _sbClient();
    if (sb2) sb2.from('matches').update({ current_turn: state.playerId, answer: null }).eq('id', matchId).then(() => {}, () => {});
  }
}

function handleOpponentLeft(matchId, _unused) {
  if (!state.matchId) return;

  if (state._presenceChannel) { try { _sbClient()?.removeChannel(state._presenceChannel); } catch(e) {} state._presenceChannel = null; }
  if (state._presenceTimer) { clearTimeout(state._presenceTimer); state._presenceTimer = null; }
  if (state._heartbeatInterval) { clearInterval(state._heartbeatInterval); state._heartbeatInterval = null; }
  if (state._typingListenerActive) {
    if (state._typingOpRef) { try { _sbClient()?.removeChannel(state._typingOpRef); } catch(e) {} state._typingOpRef = null; }
    state._typingListenerActive = false;
  }
  if (state._typingInputListener) {
    const inp = document.getElementById('answerInput');
    if (inp) inp.removeEventListener('input', state._typingInputListener);
    state._typingInputListener = null;
  }
  if (state._matchChannel) { try { _sbClient()?.removeChannel(state._matchChannel); } catch(e) {} state._matchChannel = null; }

  try { _sbClient()?.from('matches').update({ status: 'abandoned' }).eq('id', matchId).then(() => {}).catch(() => {}); } catch(e) {}

  const prevScreen = state.currentScreen;

  state.matchId = null;
  state.opponentName = null;
  state.opponentId = null;
  state.amPlayer1 = false;
  state.isMyTurn = false;
  state.currentAnswer = null;
  state.opponentAnswer = null;
  state.answerSubmitted = false;
  state._deckReady = false;
  state._currentSeed = null;
  state._nextSent = false;
  state._typingListenerActive = false;
  // FIX: reset flag mid-round che potevano restare sporchi dalla partita precedente
  // causando blocchi alla domanda corrente o comportamenti UI errati nel match successivo.
  state._advancingNow = false;
  state._answerOnDB = false;
  state._nextPressed = false;
  state._showNextForReady = false;
  state._pendingMatchUpdate = null;
  state._partnerTyping = false;
  shuffledDeck = [];
  gameStarted = false;

  const gameArea = document.getElementById('offlineGameArea');
  const hint = document.getElementById('tapHint');
  const answerCont = document.getElementById('answerContainer');
  const chatArea = document.getElementById('chatArea');
  const myAnsBox = document.getElementById('myAnswerBox');
  const opAnsBox = document.getElementById('opponentAnswerBox');
  const btnNext = document.getElementById('btnNextQ');
  if (gameArea) gameArea.style.display = 'none';
  if (hint) hint.style.display = 'none';
  if (answerCont) answerCont.style.display = 'none';
  if (chatArea) chatArea.style.display = 'none';
  if (myAnsBox) myAnsBox.style.display = 'none';
  if (opAnsBox) opAnsBox.style.display = 'none';
  if (btnNext) btnNext.style.display = 'none';
  try { hideShowQuestionBtn(); } catch(e) {}

  try { updateMatchUI(); } catch(e) {}
  try { updateTurnUI(); } catch(e) {}
  showToast('⚠️ Partner disconnected — finding a new one…', 'match-found', 3000);

  if (prevScreen === 'game') {
    setTimeout(() => {
      if (state.currentScreen === 'game' && !state.matchId && !state.isOffline && !state.isSolo && !state._userLeftMatch) {
        joinMatchQueue();
      }
    }, 2000);
  }
}

function leaveMatch() {
  state._userLeftMatch = true;
  _cleanupQueueListeners();
  if (state._presenceTimer) { clearTimeout(state._presenceTimer); state._presenceTimer = null; }
  if (!state.matchId) return;
  if (state._presenceChannel) { try { _sbClient()?.removeChannel(state._presenceChannel); } catch(e) {} state._presenceChannel = null; }
  if (state._heartbeatInterval) { clearInterval(state._heartbeatInterval); state._heartbeatInterval = null; }
  if (state._myMatchListener) { try { state._myMatchListener.cleanup(); } catch(e) {} state._myMatchListener = null; }
  if (state._typingInputListener) {
    const input = document.getElementById('answerInput');
    if (input) input.removeEventListener('input', state._typingInputListener);
    state._typingInputListener = null;
  }
  if (state._matchChannel) { try { _sbClient()?.removeChannel(state._matchChannel); } catch(e) {} state._matchChannel = null; }
  if (state._typingListenerActive) {
    if (state._typingOpRef) { try { _sbClient()?.removeChannel(state._typingOpRef); } catch(e) {} state._typingOpRef = null; }
    state._typingListenerActive = false;
  }
  state.matchId = null;
  state.opponentName = null;
  state.opponentId = null;
  state.amPlayer1 = false;
  state.isMyTurn = false;
  state.currentAnswer = null;
  state.opponentAnswer = null;
  state.answerSubmitted = false;
  state._deckReady = false;
  state._currentSeed = null;
  state._nextSent = false;
  state._typingListenerActive = false;
  // FIX: stessi reset di handleOpponentLeft — leaveMatch era incompleto
  state._advancingNow = false;
  state._answerOnDB = false;
  state._nextPressed = false;
  state._showNextForReady = false;
  state._pendingMatchUpdate = null;
  state._partnerTyping = false;
  shuffledDeck = [];
  gameStarted = false;
}
window.leaveMatch = leaveMatch;

// Cleanup queue entry when tab closes (Supabase has no onDisconnect)
window.addEventListener('beforeunload', () => {
  const supabaseUrl = window.SUPABASE_URL || 'https://ughvejlapgbkxlfzegaa.supabase.co';
  const anonKey    = typeof window.SUPABASE_ANON_KEY !== 'undefined' ? window.SUPABASE_ANON_KEY : '';
  const headers = {
    'Content-Type': 'application/json',
    'apikey': anonKey,
    'Authorization': 'Bearer ' + anonKey,
    'Prefer': 'return=minimal'
  };

  // Rimuovi dalla coda matchmaking se in attesa
  if (state._myQueueId) {
    fetch(`${supabaseUrl}/rest/v1/match_queue?id=eq.${state._myQueueId}`,
      { method: 'DELETE', headers, keepalive: true }).catch(() => {});
  }

  // FIX: marca il match come abandoned se chiudiamo tab durante una partita.
  // Senza questo l'avversario attendeva fino allo scadere del presence timeout (~11s)
  // prima di ricevere handleOpponentLeft. Con questo viene notificato quasi istantaneamente
  // via _handleMatchUpdate (status === 'abandoned').
  if (state.matchId) {
    fetch(`${supabaseUrl}/rest/v1/matches?id=eq.${state.matchId}`,
      { method: 'PATCH', headers, body: JSON.stringify({ status: 'abandoned' }), keepalive: true }).catch(() => {});
  }
});

// ── SELF-RECONNECT: re-attach presence when coming back online or tab becomes visible ──
function _tryRejoinMatch() {
  const matchId = state.matchId;
  if (!matchId || !state.playerId) return;

  // Aggiorna presence track (segnala che siamo tornati online)
  if (state._presenceChannel) {
    state._presenceChannel.track({ online_at: Date.now() }).catch(() => {});
  }

  const sb = _sbClient();
  if (!sb) return;

  // FIX: verifica lo stato del match E ri-subscriba il canale se necessario.
  // Prima faceva solo track() — se il WebSocket era caduto e non si era auto-recuperato,
  // _handleMatchUpdate non avrebbe mai ricevuto aggiornamenti anche dopo il reconnect.
  sb.from('matches').select('*').eq('id', matchId).maybeSingle().then(({ data }) => {
    if (!data || data.status === 'abandoned') {
      handleOpponentLeft(matchId, null);
    } else {
      // Partita ancora attiva — applica l'ultimo stato noto e ri-subscriba il canale
      // se è in uno stato non sano (CHANNEL_ERROR / TIMED_OUT / null)
      _handleMatchUpdate(matchId, _sbMatchToState(data));
      const chState = state._matchChannel?.state;
      if (!chState || chState === 'closed' || chState === 'errored') {
        console.warn('[Reconnect] Match channel state:', chState, '— resubscribing');
        listenToMatch(matchId);
      }
      showToast('✅ Reconnected!', 'match-found', 2000);
    }
  }).catch(() => {
    // Errore di rete — riprova tra 3s
    setTimeout(() => { if (state.matchId === matchId) _tryRejoinMatch(); }, 3000);
  });
}

// FIX: listener unificati per online/offline/visibilitychange.
// In precedenza esistevano DUE set di listener identici (uno qui, uno in DOMContentLoaded)
// che si attivavano entrambi contemporaneamente causando:
//   - Doppio toast offline ("⚠️ Connection lost" + "📶 No connection")
//   - Doppio toast online ("🔄 Reconnected" + "✅ Reconnected")
//   - Doppia query DB al focus della tab
//   - Potenziale doppia chiamata a joinMatchQueue()
// Soluzione: questo set rimane come unico punto di gestione; il secondo set (in DOMContentLoaded)
// è stato ridotto a soli toast UI, senza logica di reconnect duplicata.

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') {
    // Pause all RAF loops when tab is not visible — saves CPU/GPU entirely
    if (window._stopAllAnims) window._stopAllAnims('__none__');
  }
  if (document.visibilityState === 'visible') {
    // Resume animation for current screen
    if (state.matchId) _tryRejoinMatch();
    const cur = state.currentScreen;
    if (cur === 'welcome') setTimeout(() => initMandala('welcomeCanvas'), 30);
    if (cur === 'splash')  setTimeout(() => initMandala('splashCanvas'), 30);
    if (cur === 'game')    requestAnimationFrame(() => initGlobeCanvas());
  }
});

window.addEventListener('online', () => {
  if (state.matchId) {
    setTimeout(_tryRejoinMatch, 500);
  } else if (state.isWaitingForMatch) {
    setTimeout(() => {
      if (state.isWaitingForMatch && !state.matchId) {
        // Pulisci prima di rientrare in coda (l'entry precedente è probabilmente stale)
        if (state._myQueueId) {
          const sb = _sbClient();
          if (sb) sb.from('match_queue').delete().eq('id', state._myQueueId).then(()=>{},()=>{});
          state._myQueueId = null;
        }
        if (state._queueTimeout) { clearTimeout(state._queueTimeout); state._queueTimeout = null; }
        showToast('🔄 Reconnected — resuming search…', 'match-found', 2000);
        joinMatchQueue();
      }
    }, 1000);
  }
});

window.addEventListener('offline', () => {
  if (state.matchId || state.isWaitingForMatch) {
    showToast('⚠️ Connection lost — reconnecting…', 'match-found', 3000);
  }
});

function listenToMatch(matchId) {
  const sb = _sbClient();
  if (!sb) return;
  if (state._matchChannel) { try { sb.removeChannel(state._matchChannel); } catch(e) {} }

  // Flag to avoid processing a stale fetch result if Realtime already delivered a newer update
  let realtimeReceived = false;
  let _resubscribeTimer = null;

  const ch = sb.channel('match_state_' + matchId)
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'matches', filter: 'id=eq.' + matchId }, payload => {
      realtimeReceived = true;
      if (payload.new) _handleMatchUpdate(matchId, _sbMatchToState(payload.new));
    })
    .subscribe((status) => {
      // FIX: gestire CHANNEL_ERROR e TIMED_OUT — il canale può cadere su mobile
      // o dopo una disconnessione temporanea. Senza questo, lo stato di gioco
      // smette di aggiornarsi silenziosamente e la partita si blocca.
      if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
        console.warn('[Match] Channel ' + status + ' — resubscribing in 2s');
        if (_resubscribeTimer) return; // già programmato
        _resubscribeTimer = setTimeout(() => {
          _resubscribeTimer = null;
          // Solo se la partita è ancora attiva e questo è ancora il canale corrente
          if (state.matchId === matchId && state._matchChannel === ch) {
            listenToMatch(matchId); // ricrea il canale
            // Fetch immediato per recuperare aggiornamenti persi durante il gap
            sb.from('matches').select('*').eq('id', matchId).maybeSingle().then(({ data }) => {
              if (data && state.matchId === matchId) _handleMatchUpdate(matchId, _sbMatchToState(data));
            }).catch(() => {});
          }
        }, 2000);
      }
    });
  state._matchChannel = ch;

  // Initial fetch used only if Realtime hasn't delivered anything yet (avoids race condition)
  sb.from('matches').select('*').eq('id', matchId).maybeSingle().then(({ data }) => {
    if (data && !realtimeReceived) _handleMatchUpdate(matchId, _sbMatchToState(data));
  });
}

function _handleMatchUpdate(matchId, data) {
  if (!data) return;
  if (matchId !== state.matchId) return;
  state._lastMatchData = data;

  if (data.status === 'abandoned') { handleOpponentLeft(matchId, null); return; }

  // ── 1. DECK: build if new seed ──────────────────────────────
  if (data.deckSeed && data.deckSeed !== state._currentSeed) {
    state._currentSeed = data.deckSeed;
    buildShuffledDeck(data.deckSeed);
    state._deckReady = true;
    dbg('DECK built seed:'+data.deckSeed+' len:'+shuffledDeck.length);
    const gameArea = document.getElementById('offlineGameArea');
    if (gameArea) {
      gameArea.style.display = '';
      const cardScene = document.getElementById('cardScene');
      if (cardScene && window.ResizeObserver) {
        if (window._cardResizeObserver) window._cardResizeObserver.disconnect();
        window._cardResizeObserver = new ResizeObserver((entries) => {
          for (const entry of entries) { if (entry.contentRect.width > 0) { window._cardResizeObserver.disconnect(); buildCardBack(); } }
        });
        window._cardResizeObserver.observe(cardScene);
      } else { setTimeout(() => buildCardBack(), 100); }
    }
  }

  // Wait for deck before processing game state
  if (!state._deckReady) {
    state._pendingMatchUpdate = { matchId, data };
    return;
  }
  if (state._pendingMatchUpdate) {
    const pending = state._pendingMatchUpdate;
    state._pendingMatchUpdate = null;
    if (pending.data.questionIndex > data.questionIndex) {
      setTimeout(() => _handleMatchUpdate(pending.matchId, Object.assign({}, pending.data, { deckSeed: state._currentSeed })), 0);
      return;
    }
  }

  const qi = (typeof data.questionIndex === 'number' && !isNaN(data.questionIndex)) ? data.questionIndex : 0;

  // ── 2. NEW QUESTION: qi changed — full reset ────────────────
  if (qi !== state.questionIndex) {
    state.questionIndex = qi;
    deckIndex = qi;
    state.isMyTurn = (data.currentTurn === state.playerId);
    state.currentAnswer = null;
    state.opponentAnswer = null;
    state.opponentAnswerLang = 'en';
    state.answerSubmitted = false;
    state._answerOnDB = false;
    state._partnerTyping = false;
    state._nextPressed = false;
    state._nextSent = false;
    state._advancingNow = false;
    state._showNextForReady = false;
    _resetRoundUI();
    const card = getCurrentCard();
    if (card && card.isFruit && typeof gardenUnlock === 'function') gardenUnlock(card.symbol);
    loadQuestion();
    updateTurnUI();
    return;
  }

  // ── 3. SAME QUESTION: update answer + ready state ──────────
  state.isMyTurn = (data.currentTurn === state.playerId);

  // Answer: once received, never clear until new question
  const ans = data.answer;
  if (ans && !state._answerOnDB) {
    state._answerOnDB = true;
    if (ans.playerId !== state.playerId) {
      state.opponentAnswer = ans.text;
      state.opponentAnswerLang = ans.lang || 'en';
      triggerOpponentAnswerToast(state.opponentName || 'Partner');
    } else {
      state.currentAnswer = state.currentAnswer || ans.text;
    }
  }

  // Ready state
  const p1Ready = !!data.nextReadyP1;
  const p2Ready = !!data.nextReadyP2;
  const myReady = state.amPlayer1 ? p1Ready : p2Ready;
  state._nextPressed = myReady;

  updateTurnUI();

  const btnNextEl = document.getElementById('btnNextQ');
  if (btnNextEl && btnNextEl.style.display !== 'none') {
    _updateNextReadyBadge(p1Ready, p2Ready);
    if (myReady) btnNextEl.classList.add('pressed');
  }

  // ── 4. BOTH READY: one player advances ─────────────────────
  if (p1Ready && p2Ready && !state._advancingNow) {
    state._advancingNow = true;
    _updateNextReadyBadge(true, true);
    const _fromQI = qi;
    const _fromMatchId = matchId;
    // FIX: timeout di sicurezza su tutta l'operazione di avanzamento —
    // se sb.update() non risponde (network freeze), _advancingNow resterebbe
    // true per sempre e il gioco si bloccherebbe alla domanda corrente.
    const _advanceGuard = setTimeout(() => {
      if (state._advancingNow && state.matchId === _fromMatchId) {
        console.warn('[Advance] timed out — releasing _advancingNow');
        state._advancingNow = false;
      }
    }, 8000);
    setTimeout(() => {
      if (state.matchId !== _fromMatchId || state.questionIndex !== _fromQI) {
        clearTimeout(_advanceGuard);
        state._advancingNow = false; return;
      }
      const sb = _sbClient(); if (!sb) { clearTimeout(_advanceGuard); state._advancingNow = false; return; }
      const nextQI = _fromQI + 1;
      const p1id = state.amPlayer1 ? state.playerId : state.opponentId;
      const p2id = state.amPlayer1 ? state.opponentId : state.playerId;
      const nextTurnId = (nextQI % 2 === 0) ? p1id : p2id;
      const nextCard = shuffledDeck[nextQI % shuffledDeck.length] || null;
      const nextQText = nextCard ? (nextCard.isFruit ? '' : (nextCard.en || '')) : '';
      sb.from('matches')
        .update({ question_index: nextQI, question_text: nextQText, current_turn: nextTurnId,
                  answer: null, next_ready_p1: false, next_ready_p2: false })
        .eq('id', _fromMatchId)
        .eq('question_index', _fromQI)
        .then(({ error }) => { clearTimeout(_advanceGuard); state._advancingNow = false; if (error) console.error('[Advance] failed:', error); })
        .catch(() => { clearTimeout(_advanceGuard); state._advancingNow = false; });
    }, 600);
  }
}

// ══════════════════════════════════════════
